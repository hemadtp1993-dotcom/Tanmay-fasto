import Link from "next/link";

export function FastoMark({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} role="img" aria-label="FASTO mark">
      <defs>
        <linearGradient id="fastoMark" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#6d3dff" />
          <stop offset="55%" stopColor="#5a22f5" />
          <stop offset="100%" stopColor="#ff7a18" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="44" height="44" rx="14" fill="url(#fastoMark)" />
      <path d="M17 33V15h14v4.6h-8.9v3.2h7.5v4.5h-7.5V33H17Z" fill="#fff" />
      <circle cx="33.5" cy="30.5" r="3.1" fill="#fff" opacity="0.9" />
    </svg>
  );
}

export function FastoLogo({ compact = false, invert = false }: { compact?: boolean; invert?: boolean }) {
  return (
    <Link href="/" className="group flex shrink-0 items-center gap-2.5" aria-label="FASTO home">
      <FastoMark className="h-9 w-9 transition-transform duration-300 group-hover:scale-105 group-hover:-rotate-3" />
      {!compact && (
        <span className="flex flex-col leading-none">
          <span
            className={`text-[1.35rem] font-extrabold tracking-tight ${invert ? "text-white" : "text-ink-900 dark:text-white"}`}
          >
            FAST<span className="text-flame-500">O</span>
          </span>
          <span
            className={`text-[0.58rem] font-semibold uppercase tracking-[0.22em] ${
              invert ? "text-white/70" : "text-ink-400"
            }`}
          >
            Shop faster
          </span>
        </span>
      )}
    </Link>
  );
}
