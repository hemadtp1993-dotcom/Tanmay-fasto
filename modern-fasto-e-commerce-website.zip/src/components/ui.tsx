import Link from "next/link";
import type { ReactNode } from "react";
import { discountPercent, rupees } from "@/lib/format";

export function Stars({ value, size = 12 }: { value: number; size?: number }) {
  const rounded = Math.round(value * 2) / 2;
  return (
    <span className="inline-flex items-center gap-[1px]" aria-label={`Rated ${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <svg key={i} width={size} height={size} viewBox="0 0 20 20" aria-hidden>
          <defs>
            <linearGradient id={`star-${i}-${rounded}`} x1="0" x2="1">
              <stop offset={`${(rounded >= i ? 100 : rounded + 0.5 === i ? 50 : 0)}%`} stopColor="#ff9f1a" />
              <stop offset={`${(rounded >= i ? 100 : rounded + 0.5 === i ? 50 : 0)}%`} stopColor="rgba(139,147,173,0.35)" />
            </linearGradient>
          </defs>
          <path
            fill={`url(#star-${i}-${rounded})`}
            d="M10 1.6l2.6 5.3 5.9.8-4.3 4.1 1 5.8L10 14.9l-5.2 2.7 1-5.8L1.5 7.7l5.9-.8L10 1.6z"
          />
        </svg>
      ))}
    </span>
  );
}

export function RatingPill({ value, count }: { value: number; count?: number }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="inline-flex items-center gap-1 rounded-md bg-emerald-600/12 px-1.5 py-0.5 text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
        {value.toFixed(1)}
        <svg width="10" height="10" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
          <path d="M10 1.6l2.6 5.3 5.9.8-4.3 4.1 1 5.8L10 14.9l-5.2 2.7 1-5.8L1.5 7.7l5.9-.8L10 1.6z" />
        </svg>
      </span>
      {count != null && <span className="text-[11px] font-medium text-ink-400">({count.toLocaleString("en-IN")})</span>}
    </span>
  );
}

export function Price({ price, mrp, size = "md" }: { price: number; mrp: number; size?: "sm" | "md" | "lg" }) {
  const off = discountPercent(mrp, price);
  const cls = { sm: "text-sm", md: "text-base", lg: "text-2xl" }[size];
  return (
    <span className="flex flex-wrap items-baseline gap-1.5">
      <span className={`${cls} font-extrabold tracking-tight text-ink-900 dark:text-white`}>{rupees(price)}</span>
      {off > 0 && <span className="text-xs text-ink-400 line-through">{rupees(mrp)}</span>}
      {off > 0 && <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">{off}% off</span>}
    </span>
  );
}

export function Chip({
  children,
  tone = "neutral",
  className = "",
}: {
  children: ReactNode;
  tone?: "neutral" | "brand" | "flame" | "emerald" | "rose";
  className?: string;
}) {
  const tones = {
    neutral: "bg-ink-400/12 text-ink-600 dark:text-ink-200",
    brand: "bg-brand-500/12 text-brand-600 dark:text-brand-300",
    flame: "bg-flame-500/15 text-flame-700 dark:text-flame-300",
    emerald: "bg-emerald-500/12 text-emerald-700 dark:text-emerald-400",
    rose: "bg-rose-500/12 text-rose-600 dark:text-rose-400",
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide ${tones[tone]} ${className}`}>
      {children}
    </span>
  );
}

export function SectionHeader({
  title,
  subtitle,
  href,
  cta = "See all",
}: {
  title: string;
  subtitle?: string;
  href?: string;
  cta?: string;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        <h2 className="text-lg font-extrabold tracking-tight text-ink-900 dark:text-white sm:text-xl">{title}</h2>
        {subtitle && <p className="mt-0.5 text-sm text-ink-400">{subtitle}</p>}
      </div>
      {href && (
        <Link
          href={href}
          className="shrink-0 rounded-full border border-brand-500/30 px-3.5 py-1.5 text-xs font-bold text-brand-600 transition hover:bg-brand-500 hover:text-white dark:text-brand-300"
        >
          {cta} →
        </Link>
      )}
    </div>
  );
}

export function EmptyState({ icon, title, body, action }: { icon: string; title: string; body: string; action?: ReactNode }) {
  return (
    <div className="panel flex flex-col items-center justify-center rounded-3xl px-6 py-16 text-center">
      <div className="mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-brand-500/10 text-3xl" aria-hidden>
        {icon}
      </div>
      <h3 className="text-lg font-bold text-ink-900 dark:text-white">{title}</h3>
      <p className="mt-1 max-w-sm text-sm text-ink-400">{body}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function PrimaryButton({
  children,
  className = "",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode }) {
  return (
    <button
      {...rest}
      className={`inline-flex items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-bold text-white shadow-float transition hover:bg-brand-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60 ${className}`}
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  className = "",
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { children: ReactNode }) {
  return (
    <button
      {...rest}
      className={`inline-flex items-center justify-center gap-2 rounded-xl border border-brand-500/40 bg-brand-500/8 px-5 py-3 text-sm font-bold text-brand-700 transition hover:bg-brand-500/16 active:scale-[0.98] disabled:opacity-60 dark:text-brand-200 ${className}`}
    >
      {children}
    </button>
  );
}

export function CtaLink({
  href,
  children,
  variant = "solid",
  className = "",
}: {
  href: string;
  children: ReactNode;
  variant?: "solid" | "outline";
  className?: string;
}) {
  const base =
    variant === "solid"
      ? "bg-brand-600 text-white shadow-float hover:bg-brand-700"
      : "border border-brand-500/40 bg-brand-500/8 text-brand-700 hover:bg-brand-500/16 dark:text-brand-200";
  return (
    <Link
      href={href}
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-bold transition active:scale-[0.98] ${base} ${className}`}
    >
      {children}
    </Link>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`shimmer rounded-xl ${className}`} />;
}
