"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import type { Product, Review } from "@/db/schema";
import { deliveryPromise, discountPercent, formatDate, rupees } from "@/lib/format";
import { CompareToggle } from "./product-card";
import { bump, useShop } from "./store";
import { RatingPill, SectionHeader, Stars } from "./ui";

export default function ProductDetail({
  product,
  reviews,
  similar,
  wishlisted,
  pincode: initialPincode,
}: {
  product: Product;
  reviews: Review[];
  similar: Product[];
  wishlisted: boolean;
  pincode: string;
}) {
  const router = useRouter();
  const { toast, requireLogin, user } = useShop();
  const [active, setActive] = useState(0);
  const [color, setColor] = useState(product.colors[0] ?? null);
  const [size, setSize] = useState(product.sizes[0] ?? null);
  const [pin, setPin] = useState(initialPincode);
  const [checkedPin, setCheckedPin] = useState(initialPincode);
  const [busy, setBusy] = useState(false);
  const [wish, setWish] = useState(wishlisted);
  const [reviewList, setReviewList] = useState(reviews);
  const [form, setForm] = useState({ rating: 5, title: "", body: "" });

  const off = discountPercent(product.mrp, product.price);
  const emi = Math.round(product.price / 12);

  const distribution = useMemo(() => {
    const buckets = [5, 4, 3, 2, 1].map((star) => {
      const weight = star === 5 ? 0.62 : star === 4 ? 0.24 : star === 3 ? 0.08 : star === 2 ? 0.04 : 0.02;
      return { star, count: Math.round(product.reviewCount * weight) };
    });
    const total = buckets.reduce((s, b) => s + b.count, 0) || 1;
    return buckets.map((b) => ({ ...b, pct: Math.round((b.count / total) * 100) }));
  }, [product.reviewCount]);

  async function addToCart(goToCart = false) {
    if (!requireLogin(`/product/${product.slug}`)) return;
    if (product.sizes.length && !size) {
      toast("Please select a size", "error");
      return;
    }
    setBusy(true);
    const res = await fetch("/api/cart", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id, quantity: 1, size, color }),
    });
    if (res.ok) {
      toast("Added to cart");
      bump();
      if (goToCart) router.push("/cart");
    } else toast("Could not add to cart", "error");
    setBusy(false);
  }

  async function toggleWish() {
    if (!requireLogin(`/product/${product.slug}`)) return;
    const res = await fetch("/api/wishlist", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id }),
    });
    const data = (await res.json()) as { wishlisted: boolean };
    setWish(data.wishlisted);
    toast(data.wishlisted ? "Saved to wishlist" : "Removed from wishlist", "info");
    bump();
  }

  async function share() {
    const url = `${window.location.origin}/product/${product.slug}`;
    try {
      if (navigator.share) await navigator.share({ title: product.title, url });
      else {
        await navigator.clipboard.writeText(url);
        toast("Product link copied");
      }
    } catch {
      toast("Sharing cancelled", "info");
    }
  }

  async function submitReview(event: React.FormEvent) {
    event.preventDefault();
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id, ...form }),
    });
    const data = (await res.json()) as { ok: boolean; error?: string; message?: string };
    if (!data.ok) {
      toast(data.error ?? "Could not post review", "error");
      return;
    }
    toast(data.message ?? "Review posted");
    setReviewList([
      {
        id: Date.now(),
        productId: product.id,
        userId: user?.id ?? null,
        authorName: user?.name ?? "You",
        rating: form.rating,
        title: form.title,
        body: form.body,
        verified: true,
        helpfulCount: 0,
        createdAt: new Date(),
      },
      ...reviewList,
    ]);
    setForm({ rating: 5, title: "", body: "" });
    router.refresh();
  }

  const inStock = product.stock > 0;

  return (
    <div className="space-y-10">
      <nav className="flex flex-wrap items-center gap-1.5 text-xs text-ink-400">
        <Link href="/" className="hover:text-brand-600">Home</Link>
        <span aria-hidden>/</span>
        <Link href={`/category/${product.categorySlug}`} className="hover:text-brand-600 capitalize">{product.categorySlug}</Link>
        <span aria-hidden>/</span>
        <span className="line-clamp-1 text-ink-600 dark:text-ink-200">{product.title}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-[minmax(0,460px)_1fr]">
        {/* gallery */}
        <div className="lg:sticky lg:top-40 lg:self-start">
          <div className="panel group relative overflow-hidden rounded-3xl">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={product.images[active]}
              alt={product.title}
              className="aspect-square w-full object-cover transition duration-700 group-hover:scale-110"
            />
            {off > 0 && (
              <span className="absolute left-3 top-3 rounded-full bg-flame-500 px-3 py-1 text-xs font-black text-white shadow">
                {off}% OFF
              </span>
            )}
          </div>
          <div className="mt-3 flex gap-2">
            {product.images.map((src, i) => (
              <button
                key={src + i}
                type="button"
                onMouseEnter={() => setActive(i)}
                onClick={() => setActive(i)}
                aria-label={`View image ${i + 1}`}
                className={`h-16 w-16 overflow-hidden rounded-xl border-2 transition ${
                  i === active ? "border-brand-600" : "border-transparent opacity-70 hover:opacity-100"
                }`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={src} alt="" loading="lazy" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => addToCart(false)}
              disabled={busy || !inStock}
              className="rounded-xl bg-brand-600 py-3.5 text-sm font-bold text-white shadow-float transition hover:bg-brand-700 active:scale-[0.98] disabled:opacity-50"
            >
              {inStock ? "🛒 Add to cart" : "Sold out"}
            </button>
            <button
              type="button"
              onClick={() => addToCart(true)}
              disabled={busy || !inStock}
              className="rounded-xl bg-flame-500 py-3.5 text-sm font-bold text-white shadow-float transition hover:bg-flame-600 active:scale-[0.98] disabled:opacity-50"
            >
              ⚡ Buy now
            </button>
          </div>
        </div>

        {/* info */}
        <div>
          <div className="flex items-start justify-between gap-3">
            <div>
              <Link href={`/products?q=${encodeURIComponent(product.brand)}`} className="text-xs font-black uppercase tracking-wide text-brand-600 dark:text-brand-300">
                {product.brand}
              </Link>
              <h1 className="mt-1 text-xl font-black leading-snug tracking-tight text-ink-900 dark:text-white sm:text-2xl">
                {product.title}
              </h1>
            </div>
            <div className="flex shrink-0 gap-1.5">
              <button
                type="button"
                onClick={toggleWish}
                aria-label="Toggle wishlist"
                className={`grid h-10 w-10 place-items-center rounded-full border transition hairline ${wish ? "bg-rose-500/10" : "hover:bg-ink-400/10"}`}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill={wish ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" className={wish ? "text-rose-500" : "text-ink-400"}>
                  <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l8.8 8.8 8.8-8.8a5.5 5.5 0 0 0 0-7.8z" />
                </svg>
              </button>
              <button type="button" onClick={share} aria-label="Share product" className="grid h-10 w-10 place-items-center rounded-full border transition hairline hover:bg-ink-400/10">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-ink-400">
                  <circle cx="18" cy="5" r="3" />
                  <circle cx="6" cy="12" r="3" />
                  <circle cx="18" cy="19" r="3" />
                  <path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4" />
                </svg>
              </button>
              <CompareToggle product={product} />
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-3">
            <RatingPill value={product.rating} count={product.reviewCount} />
            <span className="text-xs font-semibold text-ink-400">{product.soldCount.toLocaleString("en-IN")}+ sold</span>
            {product.badges.map((b) => (
              <span key={b} className="rounded-full bg-brand-500/12 px-2.5 py-1 text-[11px] font-black uppercase text-brand-600 dark:text-brand-300">
                {b}
              </span>
            ))}
          </div>

          <div className="panel mt-5 rounded-2xl p-4">
            <p className="flex flex-wrap items-baseline gap-2">
              <span className="text-3xl font-black tracking-tight text-ink-900 dark:text-white">{rupees(product.price)}</span>
              <span className="text-sm text-ink-400 line-through">{rupees(product.mrp)}</span>
              {off > 0 && <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{off}% off</span>}
            </p>
            <p className="mt-1 text-xs text-ink-400">Inclusive of all taxes · EMI from {rupees(emi)}/month</p>
            <p className={`mt-2 text-xs font-bold ${inStock ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600"}`}>
              {inStock ? (product.stock < 10 ? `Hurry! Only ${product.stock} left in stock` : `In stock · ships in 24 hours`) : "Currently out of stock"}
            </p>
          </div>

          {/* variants */}
          {product.colors.length > 0 && (
            <div className="mt-5">
              <p className="mb-2 text-xs font-black uppercase tracking-wide text-ink-400">
                Colour: <span className="text-ink-800 dark:text-white">{color}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className={`rounded-xl border px-3.5 py-2 text-xs font-bold transition ${
                      c === color ? "border-brand-600 bg-brand-500/10 text-brand-600 dark:text-brand-300" : "hairline text-ink-600 dark:text-ink-200 hover:border-brand-400"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {product.sizes.length > 0 && (
            <div className="mt-5">
              <p className="mb-2 flex items-center justify-between text-xs font-black uppercase tracking-wide text-ink-400">
                <span>
                  Size: <span className="text-ink-800 dark:text-white">{size}</span>
                </span>
                <span className="font-semibold normal-case text-brand-600 dark:text-brand-300">Size guide</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setSize(s)}
                    className={`min-w-[52px] rounded-xl border px-3 py-2 text-xs font-bold transition ${
                      s === size ? "border-brand-600 bg-brand-500/10 text-brand-600 dark:text-brand-300" : "hairline text-ink-600 dark:text-ink-200 hover:border-brand-400"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* delivery */}
          <div className="panel mt-5 rounded-2xl p-4">
            <p className="text-xs font-black uppercase tracking-wide text-ink-400">Delivery</p>
            <div className="mt-2 flex gap-2">
              <input
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="Enter 6-digit pincode"
                inputMode="numeric"
                className="w-40 rounded-xl border bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500 hairline"
              />
              <button
                type="button"
                onClick={() => {
                  if (pin.length !== 6) {
                    toast("Enter a valid 6-digit pincode", "error");
                    return;
                  }
                  setCheckedPin(pin);
                  toast("Delivery available at your pincode");
                }}
                className="rounded-xl bg-brand-500/12 px-4 py-2 text-xs font-bold text-brand-700 dark:text-brand-200"
              >
                Check
              </button>
            </div>
            {checkedPin.length === 6 && (
              <ul className="mt-3 space-y-1.5 text-xs text-ink-600 dark:text-ink-200">
                <li>🚚 Free delivery by <strong>{deliveryPromise(checkedPin)}</strong></li>
                <li>🔄 7-day easy return & replacement window</li>
                <li>💵 Cash on delivery available up to {rupees(50000)}</li>
                <li>🛡️ 1-year brand warranty · FASTO Assured</li>
              </ul>
            )}
          </div>

          {/* highlights */}
          <div className="mt-6">
            <h2 className="mb-2 text-sm font-black uppercase tracking-wide text-ink-400">Highlights</h2>
            <ul className="space-y-1.5">
              {product.highlights.map((h) => (
                <li key={h} className="flex gap-2 text-sm text-ink-700 dark:text-ink-100">
                  <span aria-hidden className="text-brand-600">•</span>
                  {h}
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-6">
            <h2 className="mb-2 text-sm font-black uppercase tracking-wide text-ink-400">Description</h2>
            <p className="text-sm leading-relaxed text-ink-600 dark:text-ink-200">{product.description}</p>
          </div>

          <div className="mt-6">
            <h2 className="mb-3 text-sm font-black uppercase tracking-wide text-ink-400">Specifications</h2>
            <div className="panel overflow-hidden rounded-2xl">
              <table className="w-full text-sm">
                <tbody>
                  {product.specs.map((s, i) => (
                    <tr key={s.label + i} className="border-b last:border-0 hairline">
                      <th scope="row" className="w-2/5 bg-ink-400/5 px-4 py-2.5 text-left font-semibold text-ink-500 dark:text-ink-300">
                        {s.label}
                      </th>
                      <td className="px-4 py-2.5 text-ink-800 dark:text-ink-100">{s.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* reviews */}
      <section>
        <SectionHeader title="Ratings & reviews" subtitle={`${product.reviewCount.toLocaleString("en-IN")} verified ratings`} />
        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <div className="panel rounded-2xl p-5">
            <p className="text-4xl font-black text-ink-900 dark:text-white">
              {product.rating.toFixed(1)}
              <span className="text-base text-ink-400">/5</span>
            </p>
            <div className="mt-1.5">
              <Stars value={product.rating} size={16} />
            </div>
            <p className="mt-1 text-xs text-ink-400">{product.reviewCount.toLocaleString("en-IN")} ratings & reviews</p>
            <div className="mt-4 space-y-1.5">
              {distribution.map((d) => (
                <div key={d.star} className="flex items-center gap-2 text-xs">
                  <span className="w-6 text-ink-400">{d.star}★</span>
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink-400/15">
                    <span className="block h-full rounded-full bg-amber-500" style={{ width: `${d.pct}%` }} />
                  </span>
                  <span className="w-10 text-right text-ink-400">{d.count.toLocaleString("en-IN")}</span>
                </div>
              ))}
            </div>

            {user ? (
              <form onSubmit={submitReview} className="mt-5 space-y-2 border-t pt-4 hairline">
                <p className="text-xs font-black uppercase tracking-wide text-ink-400">Rate this product</p>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button key={n} type="button" onClick={() => setForm((f) => ({ ...f, rating: n }))} aria-label={`${n} star`} className="text-xl">
                      <span className={n <= form.rating ? "text-amber-500" : "text-ink-400/50"}>★</span>
                    </button>
                  ))}
                </div>
                <input
                  value={form.title}
                  onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                  placeholder="Review headline"
                  className="w-full rounded-xl border bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500 hairline"
                />
                <textarea
                  value={form.body}
                  onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
                  placeholder="What did you like or dislike?"
                  rows={3}
                  className="w-full rounded-xl border bg-transparent px-3 py-2 text-sm outline-none focus:border-brand-500 hairline"
                />
                <button type="submit" className="w-full rounded-xl bg-brand-600 py-2.5 text-xs font-bold text-white">
                  Post review
                </button>
              </form>
            ) : (
              <p className="mt-4 border-t pt-4 text-xs text-ink-400 hairline">
                <Link href="/login" className="font-bold text-brand-600 dark:text-brand-300">
                  Sign in
                </Link>{" "}
                to write a review.
              </p>
            )}
          </div>

          <div className="space-y-3">
            {reviewList.map((r) => (
              <article key={r.id} className="panel rounded-2xl p-4">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 rounded-md bg-emerald-600/12 px-1.5 py-0.5 text-[11px] font-bold text-emerald-700 dark:text-emerald-400">
                    {r.rating}★
                  </span>
                  <p className="text-sm font-bold text-ink-900 dark:text-white">{r.title || "Verified purchase"}</p>
                </div>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-600 dark:text-ink-200">{r.body}</p>
                <p className="mt-2 flex flex-wrap items-center gap-2 text-[11px] text-ink-400">
                  <span className="font-bold text-ink-600 dark:text-ink-200">{r.authorName}</span>
                  <span>· {formatDate(r.createdAt)}</span>
                  {r.verified && <span className="rounded-full bg-brand-500/10 px-2 py-0.5 font-bold text-brand-600 dark:text-brand-300">Verified buyer</span>}
                  <span>· 👍 {r.helpfulCount} found this helpful</span>
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* similar */}
      {similar.length > 0 && (
        <section>
          <SectionHeader title="Similar products" subtitle="Other great options in this category" href={`/category/${product.categorySlug}`} />
          <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
            {similar.map((p) => (
              <div key={p.id} className="w-[172px] shrink-0 sm:w-[196px]">
                <Link href={`/product/${p.slug}`} className="hidden">
                  {p.title}
                </Link>
                <SimilarCard product={p} />
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function SimilarCard({ product }: { product: Product }) {
  return (
    <Link href={`/product/${product.slug}`} className="lift panel flex h-full flex-col overflow-hidden rounded-2xl">
      <div className="aspect-square overflow-hidden bg-ink-50 dark:bg-ink-900">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={product.images[0]} alt={product.title} loading="lazy" className="h-full w-full object-cover transition duration-500 hover:scale-105" />
      </div>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <p className="text-[10px] font-black uppercase tracking-wide text-brand-600 dark:text-brand-300">{product.brand}</p>
        <p className="line-clamp-2 text-xs font-semibold text-ink-800 dark:text-ink-100">{product.title}</p>
        <p className="mt-auto flex items-baseline gap-1.5 pt-1">
          <span className="text-sm font-extrabold text-ink-900 dark:text-white">{rupees(product.price)}</span>
          {off(product) > 0 && <span className="text-[11px] font-bold text-emerald-600">{off(product)}% off</span>}
        </p>
      </div>
    </Link>
  );
}

function off(p: Product) {
  return discountPercent(p.mrp, p.price);
}
