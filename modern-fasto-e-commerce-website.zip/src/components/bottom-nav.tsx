"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useShop } from "./store";

const ITEMS = [
  { href: "/", label: "Home", icon: "🏠" },
  { href: "/categories", label: "Categories", icon: "🗂️" },
  { href: "/products", label: "Search", icon: "🔍" },
  { href: "/cart", label: "Cart", icon: "🛒", badge: "cart" as const },
  { href: "/account", label: "Account", icon: "👤" },
];

export default function BottomNav() {
  const pathname = usePathname();
  const { cartCount } = useShop();

  if (pathname.startsWith("/admin")) return null;

  return (
    <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t bg-[var(--panel)]/98 backdrop-blur hairline lg:hidden">
      <ul className="grid grid-cols-5">
        {ITEMS.map((item) => {
          const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href.split("?")[0]) && item.href !== "/";
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                className={`relative flex flex-col items-center gap-0.5 py-2 text-[10px] font-bold transition ${
                  active ? "text-brand-600 dark:text-brand-300" : "text-ink-400"
                }`}
              >
                <span aria-hidden className="text-lg leading-none">
                  {item.icon}
                </span>
                {item.label}
                {item.badge === "cart" && cartCount > 0 && (
                  <span className="absolute right-[22%] top-1 grid h-4 min-w-[16px] place-items-center rounded-full bg-brand-600 px-1 text-[9px] font-black text-white">
                    {cartCount}
                  </span>
                )}
                {active && <span className="absolute -top-px h-0.5 w-8 rounded-full bg-brand-600" />}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
