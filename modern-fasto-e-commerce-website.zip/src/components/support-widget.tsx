"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const QUICK = [
  "Where is my order?",
  "How do returns work?",
  "What payment methods are supported?",
  "How do I use a coupon?",
];

const ANSWERS: Record<string, string> = {
  "Where is my order?":
    "Open Account → My Orders → Track order. You will see a live timeline from packing to doorstep, plus the courier partner's contact number.",
  "How do returns work?":
    "Most items carry a 7-day return window. Raise the request from your order page, and our courier picks it up from your doorstep within 48 hours. Refunds land in 3 working days after quality check.",
  "What payment methods are supported?":
    "UPI (GPay, PhonePe, Paytm), credit and debit cards, net banking from 58 banks, FASTO wallet, EMI on orders above ₹3,000 and Cash on Delivery.",
  "How do I use a coupon?":
    "Apply the code in the cart or on the checkout payment page. Only one coupon can be applied per order, and coupon discounts stack with product offers.",
};

export default function SupportWidget() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [question, setQuestion] = useState<string | null>(null);

  if (pathname.startsWith("/admin")) return null;

  const answer = question ? ANSWERS[question] : null;

  return (
    <div className="fixed bottom-20 right-4 z-[60] flex flex-col items-end gap-3 lg:bottom-6">
      {open && (
        <div className="animate-pop panel w-[min(20rem,calc(100vw-2rem))] overflow-hidden rounded-3xl shadow-float">
          <div className="bg-gradient-to-r from-brand-600 to-flame-500 px-4 py-3 text-white">
            <p className="text-sm font-bold">FASTO Assist</p>
            <p className="text-[11px] opacity-90">Typically replies in under 2 minutes</p>
          </div>
          <div className="max-h-72 space-y-3 overflow-y-auto p-4">
            <div className="rounded-2xl rounded-tl-sm bg-ink-400/10 px-3 py-2 text-sm text-ink-700 dark:text-ink-100">
              Hi 👋 I&apos;m Zoya from FASTO care. How can I help you today?
            </div>
            {answer && (
              <div className="rounded-2xl rounded-tr-sm bg-brand-500/10 px-3 py-2 text-sm text-ink-700 dark:text-ink-100">{answer}</div>
            )}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {QUICK.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setQuestion(q)}
                  className="rounded-full bg-ink-400/10 px-2.5 py-1.5 text-[11px] font-semibold text-ink-600 transition hover:bg-brand-500 hover:text-white dark:text-ink-200"
                >
                  {q}
                </button>
              ))}
            </div>
            <Link
              href="/contact"
              className="block rounded-xl bg-brand-600 py-2 text-center text-xs font-bold text-white"
              onClick={() => setOpen(false)}
            >
              Talk to a human →
            </Link>
          </div>
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="Customer support chat"
        className="grid h-13 w-13 place-items-center rounded-full bg-gradient-to-br from-brand-600 to-flame-500 p-3.5 text-lg text-white shadow-float transition hover:scale-105 active:scale-95"
      >
        {open ? "✕" : "💬"}
      </button>
    </div>
  );
}
