"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import type { Address, Coupon, Notification, Order, OrderItem, Product, returnRequests as ReturnTable } from "@/db/schema";
import { ORDER_STATUS_LABEL, deliveryPromise, formatDateTime, initials, rupees, statusTone } from "@/lib/format";
import ProductCard from "./product-card";
import { bump, useShop } from "./store";
import { EmptyState, RatingPill } from "./ui";

type OrderWithItems = Order & { items: OrderItem[] };
type ReturnRow = typeof ReturnTable.$inferSelect;

const TABS = [
  ["profile", "Profile", "👤"],
  ["orders", "My orders", "📦"],
  ["addresses", "Addresses", "📍"],
  ["payments", "Payment methods", "💳"],
  ["wishlist", "Wishlist", "❤️"],
  ["coupons", "Coupons & rewards", "🎁"],
  ["notifications", "Notifications", "🔔"],
  ["recent", "Recently viewed", "🕘"],
  ["returns", "Returns & refunds", "↩️"],
  ["support", "Help & support", "💬"],
] as const;

export default function AccountDashboard({
  user,
  orders,
  addresses,
  paymentMethods,
  notifications,
  returns,
  recent,
  wishlist,
  coupons,
  tab,
}: {
  user: { id: number; name: string; email: string; phone: string | null; role: string; referralCode: string | null; walletBalance: number; fastoCoins: number; createdAt: Date | string };
  orders: OrderWithItems[];
  addresses: Address[];
  paymentMethods: Array<{ id: number; kind: string; label: string; detail: string }>;
  notifications: Notification[];
  returns: ReturnRow[];
  recent: Product[];
  wishlist: Product[];
  coupons: Coupon[];
  tab: string;
}) {
  const router = useRouter();
  const params = useSearchParams();
  const { toast } = useShop();
  const [busy, setBusy] = useState(false);

  function go(next: string) {
    router.push(`/account?tab=${next}`);
  }

  async function act(body: Record<string, unknown>, successMessage?: string) {
    setBusy(true);
    const res = await fetch("/api/account", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = (await res.json()) as { ok: boolean; error?: string; message?: string };
    setBusy(false);
    if (!data.ok) {
      toast(data.error ?? "Action failed", "error");
      return false;
    }
    toast(data.message ?? successMessage ?? "Done");
    router.refresh();
    return true;
  }

  async function logout() {
    await fetch("/api/auth", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "logout" }) });
    bump();
    toast("Logged out", "info");
    router.push("/");
    router.refresh();
  }

  const activeTab = TABS.some(([id]) => id === tab) ? tab : "profile";

  return (
    <div className="grid gap-5 lg:grid-cols-[250px_1fr]">
      {/* sidebar */}
      <aside className="lg:sticky lg:top-40 lg:h-fit">
        <div className="panel rounded-2xl p-4">
          <div className="flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-brand-600 to-flame-500 text-sm font-black text-white">
              {initials(user.name)}
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-black text-ink-900 dark:text-white">{user.name}</p>
              <p className="truncate text-[11px] text-ink-400">{user.email}</p>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-brand-500/8 p-2 text-center">
              <p className="text-sm font-black text-brand-600 dark:text-brand-300">{user.fastoCoins}</p>
              <p className="text-[10px] font-bold uppercase text-ink-400">FASTO coins</p>
            </div>
            <div className="rounded-xl bg-emerald-500/10 p-2 text-center">
              <p className="text-sm font-black text-emerald-600 dark:text-emerald-400">{rupees(user.walletBalance)}</p>
              <p className="text-[10px] font-bold uppercase text-ink-400">Wallet</p>
            </div>
          </div>
        </div>

        <nav className="no-scrollbar panel mt-3 flex gap-1 overflow-x-auto rounded-2xl p-2 lg:flex-col">
          {TABS.map(([id, label, icon]) => (
            <button
              key={id}
              type="button"
              onClick={() => go(id)}
              className={`flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-bold transition ${
                activeTab === id ? "bg-brand-600 text-white" : "text-ink-600 hover:bg-ink-400/10 dark:text-ink-200"
              }`}
            >
              <span aria-hidden>{icon}</span>
              {label}
            </button>
          ))}
          {user.role === "admin" && (
            <Link href="/admin" className="flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold text-flame-600">
              <span aria-hidden>📊</span> Admin dashboard
            </Link>
          )}
          <button
            type="button"
            onClick={logout}
            className="flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-bold text-rose-600 hover:bg-rose-500/10"
          >
            <span aria-hidden>🚪</span> Logout
          </button>
        </nav>
      </aside>

      <div className="min-w-0 space-y-4">
        {activeTab === "profile" && (
          <>
            <Card title="Profile information">
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                  await act({ action: "profile.update", ...data }, "Profile updated");
                }}
                className="grid gap-3 sm:grid-cols-2"
              >
                <Input name="name" label="Full name" defaultValue={user.name} />
                <Input name="phone" label="Mobile number" defaultValue={user.phone ?? ""} />
                <div className="sm:col-span-2">
                  <p className="text-xs font-bold text-ink-400">Email (used for sign in)</p>
                  <p className="mt-1 text-sm font-semibold text-ink-800 dark:text-white">{user.email}</p>
                </div>
                <button type="submit" disabled={busy} className="w-fit rounded-xl bg-brand-600 px-5 py-2.5 text-xs font-bold text-white disabled:opacity-60">
                  Save changes
                </button>
              </form>
            </Card>

            <div className="grid gap-4 sm:grid-cols-3">
              <Card title="Referral code">
                <p className="font-mono text-lg font-black tracking-widest text-brand-600 dark:text-brand-300">{user.referralCode ?? "—"}</p>
                <p className="mt-1 text-[11px] text-ink-400">
                  Share it — you both get ₹200 when your friend places their first order.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    void navigator.clipboard.writeText(user.referralCode ?? "");
                    toast("Referral code copied");
                  }}
                  className="mt-3 w-full rounded-xl bg-brand-500/12 py-2 text-xs font-bold text-brand-700 dark:text-brand-200"
                >
                  Copy code
                </button>
              </Card>
              <Card title="Member since">
                <p className="text-lg font-black text-ink-900 dark:text-white">{formatDateTime(user.createdAt).split(",")[0]}</p>
                <p className="mt-1 text-[11px] text-ink-400">FASTO Plus member · free delivery on all orders</p>
              </Card>
              <Card title="Account security">
                <p className="text-[11px] text-ink-400">
                  Two-factor authentication and login alerts are on. Sessions expire automatically after 30 days.
                </p>
                <Link href="/forgot-password" className="mt-3 block rounded-xl bg-ink-400/10 py-2 text-center text-xs font-bold text-ink-700 dark:text-ink-100">
                  Change password
                </Link>
              </Card>
            </div>
          </>
        )}

        {activeTab === "orders" && (
          <>
            <Card title={`My orders (${orders.length})`}>
              {orders.length === 0 ? (
                <EmptyState
                  icon="📦"
                  title="No orders yet"
                  body="When you place an order it will appear here with live tracking."
                  action={<Link href="/products" className="rounded-xl bg-brand-600 px-5 py-3 text-sm font-bold text-white">Start shopping</Link>}
                />
              ) : (
                <div className="space-y-3">
                  {orders.map((order) => (
                    <article key={order.id} className="rounded-2xl border p-4 hairline">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <p className="text-sm font-black text-ink-900 dark:text-white">{order.orderNumber}</p>
                          <p className="text-[11px] text-ink-400">Placed {formatDateTime(order.createdAt)}</p>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusTone(order.status)}`}>
                            {ORDER_STATUS_LABEL[order.status] ?? order.status}
                          </span>
                          <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusTone(order.paymentStatus)}`}>
                            {order.paymentStatus}
                          </span>
                          <span className="text-sm font-black text-ink-900 dark:text-white">{rupees(order.total)}</span>
                        </div>
                      </div>

                      <div className="mt-3 flex gap-2 overflow-x-auto no-scrollbar">
                        {order.items.map((item) => (
                          <Link key={item.id} href={`/product/${item.slug}`} className="flex w-56 shrink-0 gap-2 rounded-xl bg-ink-400/6 p-2">
                            <span className="h-14 w-14 shrink-0 overflow-hidden rounded-lg bg-ink-50 dark:bg-ink-900">
                              {/* eslint-disable-next-line @next/next/no-img-element */}
                              <img src={item.image} alt="" loading="lazy" className="h-full w-full object-cover" />
                            </span>
                            <span className="min-w-0">
                              <span className="line-clamp-2 text-[11px] font-semibold text-ink-800 dark:text-ink-100">{item.title}</span>
                              <span className="block text-[10px] text-ink-400">Qty {item.quantity} · {rupees(item.price)}</span>
                            </span>
                          </Link>
                        ))}
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2">
                        <Link href={`/account/orders/${order.orderNumber}`} className="rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white">
                          Track order
                        </Link>
                        <button
                          type="button"
                          onClick={() => downloadInvoice(order)}
                          className="rounded-xl border px-4 py-2 text-xs font-bold text-ink-600 hairline dark:text-ink-200"
                        >
                          ⬇ Invoice
                        </button>
                        {["confirmed", "packed"].includes(order.status) && (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => act({ action: "order.cancel", orderId: order.id }, "Order cancelled")}
                            className="rounded-xl border border-rose-500/40 px-4 py-2 text-xs font-bold text-rose-600"
                          >
                            Cancel order
                          </button>
                        )}
                        {order.status === "delivered" && (
                          <button
                            type="button"
                            onClick={() => {
                              go("returns");
                              toast("Choose the item you want to return", "info");
                            }}
                            className="rounded-xl border px-4 py-2 text-xs font-bold text-ink-600 hairline dark:text-ink-200"
                          >
                            Return / Replace
                          </button>
                        )}
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </Card>
          </>
        )}

        {activeTab === "addresses" && (
          <>
            <Card title={`Saved addresses (${addresses.length})`}>
              <div className="grid gap-3 sm:grid-cols-2">
                {addresses.map((a) => (
                  <div key={a.id} className="rounded-2xl border p-4 hairline">
                    <p className="flex items-center gap-2 text-sm font-bold text-ink-900 dark:text-white">
                      {a.fullName}
                      <span className="rounded-full bg-ink-400/12 px-2 py-0.5 text-[10px] font-bold uppercase text-ink-500 dark:text-ink-300">{a.label}</span>
                      {a.isDefault && <span className="text-[10px] font-bold text-emerald-600">Default</span>}
                    </p>
                    <p className="mt-1 text-xs leading-relaxed text-ink-500 dark:text-ink-300">
                      {a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city}, {a.state} — {a.pincode}
                    </p>
                    <p className="mt-1 text-xs text-ink-400">📞 {a.phone}</p>
                    <div className="mt-3 flex gap-3 text-xs font-bold">
                      {!a.isDefault && (
                        <button type="button" onClick={() => act({ action: "address.default", id: a.id }, "Default address updated")} className="text-brand-600 dark:text-brand-300">
                          Set as default
                        </button>
                      )}
                      <button type="button" onClick={() => act({ action: "address.delete", id: a.id }, "Address removed")} className="text-rose-600">
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="Add a new address">
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                  const ok = await act({ action: "address.save", ...data, isDefault: addresses.length === 0 }, "Address saved");
                  if (ok) (e.target as HTMLFormElement).reset();
                }}
                className="grid gap-3 sm:grid-cols-2"
              >
                <Input name="fullName" label="Full name" required />
                <Input name="phone" label="Mobile number" required />
                <Input name="line1" label="Flat / house / building" required />
                <Input name="line2" label="Area / landmark" />
                <Input name="city" label="City" required />
                <Input name="state" label="State" required />
                <Input name="pincode" label="Pincode" required />
                <Input name="label" label="Type (Home / Work)" />
                <button type="submit" disabled={busy} className="w-fit rounded-xl bg-brand-600 px-5 py-2.5 text-xs font-bold text-white sm:col-span-2">
                  Save address
                </button>
              </form>
            </Card>
          </>
        )}

        {activeTab === "payments" && (
          <>
            <Card title={`Saved payment methods (${paymentMethods.length})`}>
              {paymentMethods.length === 0 ? (
                <p className="text-sm text-ink-400">No saved methods. Add one for one-tap checkout.</p>
              ) : (
                <div className="space-y-2">
                  {paymentMethods.map((m) => (
                    <div key={m.id} className="flex items-center gap-3 rounded-2xl border p-3.5 hairline">
                      <span aria-hidden className="text-xl">{m.kind === "upi" ? "🇮🇳" : m.kind === "card" ? "💳" : "🏦"}</span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-bold text-ink-900 dark:text-white">{m.label}</p>
                        <p className="truncate text-[11px] text-ink-400">{m.detail}</p>
                      </div>
                      <button type="button" onClick={() => act({ action: "payment.delete", id: m.id }, "Payment method removed")} className="text-xs font-bold text-rose-600">
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </Card>
            <Card title="Add a payment method">
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                  const ok = await act({ action: "payment.save", ...data, detail: data.detail }, "Payment method saved");
                  if (ok) (e.target as HTMLFormElement).reset();
                }}
                className="grid gap-3 sm:grid-cols-2"
              >
                <label className="text-xs font-bold text-ink-600 dark:text-ink-200">
                  Type
                  <select name="kind" className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline">
                    <option value="upi">UPI</option>
                    <option value="card">Card</option>
                    <option value="netbanking">Net banking</option>
                  </select>
                </label>
                <Input name="label" label="Label (e.g. HDFC UPI)" required />
                <Input name="detail" label="UPI ID / last 4 digits" required />
                <button type="submit" disabled={busy} className="w-fit rounded-xl bg-brand-600 px-5 py-2.5 text-xs font-bold text-white sm:col-span-2">
                  Save method
                </button>
              </form>
              <p className="mt-3 rounded-xl bg-ink-400/6 px-3 py-2 text-[11px] text-ink-400">
                🔒 FASTO stores only a masked reference. Full card numbers are tokenised by our PCI-DSS gateway.
              </p>
            </Card>
          </>
        )}

        {activeTab === "wishlist" && (
          <Card title={`My wishlist (${wishlist.length})`}>
            {wishlist.length === 0 ? (
              <EmptyState icon="❤️" title="Nothing saved yet" body="Tap the heart on any product to add it here." action={<Link href="/products" className="rounded-xl bg-brand-600 px-5 py-3 text-sm font-bold text-white">Explore products</Link>} />
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
                {wishlist.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </Card>
        )}

        {activeTab === "coupons" && (
          <>
            <Card title="Available coupons">
              <div className="grid gap-3 sm:grid-cols-2">
                {coupons.map((c) => (
                  <div key={c.id} className="rounded-2xl border border-dashed border-brand-500/40 bg-brand-500/5 p-4">
                    <p className="font-mono text-sm font-black tracking-wider text-brand-600 dark:text-brand-300">{c.code}</p>
                    <p className="mt-1 text-sm font-bold text-ink-900 dark:text-white">{c.title}</p>
                    <p className="mt-0.5 text-[11px] leading-snug text-ink-400">{c.description}</p>
                    <button
                      type="button"
                      onClick={() => {
                        void navigator.clipboard.writeText(c.code);
                        toast(`${c.code} copied`);
                      }}
                      className="mt-3 rounded-xl bg-brand-600 px-4 py-2 text-xs font-bold text-white"
                    >
                      Copy code
                    </button>
                  </div>
                ))}
              </div>
            </Card>
            <Card title="Referral programme">
              <p className="text-sm text-ink-600 dark:text-ink-200">
                Share <strong className="font-mono text-brand-600 dark:text-brand-300">{user.referralCode}</strong> with friends. They get ₹200 off
                their first order, you get ₹200 in your FASTO wallet — unlimited referrals.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    void navigator.clipboard.writeText(`Shop on FASTO with my code ${user.referralCode} and get ₹200 off your first order!`);
                    toast("Referral message copied");
                  }}
                  className="rounded-xl bg-brand-600 px-4 py-2.5 text-xs font-bold text-white"
                >
                  Copy invite message
                </button>
                <button type="button" onClick={() => toast("Share sheet opened", "info")} className="rounded-xl border px-4 py-2.5 text-xs font-bold text-ink-600 hairline dark:text-ink-200">
                  Share on WhatsApp
                </button>
              </div>
            </Card>
          </>
        )}

        {activeTab === "notifications" && (
          <Card
            title={`Notifications (${notifications.length})`}
            action={
              <button type="button" onClick={() => act({ action: "notifications.read" }, "All marked as read")} className="text-xs font-bold text-brand-600 dark:text-brand-300">
                Mark all read
              </button>
            }
          >
            {notifications.length === 0 ? (
              <p className="text-sm text-ink-400">You&apos;re all caught up.</p>
            ) : (
              <div className="space-y-2">
                {notifications.map((n) => (
                  <Link
                    key={n.id}
                    href={n.href ?? "/account"}
                    onClick={() => act({ action: "notification.read", id: n.id })}
                    className={`flex gap-3 rounded-2xl border p-3.5 transition hover:border-brand-400 hairline ${n.readAt ? "opacity-70" : "bg-brand-500/5"}`}
                  >
                    <span aria-hidden className="text-lg">
                      {n.kind === "order" ? "📦" : n.kind === "offer" ? "🎁" : n.kind === "reward" ? "🪙" : "🔔"}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-bold text-ink-900 dark:text-white">{n.title}</span>
                      <span className="block text-xs text-ink-400">{n.body}</span>
                      <span className="mt-0.5 block text-[10px] text-ink-400">{formatDateTime(n.createdAt)}</span>
                    </span>
                    {!n.readAt && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-brand-600" />}
                  </Link>
                ))}
              </div>
            )}
          </Card>
        )}

        {activeTab === "recent" && (
          <Card title={`Recently viewed (${recent.length})`}>
            {recent.length === 0 ? (
              <p className="text-sm text-ink-400">Products you view will show up here.</p>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
                {recent.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </Card>
        )}

        {activeTab === "returns" && (
          <>
            <Card title="Return & refund requests">
              {returns.length === 0 ? (
                <p className="text-sm text-ink-400">No requests yet. Delivered items can be returned within 7 days.</p>
              ) : (
                <div className="space-y-2">
                  {returns.map((r) => (
                    <div key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border p-3.5 hairline">
                      <div>
                        <p className="text-sm font-bold text-ink-900 dark:text-white">
                          #{r.id} · {r.orderNumber} · {r.kind}
                        </p>
                        <p className="text-[11px] text-ink-400">
                          {r.reason} · raised {formatDateTime(r.createdAt)} · refund {rupees(r.refundAmount)}
                        </p>
                      </div>
                      <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusTone(r.status === "completed" ? "delivered" : "pending")}`}>
                        {r.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </Card>
            <Card title="Raise a new request">
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                  const ok = await act({ action: "return.create", ...data, orderId: Number(data.orderId), kind: data.kind }, "Request raised");
                  if (ok) (e.target as HTMLFormElement).reset();
                }}
                className="grid gap-3 sm:grid-cols-2"
              >
                <label className="text-xs font-bold text-ink-600 dark:text-ink-200">
                  Order
                  <select name="orderId" className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline">
                    {orders
                      .filter((o) => o.status === "delivered")
                      .map((o) => (
                        <option key={o.id} value={o.id}>
                          {o.orderNumber} · {rupees(o.total)}
                        </option>
                      ))}
                    {orders.filter((o) => o.status === "delivered").length === 0 && <option value="">No delivered orders yet</option>}
                  </select>
                </label>
                <label className="text-xs font-bold text-ink-600 dark:text-ink-200">
                  Request type
                  <select name="kind" className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline">
                    <option value="return">Return & refund</option>
                    <option value="replace">Replacement</option>
                  </select>
                </label>
                <Input name="reason" label="Reason (damaged, wrong item, size issue…)" required />
                <Input name="comments" label="Additional comments" />
                <button type="submit" disabled={busy} className="w-fit rounded-xl bg-brand-600 px-5 py-2.5 text-xs font-bold text-white sm:col-span-2">
                  Submit request
                </button>
              </form>
            </Card>
          </>
        )}

        {activeTab === "support" && (
          <>
            <Card title="Help & support">
              <div className="grid gap-2 sm:grid-cols-2">
                {[
                  ["Track an order", "/account?tab=orders"],
                  ["Return or replace an item", "/account?tab=returns"],
                  ["Read the FAQ", "/faq"],
                  ["Contact customer care", "/contact"],
                  ["Shipping policy", "/faq#shipping"],
                  ["Refund timelines", "/faq#returns"],
                ].map(([label, href]) => (
                  <Link key={href} href={href} className="rounded-2xl border p-3.5 text-sm font-bold text-ink-800 transition hover:border-brand-500 hairline dark:text-ink-100">
                    {label} →
                  </Link>
                ))}
              </div>
            </Card>
            <Card title="Raise a ticket">
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                  const res = await fetch("/api/account", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ action: "support.create", ...data, email: user.email, name: user.name }),
                  });
                  const out = (await res.json()) as { ok: boolean; ticket?: string };
                  if (out.ok) {
                    toast(`Ticket ${out.ticket} created`);
                    (e.target as HTMLFormElement).reset();
                  }
                }}
                className="grid gap-3 sm:grid-cols-2"
              >
                <Input name="subject" label="Subject" required />
                <Input name="orderNumber" label="Order number (optional)" />
                <label className="text-xs font-bold text-ink-600 sm:col-span-2 dark:text-ink-200">
                  Describe the issue
                  <textarea name="message" required rows={4} className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline" />
                </label>
                <button type="submit" className="w-fit rounded-xl bg-brand-600 px-5 py-2.5 text-xs font-bold text-white sm:col-span-2">
                  Submit ticket
                </button>
              </form>
            </Card>
          </>
        )}

        <QuickReorder orders={orders} />
      </div>
    </div>
  );
}

function QuickReorder({ orders }: { orders: OrderWithItems[] }) {
  const delivered = orders.filter((o) => o.status === "delivered").flatMap((o) => o.items);
  if (!delivered.length) return null;
  return (
    <Card title="Buy it again">
      <div className="no-scrollbar flex gap-3 overflow-x-auto">
        {delivered.slice(0, 8).map((item) => (
          <Link key={item.id} href={`/product/${item.slug}`} className="w-28 shrink-0">
            <span className="block h-28 w-28 overflow-hidden rounded-2xl bg-ink-50 dark:bg-ink-900">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={item.image} alt="" loading="lazy" className="h-full w-full object-cover" />
            </span>
            <span className="mt-1 block line-clamp-2 text-[11px] font-semibold text-ink-700 dark:text-ink-200">{item.title}</span>
          </Link>
        ))}
      </div>
    </Card>
  );
}

function Card({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <section className="panel rounded-2xl p-4 sm:p-5">
      <header className="mb-3 flex items-center justify-between gap-3">
        <h2 className="text-sm font-black uppercase tracking-wide text-ink-400">{title}</h2>
        {action}
      </header>
      {children}
    </section>
  );
}

function Input({ name, label, defaultValue, required }: { name: string; label: string; defaultValue?: string; required?: boolean }) {
  return (
    <label className="text-xs font-bold text-ink-600 dark:text-ink-200">
      {label}
      <input
        name={name}
        required={required}
        defaultValue={defaultValue}
        className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none transition focus:border-brand-500 hairline"
      />
    </label>
  );
}

function downloadInvoice(order: OrderWithItems) {
  const address = order.shippingAddress as Record<string, string>;
  const rows = order.items
    .map((i) => `<tr><td>${i.title}</td><td>${i.quantity}</td><td>₹${i.price}</td><td>₹${i.price * i.quantity}</td></tr>`)
    .join("");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Invoice ${order.orderNumber}</title>
  <style>body{font-family:system-ui,sans-serif;padding:32px;color:#12162a}h1{margin:0 0 4px}table{width:100%;border-collapse:collapse;margin-top:18px}td,th{border-bottom:1px solid #e6e8f0;padding:8px;text-align:left;font-size:14px}.muted{color:#6b7280;font-size:13px}</style>
  </head><body>
  <h1>FASTO Retail Pvt. Ltd.</h1><p class="muted">Tax Invoice · ${order.orderNumber} · ${new Date(order.createdAt).toLocaleDateString("en-IN")}</p>
  <p class="muted">GSTIN 29ABCDE1234F1Z5 · 4th Floor, Prestige Tech Park, Bengaluru 560103</p>
  <p><strong>Bill to:</strong> ${address.fullName ?? ""}, ${address.line1 ?? ""}, ${address.city ?? ""} ${address.pincode ?? ""}</p>
  <table><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table>
  <p style="margin-top:18px"><strong>Items total:</strong> ₹${order.itemsTotal} &nbsp; <strong>Discount:</strong> ₹${order.discount} &nbsp; <strong>Delivery:</strong> ₹${order.deliveryFee} &nbsp; <strong>Grand total:</strong> ₹${order.total}</p>
  <p class="muted">Payment: ${order.paymentMethod.toUpperCase()} · ${order.paymentStatus}. This is a computer-generated invoice.</p>
  </body></html>`;
  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `FASTO-Invoice-${order.orderNumber}.html`;
  a.click();
  URL.revokeObjectURL(url);
}

export function OrderSummaryMeta({ rating, count }: { rating: number; count: number }) {
  return <RatingPill value={rating} count={count} />;
}

export function DeliveryEta({ pincode }: { pincode?: string }) {
  return <span>Arrives by {deliveryPromise(pincode)}</span>;
}
