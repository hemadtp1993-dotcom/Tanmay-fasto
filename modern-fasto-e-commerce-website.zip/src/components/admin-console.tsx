"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useMemo, useState } from "react";
import type { Banner, Category, Coupon, Order, OrderItem, Product, returnRequests as ReturnTable } from "@/db/schema";
import { ORDER_STATUS_LABEL, formatDateTime, rupees, statusTone } from "@/lib/format";
import { useShop } from "./store";

type OrderWithItems = Order & { items: OrderItem[] };
type ReturnRow = typeof ReturnTable.$inferSelect;
type AdminUser = { id: number; name: string; email: string; phone: string | null; role: string; createdAt: Date | string; orders: number; spent: number };

const SECTIONS = [
  ["overview", "Overview", "📊"],
  ["products", "Products", "📦"],
  ["orders", "Orders", "🧾"],
  ["inventory", "Inventory", "🏷️"],
  ["categories", "Categories", "🗂️"],
  ["coupons", "Coupons", "🎁"],
  ["banners", "Banners", "🖼️"],
  ["users", "Users", "👥"],
  ["returns", "Returns", "↩️"],
] as const;

export default function AdminConsole({
  stats,
  products,
  orders,
  users,
  coupons,
  banners,
  categories,
  returns,
  revenueByDay,
  topProducts,
}: {
  stats: { revenue: number; orders: number; aov: number; customers: number; pending: number; products: number; lowStock: number };
  products: Product[];
  orders: OrderWithItems[];
  users: AdminUser[];
  coupons: Coupon[];
  banners: Banner[];
  categories: Category[];
  returns: ReturnRow[];
  revenueByDay: Array<{ day: string; revenue: number; orders: number }>;
  topProducts: Array<{ title: string; sold: number; revenue: number }>;
}) {
  const router = useRouter();
  const params = useSearchParams();
  const { toast } = useShop();
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState(false);
  const tab = SECTIONS.some(([id]) => id === params.get("tab")) ? (params.get("tab") as string) : "overview";

  async function act(body: Record<string, unknown>, fallback: string) {
    setBusy(true);
    const res = await fetch("/api/admin", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = (await res.json()) as { ok: boolean; message?: string; error?: string };
    setBusy(false);
    toast(data.ok ? (data.message ?? fallback) : (data.error ?? "Action failed"), data.ok ? "success" : "error");
    if (data.ok) router.refresh();
    return data.ok;
  }

  const filteredProducts = useMemo(
    () => products.filter((p) => `${p.title} ${p.brand} ${p.categorySlug}`.toLowerCase().includes(query.toLowerCase())),
    [products, query],
  );

  const maxRevenue = Math.max(1, ...revenueByDay.map((d) => d.revenue));

  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-60 shrink-0 border-r bg-[var(--panel)] p-4 hairline lg:block">
        <Link href="/" className="mb-6 flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-brand-600 to-flame-500 text-sm font-black text-white">F</span>
          <span>
            <span className="block text-sm font-black text-ink-900 dark:text-white">FASTO Admin</span>
            <span className="block text-[10px] font-semibold uppercase tracking-widest text-ink-400">Control centre</span>
          </span>
        </Link>
        <nav className="space-y-1">
          {SECTIONS.map(([id, label, icon]) => (
            <Link
              key={id}
              href={`/admin?tab=${id}`}
              className={`flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-xs font-bold transition ${
                tab === id ? "bg-brand-600 text-white" : "text-ink-600 hover:bg-ink-400/10 dark:text-ink-200"
              }`}
            >
              <span aria-hidden>{icon}</span>
              {label}
            </Link>
          ))}
        </nav>
        <Link href="/" className="mt-6 block rounded-xl border px-3 py-2.5 text-center text-xs font-bold text-ink-600 hairline dark:text-ink-200">
          ← Back to storefront
        </Link>
      </aside>

      <div className="min-w-0 flex-1 p-4 sm:p-6">
        <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-black tracking-tight text-white sm:text-2xl">
              {SECTIONS.find(([id]) => id === tab)?.[1]}
            </h1>
            <p className="text-xs text-white/60">Live data from your FASTO catalogue and orders</p>
          </div>
          <div className="flex flex-wrap gap-1.5 lg:hidden">
            {SECTIONS.slice(0, 5).map(([id, label]) => (
              <Link key={id} href={`/admin?tab=${id}`} className={`rounded-lg px-2.5 py-1.5 text-[11px] font-bold ${tab === id ? "bg-white text-ink-900" : "bg-white/10 text-white"}`}>
                {label}
              </Link>
            ))}
          </div>
        </header>

        {tab === "overview" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              {[
                ["Revenue", rupees(stats.revenue), "All-time gross"],
                ["Orders", stats.orders.toLocaleString("en-IN"), `${stats.pending} awaiting dispatch`],
                ["Avg order value", rupees(stats.aov), "Across paid orders"],
                ["Customers", stats.customers.toLocaleString("en-IN"), "Registered shoppers"],
              ].map(([label, value, hint]) => (
                <div key={label} className="rounded-2xl bg-white/5 p-4">
                  <p className="text-[10px] font-black uppercase tracking-widest text-white/60">{label}</p>
                  <p className="mt-1 text-2xl font-black text-white">{value}</p>
                  <p className="text-[11px] text-white/50">{hint}</p>
                </div>
              ))}
            </div>

            <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
              <div className="rounded-2xl bg-white/5 p-4">
                <p className="mb-4 text-xs font-black uppercase tracking-widest text-white/70">Revenue · last 7 days</p>
                <div className="flex h-44 items-end gap-2">
                  {revenueByDay.map((d) => (
                    <div key={d.day} className="flex flex-1 flex-col items-center gap-2">
                      <div
                        className="w-full rounded-t-lg bg-gradient-to-t from-brand-600 to-flame-400 transition-all"
                        style={{ height: `${Math.max(4, (d.revenue / maxRevenue) * 100)}%` }}
                        title={`${rupees(d.revenue)} · ${d.orders} orders`}
                      />
                      <span className="text-[10px] text-white/50">{d.day}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl bg-white/5 p-4">
                <p className="mb-3 text-xs font-black uppercase tracking-widest text-white/70">Top products</p>
                <div className="space-y-2">
                  {topProducts.map((p, i) => (
                    <div key={p.title} className="flex items-center gap-3">
                      <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-white/10 text-[11px] font-black text-white">{i + 1}</span>
                      <span className="min-w-0 flex-1 truncate text-xs font-semibold text-white">{p.title}</span>
                      <span className="shrink-0 text-[11px] text-white/60">{p.sold} sold</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              {[
                ["Catalogue size", stats.products, "products live"],
                ["Low stock alerts", stats.lowStock, "below 10 units"],
                ["Open returns", returns.filter((r) => r.status === "requested").length, "awaiting action"],
              ].map(([label, value, hint]) => (
                <div key={label as string} className="rounded-2xl bg-white/5 p-4">
                  <p className="text-2xl font-black text-white">{value as number}</p>
                  <p className="text-xs font-bold text-white/80">{label as string}</p>
                  <p className="text-[11px] text-white/50">{hint as string}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "products" && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products…"
                className="min-w-48 flex-1 rounded-xl bg-white/8 px-3.5 py-2.5 text-sm text-white outline-none placeholder:text-white/40"
              />
              <button
                type="button"
                onClick={() => {
                  setEditing(null);
                  setProductForm(true);
                }}
                className="rounded-xl bg-white px-4 py-2.5 text-xs font-black text-ink-900"
              >
                + Add product
              </button>
            </div>

            {productForm && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                  const ok = await act(
                    {
                      action: "product.save",
                      id: editing?.id,
                      ...data,
                      specs: data.specs,
                      highlights: data.highlights,
                      images: data.images,
                      colors: data.colors,
                      sizes: data.sizes,
                      isFlashSale: data.isFlashSale === "on",
                      trending: data.trending === "on",
                      bestseller: data.bestseller === "on",
                      newArrival: data.newArrival === "on",
                    },
                    "Product saved",
                  );
                  if (ok) setProductForm(false);
                }}
                className="grid gap-3 rounded-2xl bg-white/5 p-4 sm:grid-cols-2"
              >
                <Field name="title" label="Product title" defaultValue={editing?.title} required className="sm:col-span-2" />
                <Field name="brand" label="Brand" defaultValue={editing?.brand} required />
                <label className="text-[11px] font-bold uppercase tracking-wide text-white/60">
                  Category
                  <select name="categorySlug" defaultValue={editing?.categorySlug ?? "electronics"} className="mt-1 w-full rounded-xl bg-white/8 px-3 py-2.5 text-sm font-normal text-white outline-none">
                    {categories.map((c) => (
                      <option key={c.slug} value={c.slug} className="text-ink-900">
                        {c.name}
                      </option>
                    ))}
                  </select>
                </label>
                <Field name="price" label="Selling price (₹)" type="number" defaultValue={editing?.price} required />
                <Field name="mrp" label="MRP (₹)" type="number" defaultValue={editing?.mrp} required />
                <Field name="stock" label="Stock units" type="number" defaultValue={editing?.stock ?? 25} />
                <Field name="rating" label="Rating (1-5)" type="number" defaultValue={editing?.rating ?? 4.3} />
                <Field name="images" label="Image URLs (one per line)" defaultValue={editing?.images.join("\n")} className="sm:col-span-2" multiline />
                <Field name="colors" label="Colours (comma separated)" defaultValue={editing?.colors.join(", ")} />
                <Field name="sizes" label="Sizes (comma separated)" defaultValue={editing?.sizes.join(", ")} />
                <Field name="highlights" label="Highlights (one per line)" defaultValue={editing?.highlights.join("\n")} className="sm:col-span-2" multiline />
                <Field name="description" label="Description" defaultValue={editing?.description} className="sm:col-span-2" multiline />
                <Field name="specs" label="Specs (Label: value per line)" defaultValue={editing?.specs.map((s) => `${s.label}: ${s.value}`).join("\n")} className="sm:col-span-2" multiline />
                <div className="flex flex-wrap gap-3 text-xs font-bold text-white sm:col-span-2">
                  {([["isFlashSale", "Flash sale"], ["trending", "Trending"], ["bestseller", "Bestseller"], ["newArrival", "New arrival"]] as const).map(([key, label]) => (
                    <label key={key} className="flex items-center gap-1.5">
                      <input type="checkbox" name={key} defaultChecked={editing ? Boolean(editing[key]) : false} className="accent-brand-500" />
                      {label}
                    </label>
                  ))}
                </div>
                <div className="flex gap-2 sm:col-span-2">
                  <button type="submit" disabled={busy} className="rounded-xl bg-white px-5 py-2.5 text-xs font-black text-ink-900 disabled:opacity-60">
                    {editing ? "Update product" : "Create product"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setProductForm(false);
                      setEditing(null);
                    }}
                    className="rounded-xl border border-white/25 px-5 py-2.5 text-xs font-bold text-white"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            <div className="overflow-x-auto rounded-2xl bg-white/5">
              <table className="w-full min-w-[720px] text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase tracking-widest text-white/60">
                    <th className="p-3">Product</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Price</th>
                    <th className="p-3">Stock</th>
                    <th className="p-3">Rating</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="border-b border-white/5 last:border-0">
                      <td className="p-3">
                        <div className="flex items-center gap-2.5">
                          <span className="h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-white/10">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={p.images[0]} alt="" loading="lazy" className="h-full w-full object-cover" />
                          </span>
                          <span className="min-w-0">
                            <span className="block max-w-[220px] truncate text-xs font-bold text-white">{p.title}</span>
                            <span className="block text-[10px] text-white/50">{p.brand}</span>
                          </span>
                        </div>
                      </td>
                      <td className="p-3 text-xs capitalize text-white/70">{p.categorySlug}</td>
                      <td className="p-3 text-xs font-bold text-white">{rupees(p.price)}</td>
                      <td className={`p-3 text-xs font-bold ${p.stock === 0 ? "text-rose-400" : p.stock < 10 ? "text-amber-400" : "text-white/80"}`}>{p.stock}</td>
                      <td className="p-3 text-xs text-white/70">{p.rating.toFixed(1)}★</td>
                      <td className="p-3 text-right">
                        <div className="flex justify-end gap-2 text-[11px] font-bold">
                          <button
                            type="button"
                            onClick={() => {
                              setEditing(p);
                              setProductForm(true);
                              window.scrollTo({ top: 0, behavior: "smooth" });
                            }}
                            className="text-brand-300"
                          >
                            Edit
                          </button>
                          <button type="button" onClick={() => act({ action: "product.delete", id: p.id }, "Product removed")} className="text-rose-400">
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === "inventory" && (
          <div className="overflow-x-auto rounded-2xl bg-white/5">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase tracking-widest text-white/60">
                  <th className="p-3">Product</th>
                  <th className="p-3">Current stock</th>
                  <th className="p-3">Set stock</th>
                  <th className="p-3">Price (₹)</th>
                  <th className="p-3 text-right">Save</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id} className="border-b border-white/5 last:border-0">
                    <td className="max-w-[240px] truncate p-3 text-xs font-semibold text-white">{p.title}</td>
                    <td className={`p-3 text-xs font-bold ${p.stock === 0 ? "text-rose-400" : p.stock < 10 ? "text-amber-400" : "text-white/80"}`}>{p.stock}</td>
                    <td className="p-3 text-xs text-white/70">{rupees(p.price)}</td>
                    <td className="p-3 text-right">
                      <form
                        onSubmit={async (e) => {
                          e.preventDefault();
                          const value = Number(new FormData(e.currentTarget).get("stock"));
                          await act({ action: "product.stock", id: p.id, stock: value }, "Inventory updated");
                        }}
                        className="flex items-center justify-end gap-2"
                      >
                        <input name="stock" type="number" defaultValue={p.stock} className="w-20 rounded-lg bg-white/10 px-2 py-1.5 text-xs text-white outline-none" />
                        <button type="submit" className="rounded-lg bg-white px-3 py-1.5 text-[10px] font-black text-ink-900">
                          Save
                        </button>
                      </form>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "orders" && (
          <div className="space-y-3">
            {orders.map((o) => (
              <div key={o.id} className="rounded-2xl bg-white/5 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="text-sm font-black text-white">{o.orderNumber}</p>
                    <p className="text-[11px] text-white/50">
                      {formatDateTime(o.createdAt)} · {o.email || "guest"} · {o.paymentMethod.toUpperCase()} · {o.paymentStatus}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${statusTone(o.status)}`}>{ORDER_STATUS_LABEL[o.status] ?? o.status}</span>
                    <span className="text-sm font-black text-white">{rupees(o.total)}</span>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {o.items.map((i) => (
                    <span key={i.id} className="rounded-lg bg-white/8 px-2 py-1 text-[10px] text-white/70">
                      {i.title.slice(0, 30)} × {i.quantity}
                    </span>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {["confirmed", "packed", "shipped", "out_for_delivery", "delivered", "cancelled"].map((s) => (
                    <button
                      key={s}
                      type="button"
                      disabled={busy || o.status === s}
                      onClick={() => act({ action: "order.status", id: o.id, status: s }, "Order updated")}
                      className={`rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition ${
                        o.status === s ? "bg-white/15 text-white" : "bg-white/8 text-white/70 hover:bg-white/20"
                      }`}
                    >
                      {ORDER_STATUS_LABEL[s]?.replace(" at fulfilment centre", "") ?? s}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            {orders.length === 0 && <p className="rounded-2xl bg-white/5 p-6 text-center text-sm text-white/60">No orders yet.</p>}
          </div>
        )}

        {tab === "categories" && (
          <div className="space-y-4">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                const ok = await act({ action: "category.save", ...data }, "Category saved");
                if (ok) (e.target as HTMLFormElement).reset();
              }}
              className="grid gap-3 rounded-2xl bg-white/5 p-4 sm:grid-cols-4"
            >
              <Field name="name" label="Name" required />
              <Field name="icon" label="Emoji icon" />
              <Field name="tagline" label="Tagline" />
              <button type="submit" disabled={busy} className="self-end rounded-xl bg-white px-4 py-2.5 text-xs font-black text-ink-900">
                Add category
              </button>
            </form>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {categories.map((c) => (
                <div key={c.id} className="flex items-center gap-3 rounded-2xl bg-white/5 p-3">
                  <span aria-hidden className="text-xl">{c.icon}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-xs font-bold text-white">{c.name}</span>
                    <span className="block text-[10px] text-white/50">{c.slug}</span>
                  </span>
                  <button type="button" onClick={() => act({ action: "category.delete", id: c.id }, "Category removed")} className="text-[11px] font-bold text-rose-400">
                    Delete
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "coupons" && (
          <div className="space-y-4">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                const ok = await act({ action: "coupon.save", ...data, active: true }, "Coupon saved");
                if (ok) (e.target as HTMLFormElement).reset();
              }}
              className="grid gap-3 rounded-2xl bg-white/5 p-4 sm:grid-cols-6"
            >
              <Field name="code" label="Code" required />
              <Field name="title" label="Title" required />
              <label className="text-[11px] font-bold uppercase tracking-wide text-white/60">
                Type
                <select name="type" className="mt-1 w-full rounded-xl bg-white/8 px-3 py-2.5 text-sm font-normal text-white outline-none">
                  <option value="flat" className="text-ink-900">Flat ₹</option>
                  <option value="percent" className="text-ink-900">Percent %</option>
                </select>
              </label>
              <Field name="value" label="Value" type="number" required />
              <Field name="minCart" label="Min cart ₹" type="number" />
              <Field name="maxDiscount" label="Max discount ₹" type="number" />
              <button type="submit" disabled={busy} className="rounded-xl bg-white px-4 py-2.5 text-xs font-black text-ink-900 sm:col-span-6">
                Save coupon
              </button>
            </form>

            <div className="grid gap-2 sm:grid-cols-2">
              {coupons.map((c) => (
                <div key={c.id} className="rounded-2xl bg-white/5 p-4">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-mono text-sm font-black text-white">{c.code}</p>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${c.active ? "bg-emerald-500/20 text-emerald-300" : "bg-white/10 text-white/50"}`}>
                      {c.active ? "Active" : "Paused"}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-white/70">{c.title}</p>
                  <p className="text-[11px] text-white/40">
                    {c.type === "percent" ? `${c.value}% up to ${rupees(c.maxDiscount)}` : c.value === 0 ? "Free delivery" : `${rupees(c.value)} off`} · min {rupees(c.minCart)} · used {c.usedCount}×
                  </p>
                  <div className="mt-2 flex gap-3 text-[11px] font-bold">
                    <button type="button" onClick={() => act({ action: "coupon.toggle", id: c.id }, "Coupon updated")} className="text-brand-300">
                      {c.active ? "Pause" : "Activate"}
                    </button>
                    <button type="button" onClick={() => act({ action: "coupon.delete", id: c.id }, "Coupon deleted")} className="text-rose-400">
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "banners" && (
          <div className="space-y-4">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
                const ok = await act({ action: "banner.save", ...data, active: true }, "Banner saved");
                if (ok) (e.target as HTMLFormElement).reset();
              }}
              className="grid gap-3 rounded-2xl bg-white/5 p-4 sm:grid-cols-3"
            >
              <Field name="title" label="Title" required className="sm:col-span-2" />
              <Field name="subtitle" label="Subtitle" />
              <Field name="ctaText" label="CTA text" />
              <Field name="ctaHref" label="CTA link" />
              <Field name="gradient" label="Gradient classes" defaultValue="from-brand-600 to-flame-500" />
              <label className="text-[11px] font-bold uppercase tracking-wide text-white/60">
                Placement
                <select name="placement" className="mt-1 w-full rounded-xl bg-white/8 px-3 py-2.5 text-sm font-normal text-white outline-none">
                  {["hero", "strip", "tile"].map((p) => (
                    <option key={p} value={p} className="text-ink-900">
                      {p}
                    </option>
                  ))}
                </select>
              </label>
              <button type="submit" disabled={busy} className="self-end rounded-xl bg-white px-4 py-2.5 text-xs font-black text-ink-900">
                Publish banner
              </button>
            </form>

            <div className="grid gap-3 sm:grid-cols-2">
              {banners.map((b) => (
                <div key={b.id} className={`rounded-2xl bg-gradient-to-br ${b.gradient} p-4 text-white`}>
                  <p className="text-sm font-black">{b.title}</p>
                  <p className="text-[11px] opacity-85">{b.subtitle}</p>
                  <p className="mt-2 text-[10px] uppercase tracking-widest opacity-75">{b.placement} · {b.ctaText}</p>
                  <div className="mt-2 flex gap-3 text-[11px] font-bold">
                    <button type="button" onClick={() => act({ action: "banner.toggle", id: b.id }, "Banner updated")}>
                      {b.active ? "Hide" : "Publish"}
                    </button>
                    <button type="button" onClick={() => act({ action: "banner.delete", id: b.id }, "Banner removed")} className="text-rose-100 underline">
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === "users" && (
          <div className="overflow-x-auto rounded-2xl bg-white/5">
            <table className="w-full min-w-[680px] text-sm">
              <thead>
                <tr className="border-b border-white/10 text-left text-[10px] font-black uppercase tracking-widest text-white/60">
                  <th className="p-3">Customer</th>
                  <th className="p-3">Contact</th>
                  <th className="p-3">Orders</th>
                  <th className="p-3">Spent</th>
                  <th className="p-3">Role</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-b border-white/5 last:border-0">
                    <td className="p-3">
                      <p className="text-xs font-bold text-white">{u.name}</p>
                      <p className="text-[10px] text-white/50">Joined {formatDateTime(u.createdAt).split(",")[0]}</p>
                    </td>
                    <td className="p-3 text-xs text-white/70">
                      {u.email}
                      <br />
                      {u.phone ?? "—"}
                    </td>
                    <td className="p-3 text-xs font-bold text-white">{u.orders}</td>
                    <td className="p-3 text-xs text-white/70">{rupees(u.spent)}</td>
                    <td className="p-3">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${u.role === "admin" ? "bg-brand-500/25 text-brand-200" : "bg-white/10 text-white/70"}`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        type="button"
                        onClick={() => act({ action: "user.role", id: u.id, role: u.role === "admin" ? "customer" : "admin" }, "Role updated")}
                        className="text-[11px] font-bold text-brand-300"
                      >
                        {u.role === "admin" ? "Revoke admin" : "Make admin"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "returns" && (
          <div className="space-y-3">
            {returns.length === 0 && <p className="rounded-2xl bg-white/5 p-6 text-center text-sm text-white/60">No return requests.</p>}
            {returns.map((r) => (
              <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-white/5 p-4">
                <div>
                  <p className="text-sm font-bold text-white">
                    #{r.id} · {r.orderNumber} · {r.kind}
                  </p>
                  <p className="text-[11px] text-white/50">
                    {r.reason} · {r.comments || "no comments"} · refund {rupees(r.refundAmount)} · {formatDateTime(r.createdAt)}
                  </p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {["approved", "pickup_scheduled", "refunded", "rejected"].map((s) => (
                    <button
                      key={s}
                      type="button"
                      disabled={busy}
                      onClick={() => act({ action: "return.status", id: r.id, status: s }, "Request updated")}
                      className={`rounded-lg px-2.5 py-1.5 text-[10px] font-bold ${r.status === s ? "bg-white/20 text-white" : "bg-white/8 text-white/70 hover:bg-white/20"}`}
                    >
                      {s.replace(/_/g, " ")}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Field({
  name,
  label,
  defaultValue,
  type = "text",
  required,
  className = "",
  multiline,
}: {
  name: string;
  label: string;
  defaultValue?: string | number;
  type?: string;
  required?: boolean;
  className?: string;
  multiline?: boolean;
}) {
  const shared =
    "mt-1 w-full rounded-xl bg-white/8 px-3 py-2.5 text-sm font-normal normal-case text-white outline-none placeholder:text-white/30";
  return (
    <label className={`text-[11px] font-bold uppercase tracking-wide text-white/60 ${className}`}>
      {label}
      {multiline ? (
        <textarea name={name} defaultValue={defaultValue} required={required} rows={3} className={shared} />
      ) : (
        <input name={name} type={type} step={type === "number" ? "any" : undefined} defaultValue={defaultValue} required={required} className={shared} />
      )}
    </label>
  );
}
