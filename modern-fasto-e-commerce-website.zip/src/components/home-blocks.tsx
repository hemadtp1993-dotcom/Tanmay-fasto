"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { Banner } from "@/db/schema";

export function HeroCarousel({ slides }: { slides: Banner[] }) {
  const [index, setIndex] = useState(0);
  const count = slides.length || 1;

  useEffect(() => {
    if (count < 2) return;
    const timer = window.setInterval(() => setIndex((i) => (i + 1) % count), 5200);
    return () => window.clearInterval(timer);
  }, [count]);

  if (!slides.length) return null;

  return (
    <div className="relative">
      <div className="relative h-[248px] overflow-hidden rounded-3xl sm:h-[300px] lg:h-[360px]">
        {slides.map((slide, i) => (
          <div
            key={slide.id}
            aria-hidden={i !== index}
            className={`absolute inset-0 bg-gradient-to-br ${slide.gradient} transition-all duration-700 ease-out ${
              i === index ? "translate-x-0 opacity-100" : "pointer-events-none translate-x-6 opacity-0"
            }`}
          >
            <div
              className="absolute -right-10 -top-16 h-64 w-64 rounded-full bg-white/15 blur-2xl sm:h-80 sm:w-80"
              style={{ animation: "fasto-spark 6s ease-in-out infinite" }}
            />
            <div className="absolute -bottom-20 left-1/3 h-56 w-56 rounded-full bg-black/10 blur-2xl" />
            <div className="relative flex h-full flex-col justify-center gap-3 px-6 sm:px-12 lg:px-16">
              <span className="w-fit rounded-full bg-white/20 px-3 py-1 text-[11px] font-black uppercase tracking-[0.16em] text-white backdrop-blur">
                FASTO exclusive
              </span>
              <h2 className="max-w-2xl text-2xl font-black leading-tight tracking-tight text-white sm:text-4xl lg:text-[2.75rem]">
                {slide.title}
              </h2>
              <p className="max-w-xl text-sm text-white/90 sm:text-base">{slide.subtitle}</p>
              <Link
                href={slide.ctaHref}
                className="mt-1 w-fit rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-ink-900 shadow-lg transition hover:scale-[1.03] active:scale-95"
              >
                {slide.ctaText} →
              </Link>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-3 flex items-center justify-center gap-2">
        {slides.map((s, i) => (
          <button
            key={s.id}
            type="button"
            aria-label={`Go to slide ${i + 1}`}
            onClick={() => setIndex(i)}
            className={`h-1.5 rounded-full transition-all ${i === index ? "w-8 bg-brand-600" : "w-3 bg-ink-400/40"}`}
          />
        ))}
      </div>
    </div>
  );
}

export function Countdown({ endsAt }: { endsAt: string }) {
  const [left, setLeft] = useState(() => new Date(endsAt).getTime() - Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setLeft(new Date(endsAt).getTime() - Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [endsAt]);

  const total = Math.max(0, left);
  const h = Math.floor(total / 3600000);
  const m = Math.floor((total % 3600000) / 60000);
  const s = Math.floor((total % 60000) / 1000);
  const pad = (n: number) => String(n).padStart(2, "0");

  return (
    <span className="inline-flex items-center gap-1 font-mono text-sm font-bold text-flame-600 dark:text-flame-300">
      {[pad(h), pad(m), pad(s)].map((v, i) => (
        <span key={i} className="rounded-md bg-flame-500/12 px-1.5 py-0.5">
          {v}
        </span>
      ))}
    </span>
  );
}

export function CategoryStrip({
  items,
}: {
  items: Array<{ slug: string; name: string; icon: string; tagline: string | null }>;
}) {
  return (
    <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
      {items.map((c, i) => (
        <Link
          key={c.slug}
          href={`/category/${c.slug}`}
          className="lift panel group flex w-[92px] shrink-0 flex-col items-center gap-2 rounded-2xl px-2 py-3 text-center sm:w-[108px]"
          style={{ animation: "fasto-rise .5s ease both", animationDelay: `${i * 0.03}s` }}
        >
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-brand-500/15 to-flame-500/15 text-2xl transition group-hover:scale-110">
            {c.icon}
          </span>
          <span className="text-[11px] font-bold leading-tight text-ink-800 dark:text-ink-100">{c.name.split(" & ")[0]}</span>
        </Link>
      ))}
    </div>
  );
}

export function StatStrip() {
  const stats = [
    ["4.2M+", "Happy shoppers"],
    ["19,000+", "Pin codes served"],
    ["1.2M+", "Products listed"],
    ["4.8★", "App rating"],
  ];
  return (
    <div className="panel grid grid-cols-2 gap-4 rounded-3xl p-5 sm:grid-cols-4">
      {stats.map(([value, label]) => (
        <div key={label} className="text-center">
          <p className="bg-gradient-to-r from-brand-600 to-flame-500 bg-clip-text text-xl font-black text-transparent sm:text-2xl">
            {value}
          </p>
          <p className="text-[11px] font-semibold uppercase tracking-wide text-ink-400">{label}</p>
        </div>
      ))}
    </div>
  );
}
