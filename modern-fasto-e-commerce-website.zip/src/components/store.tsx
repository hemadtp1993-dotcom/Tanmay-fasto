"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type SessionUser = {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  role: string;
  avatarUrl: string | null;
  referralCode: string | null;
  walletBalance: number;
  fastoCoins: number;
};

type Toast = { id: number; message: string; tone: "success" | "error" | "info" };

type ShopContextValue = {
  ready: boolean;
  cartCount: number;
  wishlistCount: number;
  user: SessionUser | null;
  refresh: () => Promise<void>;
  toast: (message: string, tone?: Toast["tone"]) => void;
  requireLogin: (next?: string) => boolean;
};

const ShopContext = createContext<ShopContextValue | null>(null);

export function ShopProvider({ children }: { children: ReactNode }) {
  const [cartCount, setCartCount] = useState(0);
  const [wishlistCount, setWishlistCount] = useState(0);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/summary", { cache: "no-store" });
      if (!res.ok) return;
      const data = (await res.json()) as { cartCount: number; wishlistCount: number; user: SessionUser | null };
      setCartCount(data.cartCount ?? 0);
      setWishlistCount(data.wishlistCount ?? 0);
      setUser(data.user ?? null);
    } catch {
      /* offline — keep last known values */
    } finally {
      setReady(true);
    }
  }, []);

  useEffect(() => {
    void refresh();
    const handler = () => void refresh();
    window.addEventListener("fasto:refresh", handler);
    window.addEventListener("focus", handler);
    return () => {
      window.removeEventListener("fasto:refresh", handler);
      window.removeEventListener("focus", handler);
    };
  }, [refresh]);

  const toast = useCallback((message: string, tone: Toast["tone"] = "success") => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev.slice(-2), { id, message, tone }]);
    window.setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 2600);
  }, []);

  const requireLogin = useCallback(
    (next = "/account") => {
      if (user) return true;
      toast("Please sign in to continue", "info");
      window.location.href = `/login?next=${encodeURIComponent(next)}`;
      return false;
    },
    [user, toast],
  );

  const value = useMemo(
    () => ({ ready, cartCount, wishlistCount, user, refresh, toast, requireLogin }),
    [ready, cartCount, wishlistCount, user, refresh, toast, requireLogin],
  );

  return (
    <ShopContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[90] flex flex-col items-center gap-2 px-4 sm:bottom-8">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`animate-pop pointer-events-auto flex max-w-sm items-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold shadow-float ${
              t.tone === "error"
                ? "bg-rose-600 text-white"
                : t.tone === "info"
                  ? "bg-ink-900 text-white dark:bg-ink-800"
                  : "bg-emerald-600 text-white"
            }`}
          >
            <span aria-hidden>{t.tone === "error" ? "⚠️" : t.tone === "info" ? "ℹ️" : "✅"}</span>
            {t.message}
          </div>
        ))}
      </div>
    </ShopContext.Provider>
  );
}

export function useShop() {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error("useShop must be used inside ShopProvider");
  return ctx;
}

export function bump() {
  window.dispatchEvent(new Event("fasto:refresh"));
}
