"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import type { Product } from "@/db/schema";
import { discountPercent, rupees } from "@/lib/format";
import { EmptyState } from "./ui";

export default function CompareBoard() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    let ids: number[] = [];
    try {
      ids = JSON.parse(localStorage.getItem("fasto_compare") ?? "[]") as number[];
    } catch {
      ids = [];
    }
    if (!ids.length) {
      setProducts([]);
      setLoading(false);
      return;
    }
    const res = await fetch(`/api/products?ids=${ids.join(",")}`);
    const data = (await res.json()) as { products: Product[] };
    setProducts(data.products ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const handler = () => void load();
    window.addEventListener("fasto:compare", handler);
    return () => window.removeEventListener("fasto:compare", handler);
  }, [load]);

  function remove(id: number) {
    const ids = JSON.parse(localStorage.getItem("fasto_compare") ?? "[]") as number[];
    localStorage.setItem("fasto_compare", JSON.stringify(ids.filter((i) => i !== id)));
    void load();
  }

  if (loading) return <div className="shimmer h-64 rounded-3xl" />;

  if (!products.length)
    return (
      <EmptyState
        icon="⇄"
        title="Nothing to compare yet"
        body="Tap the ⇄ icon on up to 4 products and we'll line up their price, rating, specs and delivery for you."
        action={
          <Link href="/products" className="rounded-xl bg-brand-600 px-5 py-3 text-sm font-bold text-white">
            Browse products
          </Link>
        }
      />
    );

  const rows: Array<{ label: string; render: (p: Product) => string }> = [
    { label: "Price", render: (p) => rupees(p.price) },
    { label: "Original price", render: (p) => rupees(p.mrp) },
    { label: "Discount", render: (p) => `${discountPercent(p.mrp, p.price)}% off` },
    { label: "Rating", render: (p) => `${p.rating.toFixed(1)} ★ (${p.reviewCount.toLocaleString("en-IN")})` },
    { label: "Brand", render: (p) => p.brand },
    { label: "Availability", render: (p) => (p.stock > 0 ? `${p.stock} in stock` : "Out of stock") },
    { label: "Colours", render: (p) => (p.colors.length ? p.colors.join(", ") : "—") },
    { label: "Sizes", render: (p) => (p.sizes.length ? p.sizes.join(", ") : "—") },
    { label: "Key spec", render: (p) => (p.specs[0] ? `${p.specs[0].label}: ${p.specs[0].value}` : "—") },
    { label: "Shoppers bought", render: (p) => `${p.soldCount.toLocaleString("en-IN")}+` },
  ];

  return (
    <div className="panel overflow-x-auto rounded-3xl">
      <table className="w-full min-w-[640px] text-sm">
        <caption className="sr-only">Product comparison</caption>
        <thead>
          <tr className="border-b hairline">
            <th scope="col" className="w-40 p-4 text-left text-[11px] font-black uppercase tracking-wide text-ink-400">
              Compare ({products.length}/4)
            </th>
            {products.map((p) => (
              <th key={p.id} scope="col" className="p-4 text-left align-top">
                <div className="flex flex-col gap-2">
                  <Link href={`/product/${p.slug}`} className="block aspect-square w-full max-w-[140px] overflow-hidden rounded-2xl bg-ink-50 dark:bg-ink-900">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={p.images[0]} alt={p.title} className="h-full w-full object-cover" loading="lazy" />
                  </Link>
                  <Link href={`/product/${p.slug}`} className="line-clamp-2 text-xs font-bold text-ink-900 hover:text-brand-600 dark:text-white">
                    {p.title}
                  </Link>
                  <button type="button" onClick={() => remove(p.id)} className="w-fit text-[11px] font-bold text-rose-600">
                    ✕ Remove
                  </button>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={row.label} className={`border-b last:border-0 hairline ${i % 2 ? "bg-ink-400/4" : ""}`}>
              <th scope="row" className="p-4 text-left text-xs font-bold text-ink-500 dark:text-ink-300">
                {row.label}
              </th>
              {products.map((p) => (
                <td key={p.id} className="p-4 text-ink-800 dark:text-ink-100">
                  {row.render(p)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
