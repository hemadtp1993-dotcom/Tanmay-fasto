"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import type { Category } from "@/db/schema";
import { rupees } from "@/lib/format";
import { FastoLogo } from "./logo";
import { bump, useShop } from "./store";
import { ThemeToggle } from "./theme-toggle";

type Suggestion = { id: number; slug: string; title: string; brand: string; price: number; images: string[] };

const CITIES = ["Bengaluru 560038", "Mumbai 400001", "Delhi 110001", "Hyderabad 500081", "Pune 411045", "Chennai 600002", "Kolkata 700016", "Ahmedabad 380015"];

const OFFERS = [
  "⚡ Mega Saver Days — up to 70% off sitewide",
  "🚚 Free delivery on orders above ₹499",
  "🎁 Use code FASTO100 for flat ₹100 off your first order",
  "🔄 7-day easy returns & refunds",
  "🏦 Extra 10% off on UPI payments",
];

export default function Header({ categories, popular }: { categories: Category[]; popular: string[] }) {
  const router = useRouter();
  const { cartCount, wishlistCount, user } = useShop();
  const [term, setTerm] = useState("");
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [recent, setRecent] = useState<string[]>([]);
  const [city, setCity] = useState(CITIES[0]);
  const [cityOpen, setCityOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      setRecent(JSON.parse(localStorage.getItem("fasto_recent") ?? "[]") as string[]);
    } catch {
      setRecent([]);
    }
    const saved = localStorage.getItem("fasto_city");
    if (saved) setCity(saved);
  }, []);

  useEffect(() => {
    if (!term.trim()) {
      setSuggestions([]);
      return;
    }
    const handle = window.setTimeout(async () => {
      try {
        const res = await fetch(`/api/search/suggest?q=${encodeURIComponent(term)}`);
        const data = (await res.json()) as { items: Suggestion[] };
        setSuggestions(data.items ?? []);
      } catch {
        setSuggestions([]);
      }
    }, 180);
    return () => window.clearTimeout(handle);
  }, [term]);

  useEffect(() => {
    function onClick(event: MouseEvent) {
      if (!boxRef.current?.contains(event.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  function submit(value: string) {
    const q = value.trim();
    if (!q) return;
    const next = [q, ...recent.filter((r) => r.toLowerCase() !== q.toLowerCase())].slice(0, 6);
    setRecent(next);
    localStorage.setItem("fasto_recent", JSON.stringify(next));
    setOpen(false);
    router.push(`/products?q=${encodeURIComponent(q)}`);
  }

  function pickCity(value: string) {
    setCity(value);
    localStorage.setItem("fasto_city", value);
    setCityOpen(false);
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    bump();
    router.push("/");
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-50">
      <div className="overflow-hidden bg-ink-950 text-white dark:bg-black">
        <div className="flex w-max animate-[marquee_28s_linear_infinite] gap-10 py-1.5 text-[11px] font-medium">
          {[...OFFERS, ...OFFERS].map((o, i) => (
            <span key={i} className="whitespace-nowrap opacity-90">
              {o}
            </span>
          ))}
        </div>
      </div>

      <div className="border-b bg-[var(--panel)]/95 backdrop-blur hairline">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-3 py-2.5 sm:px-5 lg:gap-6">
          <button
            type="button"
            className="grid h-9 w-9 place-items-center rounded-full border text-lg hairline lg:hidden"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Browse categories"
            aria-expanded={menuOpen}
          >
            ☰
          </button>

          <FastoLogo />

          <div className="relative hidden lg:block">
            <button
              type="button"
              onClick={() => setCityOpen((v) => !v)}
              className="flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-left text-xs transition hover:bg-ink-400/10"
            >
              <span aria-hidden className="text-base">📍</span>
              <span className="leading-tight">
                <span className="block text-[10px] uppercase tracking-wide text-ink-400">Deliver to</span>
                <span className="block max-w-[130px] truncate font-bold text-ink-800 dark:text-white">{city}</span>
              </span>
            </button>
            {cityOpen && (
              <div className="panel animate-pop absolute left-0 top-12 z-50 w-64 rounded-2xl p-2 shadow-card">
                <p className="px-2 pb-1 text-[11px] font-bold uppercase tracking-wide text-ink-400">Select your city</p>
                {CITIES.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => pickCity(c)}
                    className={`block w-full rounded-lg px-2.5 py-2 text-left text-sm font-medium transition hover:bg-brand-500/10 ${
                      c === city ? "text-brand-600 dark:text-brand-300" : "text-ink-600 dark:text-ink-200"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div ref={boxRef} className="relative flex-1">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                submit(term);
              }}
              className="flex items-center gap-2 rounded-2xl border bg-[var(--surface)] px-3 py-2 hairline focus-within:border-brand-500"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="shrink-0 text-ink-400" aria-hidden>
                <circle cx="11" cy="11" r="7" />
                <path d="m20 20-3.5-3.5" />
              </svg>
              <input
                value={term}
                onChange={(e) => {
                  setTerm(e.target.value);
                  setOpen(true);
                }}
                onFocus={() => setOpen(true)}
                placeholder="Search for mobiles, fashion, beauty & more"
                aria-label="Search products"
                className="w-full bg-transparent text-sm outline-none placeholder:text-ink-400"
              />
              {term && (
                <button type="button" onClick={() => setTerm("")} aria-label="Clear search" className="text-ink-400 hover:text-ink-600">
                  ✕
                </button>
              )}
              <button type="submit" className="hidden rounded-xl bg-brand-600 px-3.5 py-1.5 text-xs font-bold text-white transition hover:bg-brand-700 sm:block">
                Search
              </button>
            </form>

            {open && (
              <div className="panel animate-pop absolute inset-x-0 top-14 z-50 max-h-[70vh] overflow-y-auto rounded-2xl p-3 shadow-card">
                {term.trim() === "" ? (
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-ink-400">Recent searches</p>
                      {recent.length === 0 ? (
                        <p className="text-sm text-ink-400">No recent searches yet.</p>
                      ) : (
                        <div className="flex flex-wrap gap-1.5">
                          {recent.map((r) => (
                            <button key={r} type="button" onClick={() => submit(r)} className="rounded-full bg-ink-400/10 px-3 py-1.5 text-xs font-semibold text-ink-600 dark:text-ink-200">
                              {r}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                    <div>
                      <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-ink-400">Popular right now</p>
                      <div className="flex flex-wrap gap-1.5">
                        {popular.map((p) => (
                          <button key={p} type="button" onClick={() => submit(p)} className="rounded-full bg-brand-500/10 px-3 py-1.5 text-xs font-semibold text-brand-600 dark:text-brand-300">
                            🔥 {p}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : suggestions.length === 0 ? (
                  <p className="px-1 py-3 text-sm text-ink-400">No matches. Try a different keyword.</p>
                ) : (
                  <ul className="divide-y hairline">
                    {suggestions.map((s) => (
                      <li key={s.id}>
                        <Link
                          href={`/product/${s.slug}`}
                          onClick={() => setOpen(false)}
                          className="flex items-center gap-3 rounded-xl px-1.5 py-2 transition hover:bg-ink-400/8"
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={s.images[0]} alt="" loading="lazy" className="h-11 w-11 rounded-lg object-cover" />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-sm font-semibold text-ink-900 dark:text-white">{s.title}</span>
                            <span className="block text-[11px] text-ink-400">in {s.brand}</span>
                          </span>
                          <span className="text-sm font-bold text-ink-900 dark:text-white">{rupees(s.price)}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
                {term.trim() !== "" && (
                  <button type="button" onClick={() => submit(term)} className="mt-2 w-full rounded-xl bg-brand-500/10 py-2 text-xs font-bold text-brand-600 dark:text-brand-300">
                    See all results for “{term}”
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center gap-1 sm:gap-2">
            <ThemeToggle className="hidden sm:grid" />

            <div className="relative hidden lg:block" onMouseEnter={() => setAccountOpen(true)} onMouseLeave={() => setAccountOpen(false)}>
              <Link href={user ? "/account" : "/login"} className="flex items-center gap-2 rounded-xl px-2.5 py-2 text-xs transition hover:bg-ink-400/10">
                <span aria-hidden className="text-base">👤</span>
                <span className="leading-tight">
                  <span className="block text-[10px] uppercase tracking-wide text-ink-400">
                    {user ? "Hello," : "Account &"}
                  </span>
                  <span className="block font-bold text-ink-800 dark:text-white">{user ? user.name.split(" ")[0] : "Orders"}</span>
                </span>
              </Link>
              {accountOpen && (
                <div className="panel animate-pop absolute right-0 top-full z-50 w-60 rounded-2xl p-2 shadow-card">
                  {user ? (
                    <>
                      <div className="rounded-xl bg-brand-500/8 px-3 py-2">
                        <p className="text-sm font-bold text-ink-900 dark:text-white">{user.name}</p>
                        <p className="truncate text-[11px] text-ink-400">{user.email}</p>
                      </div>
                      {[
                        ["/account", "My account"],
                        ["/account?tab=orders", "My orders"],
                        ["/account?tab=wishlist", "My wishlist"],
                        ["/account?tab=coupons", "Coupons & rewards"],
                        ["/account?tab=returns", "Returns & refunds"],
                      ].map(([href, label]) => (
                        <Link key={href} href={href} className="block rounded-lg px-3 py-2 text-sm font-medium text-ink-600 transition hover:bg-ink-400/10 dark:text-ink-200">
                          {label}
                        </Link>
                      ))}
                      {user.role === "admin" && (
                        <Link href="/admin" className="block rounded-lg px-3 py-2 text-sm font-bold text-brand-600 dark:text-brand-300">
                          Admin dashboard →
                        </Link>
                      )}
                      <button type="button" onClick={logout} className="mt-1 w-full rounded-lg px-3 py-2 text-left text-sm font-bold text-rose-600 hover:bg-rose-500/10">
                        Log out
                      </button>
                    </>
                  ) : (
                    <div className="p-2">
                      <p className="mb-3 text-sm text-ink-400">Sign in to see your orders, wishlist and personalised picks.</p>
                      <Link href="/login" className="block rounded-xl bg-brand-600 py-2.5 text-center text-sm font-bold text-white">
                        Sign in
                      </Link>
                      <p className="mt-2 text-center text-xs text-ink-400">
                        New here?{" "}
                        <Link href="/signup" className="font-bold text-brand-600">
                          Create account
                        </Link>
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>

            <Link href="/compare" className="hidden h-10 items-center gap-1.5 rounded-xl px-2.5 text-xs font-bold text-ink-600 transition hover:bg-ink-400/10 dark:text-ink-200 xl:flex">
              <span aria-hidden className="text-base">⇄</span> Compare
            </Link>

            <Link href="/wishlist" className="relative grid h-10 w-10 place-items-center rounded-xl transition hover:bg-ink-400/10" aria-label="Wishlist">
              <span aria-hidden className="text-lg">❤️</span>
              {wishlistCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4.5 min-w-[18px] place-items-center rounded-full bg-rose-500 px-1 text-[10px] font-black text-white">
                  {wishlistCount}
                </span>
              )}
            </Link>

            <Link href="/cart" className="relative flex h-10 items-center gap-1.5 rounded-xl px-2.5 font-bold text-ink-800 transition hover:bg-ink-400/10 dark:text-white" aria-label="Cart">
              <span aria-hidden className="text-lg">🛒</span>
              <span className="hidden text-xs sm:block">Cart</span>
              {cartCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid h-4.5 min-w-[18px] place-items-center rounded-full bg-brand-600 px-1 text-[10px] font-black text-white">
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        <nav className="hidden border-t hairline lg:block">
          <div className="no-scrollbar mx-auto flex max-w-7xl items-center gap-1 overflow-x-auto px-5 py-1.5">
            <Link href="/products" className="whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-bold text-flame-600 hover:bg-flame-500/10">
              ⚡ Today&apos;s deals
            </Link>
            {categories.map((c) => (
              <Link
                key={c.slug}
                href={`/category/${c.slug}`}
                className="whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold text-ink-600 transition hover:bg-brand-500/10 hover:text-brand-600 dark:text-ink-200"
              >
                <span aria-hidden className="mr-1">{c.icon}</span>
                {c.name}
              </Link>
            ))}
          </div>
        </nav>

        {menuOpen && (
          <div className="animate-pop border-t bg-[var(--panel)] px-4 py-3 hairline lg:hidden">
            <div className="mb-3 flex items-center gap-2">
              <span aria-hidden>📍</span>
              <select
                value={city}
                onChange={(e) => pickCity(e.target.value)}
                aria-label="Select delivery city"
                className="flex-1 rounded-lg border bg-transparent px-2 py-1.5 text-sm font-semibold hairline"
              >
                {CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Link href="/products" onClick={() => setMenuOpen(false)} className="rounded-xl bg-flame-500/12 px-3 py-2.5 text-sm font-bold text-flame-600">
                ⚡ Today&apos;s deals
              </Link>
              <Link href="/compare" onClick={() => setMenuOpen(false)} className="rounded-xl bg-ink-400/10 px-3 py-2.5 text-sm font-bold text-ink-700 dark:text-ink-100">
                ⇄ Compare
              </Link>
              {categories.map((c) => (
                <Link
                  key={c.slug}
                  href={`/category/${c.slug}`}
                  onClick={() => setMenuOpen(false)}
                  className="rounded-xl bg-ink-400/8 px-3 py-2.5 text-sm font-semibold text-ink-700 dark:text-ink-100"
                >
                  <span aria-hidden className="mr-1">{c.icon}</span>
                  {c.name}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
