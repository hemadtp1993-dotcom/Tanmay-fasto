"use client";

import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import type { Category } from "@/db/schema";
import BottomNav from "./bottom-nav";
import Footer from "./footer";
import Header from "./header";
import SupportWidget from "./support-widget";

export default function Shell({
  categories,
  popular,
  children,
}: {
  categories: Category[];
  popular: string[];
  children: ReactNode;
}) {
  const pathname = usePathname();
  const bare = pathname.startsWith("/admin");

  return (
    <>
      {!bare && <Header categories={categories} popular={popular} />}
      <main className={bare ? "" : "mx-auto min-h-[60vh] w-full max-w-7xl px-3 pb-10 pt-4 sm:px-5 lg:px-6"}>{children}</main>
      {!bare && <Footer />}
      {!bare && <BottomNav />}
      {!bare && <SupportWidget />}
    </>
  );
}
