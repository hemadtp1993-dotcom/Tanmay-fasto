"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { FastoMark } from "./logo";
import { bump, useShop } from "./store";

type Mode = "login" | "signup" | "forgot";

export default function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") ?? "/account";
  const { toast } = useShop();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [referral, setReferral] = useState("");
  const [otpSent, setOtpSent] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [googleOpen, setGoogleOpen] = useState(false);
  const [googleEmail, setGoogleEmail] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);

    const endpoint = "/api/auth";
    const payload =
      mode === "login"
        ? { action: "login", email, password }
        : mode === "signup"
          ? { action: "signup", name, email, phone, password, referredBy: referral }
          : { action: "forgot", email };

    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = (await res.json()) as { ok: boolean; error?: string; message?: string; resetToken?: string };

    if (!data.ok) {
      setError(data.error ?? "Something went wrong. Please try again.");
      setBusy(false);
      return;
    }

    if (mode === "forgot") {
      setNotice(`${data.message ?? "Check your inbox."} ${data.resetToken ? `Sandbox reset link: /reset-password?token=${data.resetToken}` : ""}`);
      if (data.resetToken) setOtpSent(data.resetToken);
      setBusy(false);
      return;
    }

    toast(mode === "login" ? "Welcome back!" : "Account created 🎉");
    bump();
    router.push(next);
    router.refresh();
  }

  async function googleSignIn() {
    setBusy(true);
    setError(null);
    const res = await fetch("/api/auth", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "google", email: googleEmail || "fasto.shopper@gmail.com" }),
    });
    const data = (await res.json()) as { ok: boolean; error?: string };
    if (!data.ok) {
      setError(data.error ?? "Google sign-in failed");
      setBusy(false);
      return;
    }
    toast("Signed in with Google");
    bump();
    router.push(next);
    router.refresh();
  }

  const title = mode === "login" ? "Welcome back" : mode === "signup" ? "Create your FASTO account" : "Reset your password";

  return (
    <div className="mx-auto grid w-full max-w-5xl gap-8 py-6 lg:grid-cols-[1fr_1.05fr] lg:items-center">
      <aside className="relative hidden overflow-hidden rounded-3xl bg-gradient-to-br from-brand-700 via-brand-600 to-flame-500 p-8 text-white lg:block">
        <div className="absolute -right-10 -top-10 h-48 w-48 rounded-full bg-white/15 blur-2xl" />
        <div className="absolute -bottom-16 -left-8 h-48 w-48 rounded-full bg-black/15 blur-2xl" />
        <div className="relative">
          <FastoMark className="h-12 w-12" />
          <h2 className="mt-6 text-3xl font-black leading-tight">
            India&apos;s fastest
            <br /> way to shop.
          </h2>
          <ul className="mt-7 space-y-3.5 text-sm">
            {[
              ["🚚", "Same-day delivery in 14 metros"],
              ["🔐", "Secure UPI, card & COD payments"],
              ["↩️", "7-day no-question returns"],
              ["🎁", "₹100 welcome coupon on signup"],
              ["⭐", "4.8/5 from 42 lakh shoppers"],
            ].map(([icon, text]) => (
              <li key={text} className="flex items-center gap-3">
                <span aria-hidden className="grid h-8 w-8 place-items-center rounded-xl bg-white/20 text-base">
                  {icon}
                </span>
                {text}
              </li>
            ))}
          </ul>
          <p className="mt-8 text-xs text-white/70">
            By continuing you agree to FASTO&apos;s <Link href="/terms" className="underline">Terms</Link> and{" "}
            <Link href="/privacy" className="underline">Privacy Policy</Link>.
          </p>
        </div>
      </aside>

      <div className="panel rounded-3xl p-6 shadow-card sm:p-8">
        <div className="mb-6 flex items-center gap-3 lg:hidden">
          <FastoMark className="h-10 w-10" />
          <p className="text-lg font-extrabold text-ink-900 dark:text-white">
            FAST<span className="text-flame-500">O</span>
          </p>
        </div>

        <h1 className="text-2xl font-black tracking-tight text-ink-900 dark:text-white">{title}</h1>
        <p className="mt-1 text-sm text-ink-400">
          {mode === "login"
            ? "Sign in to see your orders, wishlist and personalised picks."
            : mode === "signup"
              ? "It takes less than a minute. No card required."
              : "We'll send a secure, single-use reset link to your email."}
        </p>

        <button
          type="button"
          onClick={() => setGoogleOpen((v) => !v)}
          className="mt-6 flex w-full items-center justify-center gap-3 rounded-xl border bg-white px-4 py-3 text-sm font-bold text-ink-800 transition hover:shadow-md dark:bg-ink-800 dark:text-white hairline"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden>
            <path fill="#4285F4" d="M23 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.6z" />
            <path fill="#34A853" d="M12 24c3.1 0 5.7-1 7.6-2.8l-3.7-2.9c-1 .7-2.3 1.1-3.9 1.1-3 0-5.5-2-6.4-4.7H1.8v3A12 12 0 0 0 12 24z" />
            <path fill="#FBBC05" d="M5.6 14.7a7.2 7.2 0 0 1 0-4.6v-3H1.8a12 12 0 0 0 0 10.6l3.8-3z" />
            <path fill="#EA4335" d="M12 4.8c1.7 0 3.2.6 4.4 1.7l3.3-3.3A11.6 11.6 0 0 0 12 0 12 12 0 0 0 1.8 6.1l3.8 3C6.5 6.7 9 4.8 12 4.8z" />
          </svg>
          Continue with Google
        </button>

        {googleOpen && (
          <div className="animate-pop mt-3 rounded-2xl border bg-ink-400/5 p-3 hairline">
            <p className="text-[11px] leading-snug text-ink-400">
              Sandbox mode: enter any Google email to simulate OAuth. Set <code className="font-mono">GOOGLE_CLIENT_ID</code> to
              enable live Google Identity Services verification.
            </p>
            <div className="mt-2 flex gap-2">
              <input
                value={googleEmail}
                onChange={(e) => setGoogleEmail(e.target.value)}
                placeholder="you@gmail.com"
                type="email"
                className="flex-1 rounded-xl border bg-transparent px-3 py-2 text-sm outline-none hairline"
              />
              <button type="button" onClick={googleSignIn} disabled={busy} className="rounded-xl bg-brand-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-60">
                Continue
              </button>
            </div>
          </div>
        )}

        <div className="my-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-wide text-ink-400">
          <span className="h-px flex-1 bg-ink-400/25" />
          or use your email
          <span className="h-px flex-1 bg-ink-400/25" />
        </div>

        <form onSubmit={submit} className="space-y-3.5">
          {mode === "signup" && (
            <Field label="Full name" value={name} onChange={setName} placeholder="Aarav Mehta" autoComplete="name" required />
          )}
          <Field label="Email address" type="email" value={email} onChange={setEmail} placeholder="you@example.com" autoComplete="email" required />
          {mode === "signup" && (
            <Field label="Mobile number (optional)" type="tel" value={phone} onChange={setPhone} placeholder="98765 43210" autoComplete="tel" />
          )}
          {mode !== "forgot" && (
            <div>
              <label className="mb-1.5 block text-xs font-bold text-ink-600 dark:text-ink-200" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === "signup" ? "8+ chars with a letter & number" : "••••••••"}
                autoComplete={mode === "signup" ? "new-password" : "current-password"}
                required
                minLength={8}
                className="w-full rounded-xl border bg-transparent px-3.5 py-2.5 text-sm outline-none transition focus:border-brand-500 hairline"
              />
            </div>
          )}
          {mode === "signup" && (
            <Field label="Referral code (optional)" value={referral} onChange={setReferral} placeholder="FRIEND200" />
          )}

          {mode === "login" && (
            <div className="flex justify-end">
              <Link href="/forgot-password" className="text-xs font-bold text-brand-600 dark:text-brand-300">
                Forgot password?
              </Link>
            </div>
          )}

          {error && <p className="rounded-xl bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-600">{error}</p>}
          {notice && (
            <div className="rounded-xl bg-emerald-500/10 px-3 py-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400">
              {notice}
              {otpSent && (
                <Link href={`/reset-password?token=${otpSent}`} className="mt-1 block font-bold underline">
                  Open reset link →
                </Link>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-xl bg-brand-600 py-3 text-sm font-bold text-white shadow-float transition hover:bg-brand-700 active:scale-[0.99] disabled:opacity-60"
          >
            {busy ? "Please wait…" : mode === "login" ? "Sign in securely" : mode === "signup" ? "Create account" : "Send reset link"}
          </button>
        </form>

        <p className="mt-5 text-center text-sm text-ink-400">
          {mode === "signup" ? (
            <>
              Already have an account?{" "}
              <Link href="/login" className="font-bold text-brand-600 dark:text-brand-300">
                Sign in
              </Link>
            </>
          ) : (
            <>
              New to FASTO?{" "}
              <Link href="/signup" className="font-bold text-brand-600 dark:text-brand-300">
                Create an account
              </Link>
            </>
          )}
        </p>

        {mode === "login" && (
          <div className="mt-5 rounded-2xl bg-ink-400/8 p-3 text-[11px] leading-relaxed text-ink-400">
            <p className="font-bold uppercase tracking-wide">Demo accounts</p>
            <p>Shopper — demo@fasto.in / Demo@123</p>
            <p>Admin — admin@fasto.in / Admin@123</p>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  autoComplete,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  autoComplete?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-bold text-ink-600 dark:text-ink-200" htmlFor={label}>
        {label}
      </label>
      <input
        id={label}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoComplete={autoComplete}
        required={required}
        className="w-full rounded-xl border bg-transparent px-3.5 py-2.5 text-sm outline-none transition focus:border-brand-500 hairline"
      />
    </div>
  );
}
