"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import type { Address } from "@/db/schema";
import { deliveryPromise, rupees } from "@/lib/format";
import { bump, useShop } from "./store";

type Line = { id: number; quantity: number; size: string | null; color: string | null; product: { id: number; title: string; brand: string; images: string[]; price: number; slug: string } };
type Totals = { itemCount: number; itemsTotal: number; mrpTotal: number; catalogueDiscount: number; couponDiscount: number; deliveryFee: number; total: number; savings: number };

const PAYMENTS = [
  { id: "upi", label: "UPI", detail: "GPay, PhonePe, Paytm & BHIM — instant confirmation", icon: "🇮🇳", recommended: true },
  { id: "card", label: "Credit / Debit card", detail: "Visa, Mastercard, RuPay & Amex with 3D Secure", icon: "💳" },
  { id: "netbanking", label: "Net banking", detail: "58 banks supported including SBI, HDFC & ICICI", icon: "🏦" },
  { id: "wallet", label: "FASTO Wallet", detail: "Use your wallet balance and FASTO coins first", icon: "👛" },
  { id: "emi", label: "EMI", detail: "No-cost EMI from ₹1,299/month on 3, 6 & 12 months", icon: "📅" },
  { id: "cod", label: "Cash on delivery", detail: "Pay in cash or UPI when the order reaches you", icon: "💵" },
];

const STATES = ["Karnataka", "Maharashtra", "Delhi", "Tamil Nadu", "Telangana", "Gujarat", "West Bengal", "Rajasthan", "Kerala", "Uttar Pradesh", "Haryana", "Punjab"];

export default function CheckoutFlow() {
  const router = useRouter();
  const { toast, user } = useShop();
  const [step, setStep] = useState(1);
  const [lines, setLines] = useState<Line[]>([]);
  const [totals, setTotals] = useState<Totals | null>(null);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Address | null>(null);
  const [method, setMethod] = useState("upi");
  const [couponCode, setCouponCode] = useState("");
  const [upiId, setUpiId] = useState("");
  const [card, setCard] = useState({ number: "", name: "", expiry: "", cvv: "" });
  const [placing, setPlacing] = useState(false);

  const load = useCallback(async () => {
    const [cartRes, accountRes] = await Promise.all([
      fetch("/api/cart", { cache: "no-store" }),
      fetch("/api/account", { cache: "no-store" }),
    ]);
    if (cartRes.ok) {
      const data = (await cartRes.json()) as { lines: Line[]; totals: Totals };
      setLines(data.lines.filter((l) => !("savedForLater" in l) || !(l as unknown as { savedForLater: boolean }).savedForLater));
      setTotals(data.totals);
    }
    if (accountRes.ok) {
      const data = (await accountRes.json()) as { addresses: Address[] };
      setAddresses(data.addresses);
      setSelected(data.addresses.find((a) => a.isDefault)?.id ?? data.addresses[0]?.id ?? null);
      if (!data.addresses.length) setFormOpen(true);
    }
  }, []);

  useEffect(() => {
    void load();
    const stored = sessionStorage.getItem("fasto_coupon");
    if (stored) setCouponCode(stored);
  }, [load]);

  async function saveAddress(event: React.FormEvent) {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(event.target as HTMLFormElement)) as Record<string, string>;
    const res = await fetch("/api/account", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "address.save", id: editing?.id, isDefault: addresses.length === 0, ...payload }),
    });
    const data = (await res.json()) as { ok: boolean; error?: string };
    if (!data.ok) {
      toast(data.error ?? "Could not save address", "error");
      return;
    }
    toast("Address saved");
    setFormOpen(false);
    setEditing(null);
    await load();
  }

  async function deleteAddress(id: number) {
    await fetch("/api/account", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "address.delete", id }) });
    toast("Address removed", "info");
    await load();
  }

  async function pay() {
    const address = addresses.find((a) => a.id === selected);
    if (!address) {
      toast("Please add a delivery address", "error");
      setStep(1);
      return;
    }
    if (method === "upi" && upiId && !/^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test(upiId)) {
      toast("Enter a valid UPI ID like name@bank", "error");
      return;
    }
    if (method === "card" && card.number.replace(/\s/g, "").length < 15) {
      toast("Enter a valid 16-digit card number", "error");
      return;
    }

    setPlacing(true);
    const gatewayRes = await fetch("/api/checkout", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "payment", code: couponCode || undefined, amount: (totals?.total ?? 0) * 100 }),
    });
    const gateway = (await gatewayRes.json()) as { ok: boolean; gateway: { id: string } };

    const verifyRes = await fetch("/api/checkout", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "verify", razorpayOrderId: gateway.gateway?.id, razorpayPaymentId: `pay_${Date.now().toString(36)}` }),
    });
    const verified = (await verifyRes.json()) as { ok: boolean; paymentRef?: string };
    if (!verified.ok) {
      toast("Payment verification failed", "error");
      setPlacing(false);
      return;
    }

    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "place",
        code: couponCode || undefined,
        paymentMethod: method,
        email: user?.email ?? "guest@fasto.in",
        phone: address.phone,
        address: {
          fullName: address.fullName,
          phone: address.phone,
          line1: address.line1,
          line2: address.line2 ?? "",
          city: address.city,
          state: address.state,
          pincode: address.pincode,
        },
      }),
    });
    const data = (await res.json()) as { ok: boolean; orderNumber?: string; error?: string };
    setPlacing(false);
    if (!data.ok || !data.orderNumber) {
      toast(data.error ?? "Could not place order", "error");
      return;
    }
    bump();
    toast("Order placed successfully 🎉");
    router.push(`/order-confirmation/${data.orderNumber}`);
  }

  const address = addresses.find((a) => a.id === selected);
  const stepLabels = ["Delivery address", "Order summary", "Payment"];

  return (
    <div className="space-y-5">
      <ol className="panel flex flex-wrap items-center gap-2 rounded-2xl px-4 py-3 text-xs font-bold sm:gap-4">
        {stepLabels.map((label, i) => {
          const n = i + 1;
          const done = step > n;
          return (
            <li key={label} className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => n < step && setStep(n)}
                className={`grid h-6 w-6 place-items-center rounded-full text-[11px] ${
                  step === n ? "bg-brand-600 text-white" : done ? "bg-emerald-500 text-white" : "bg-ink-400/15 text-ink-400"
                }`}
              >
                {done ? "✓" : n}
              </button>
              <span className={step === n ? "text-brand-600 dark:text-brand-300" : "text-ink-400"}>{label}</span>
              {n < stepLabels.length && <span aria-hidden className="hidden text-ink-400 sm:inline">—</span>}
            </li>
          );
        })}
        <li className="ml-auto hidden items-center gap-1.5 text-[11px] font-semibold text-emerald-600 sm:flex dark:text-emerald-400">
          🔒 256-bit encrypted checkout
        </li>
      </ol>

      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <div className="space-y-4">
          {/* step 1 */}
          <section className="panel rounded-2xl p-4 sm:p-5">
            <header className="flex items-center justify-between">
              <h2 className="text-sm font-black uppercase tracking-wide text-ink-400">1 · Delivery address</h2>
              {step === 1 && (
                <button
                  type="button"
                  onClick={() => {
                    setEditing(null);
                    setFormOpen((v) => !v);
                  }}
                  className="text-xs font-bold text-brand-600 dark:text-brand-300"
                >
                  {formOpen ? "Cancel" : "+ Add new address"}
                </button>
              )}
            </header>

            {step === 1 && (
              <div className="mt-3 space-y-3">
                {addresses.map((a) => (
                  <label
                    key={a.id}
                    className={`flex cursor-pointer gap-3 rounded-2xl border p-3.5 transition ${
                      selected === a.id ? "border-brand-600 bg-brand-500/5" : "hairline hover:border-brand-400"
                    }`}
                  >
                    <input
                      type="radio"
                      name="address"
                      checked={selected === a.id}
                      onChange={() => setSelected(a.id)}
                      className="mt-1 accent-brand-600"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-bold text-ink-900 dark:text-white">{a.fullName}</span>
                        <span className="rounded-full bg-ink-400/12 px-2 py-0.5 text-[10px] font-bold uppercase text-ink-500 dark:text-ink-300">
                          {a.label}
                        </span>
                        {a.isDefault && <span className="text-[10px] font-bold text-emerald-600">Default</span>}
                      </span>
                      <span className="mt-1 block text-xs leading-relaxed text-ink-500 dark:text-ink-300">
                        {a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city}, {a.state} — <strong>{a.pincode}</strong>
                      </span>
                      <span className="mt-0.5 block text-xs text-ink-400">Phone: {a.phone}</span>
                    </span>
                    <span className="flex flex-col gap-1 text-[11px] font-bold">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          setEditing(a);
                          setFormOpen(true);
                        }}
                        className="text-brand-600 dark:text-brand-300"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.preventDefault();
                          void deleteAddress(a.id);
                        }}
                        className="text-rose-600"
                      >
                        Delete
                      </button>
                    </span>
                  </label>
                ))}

                {formOpen && (
                  <form onSubmit={saveAddress} className="animate-pop grid gap-3 rounded-2xl border p-4 hairline sm:grid-cols-2">
                    {[
                      ["fullName", "Full name", true],
                      ["phone", "10-digit mobile number", true],
                      ["pincode", "Pincode", true],
                      ["city", "City / town", true],
                      ["state", "State", true],
                      ["label", "Address type (Home / Work)"],
                    ].map(([name, label, required]) => (
                      <label key={name as string} className="text-xs font-bold text-ink-600 dark:text-ink-200">
                        {label as string}
                        {name === "state" ? (
                          <select name="state" defaultValue={editing?.state ?? "Karnataka"} className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline">
                            {STATES.map((s) => (
                              <option key={s} value={s}>{s}</option>
                            ))}
                          </select>
                        ) : (
                          <input
                            name={name as string}
                            required={Boolean(required)}
                            defaultValue={editing ? String(editing[name as keyof Address] ?? "") : ""}
                            className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline"
                          />
                        )}
                      </label>
                    ))}
                    <label className="text-xs font-bold text-ink-600 sm:col-span-2 dark:text-ink-200">
                      Flat, house no., building, society
                      <input name="line1" required defaultValue={editing?.line1 ?? ""} className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline" />
                    </label>
                    <label className="text-xs font-bold text-ink-600 sm:col-span-2 dark:text-ink-200">
                      Area, colony, landmark (optional)
                      <input name="line2" defaultValue={editing?.line2 ?? ""} className="mt-1 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm font-normal outline-none focus:border-brand-500 hairline" />
                    </label>
                    <button type="submit" className="rounded-xl bg-brand-600 py-3 text-sm font-bold text-white sm:col-span-2">
                      Save address
                    </button>
                  </form>
                )}

                {addresses.length > 0 && (
                  <button
                    type="button"
                    disabled={!selected}
                    onClick={() => setStep(2)}
                    className="w-full rounded-xl bg-brand-600 py-3 text-sm font-bold text-white disabled:opacity-50"
                  >
                    Deliver to this address →
                  </button>
                )}
              </div>
            )}
            {step > 1 && address && (
              <p className="mt-2 text-xs text-ink-500 dark:text-ink-300">
                <strong className="text-ink-800 dark:text-white">{address.fullName}</strong> · {address.line1}, {address.city} {address.pincode}
              </p>
            )}
          </section>

          {/* step 2 */}
          <section className="panel rounded-2xl p-4 sm:p-5">
            <h2 className="text-sm font-black uppercase tracking-wide text-ink-400">2 · Order summary</h2>
            {step >= 2 ? (
              <div className="mt-3 space-y-3">
                {lines.map((l) => (
                  <div key={l.id} className="flex gap-3">
                    <Link href={`/product/${l.product.slug}`} className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-ink-50 dark:bg-ink-900">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={l.product.images[0]} alt="" loading="lazy" className="h-full w-full object-cover" />
                    </Link>
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-1 text-sm font-semibold text-ink-900 dark:text-white">{l.product.title}</p>
                      <p className="text-[11px] text-ink-400">
                        {l.product.brand} · Qty {l.quantity}
                        {l.size ? ` · Size ${l.size}` : ""}
                        {l.color ? ` · ${l.color}` : ""}
                      </p>
                      <p className="text-xs font-bold text-ink-900 dark:text-white">{rupees(l.product.price * l.quantity)}</p>
                    </div>
                  </div>
                ))}
                <div className="flex flex-wrap items-center gap-2 rounded-xl bg-brand-500/6 p-3">
                  <span className="text-xs font-bold text-ink-600 dark:text-ink-200">Have a coupon?</span>
                  <input
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="CODE"
                    className="w-32 rounded-lg border bg-transparent px-2.5 py-1.5 font-mono text-xs font-bold uppercase outline-none hairline"
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await fetch("/api/coupon", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ code: couponCode }) });
                      const data = (await res.json()) as { ok: boolean; coupon: { message: string } };
                      toast(data.coupon.message, data.ok ? "success" : "error");
                    }}
                    className="rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-bold text-white"
                  >
                    Check
                  </button>
                </div>
                {step === 2 && (
                  <button type="button" onClick={() => setStep(3)} className="w-full rounded-xl bg-brand-600 py-3 text-sm font-bold text-white">
                    Continue to payment →
                  </button>
                )}
              </div>
            ) : (
              <p className="mt-2 text-xs text-ink-400">Complete the delivery step to review your items.</p>
            )}
          </section>

          {/* step 3 */}
          <section className="panel rounded-2xl p-4 sm:p-5">
            <h2 className="text-sm font-black uppercase tracking-wide text-ink-400">3 · Payment method</h2>
            {step === 3 ? (
              <div className="mt-3 space-y-2.5">
                {PAYMENTS.map((p) => (
                  <div key={p.id}>
                    <label
                      className={`flex cursor-pointer items-start gap-3 rounded-2xl border p-3.5 transition ${
                        method === p.id ? "border-brand-600 bg-brand-500/5" : "hairline hover:border-brand-400"
                      }`}
                    >
                      <input type="radio" name="payment" checked={method === p.id} onChange={() => setMethod(p.id)} className="mt-1 accent-brand-600" />
                      <span aria-hidden className="text-lg">{p.icon}</span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2 text-sm font-bold text-ink-900 dark:text-white">
                          {p.label}
                          {p.recommended && <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-black uppercase text-emerald-600">Recommended</span>}
                        </span>
                        <span className="mt-0.5 block text-xs text-ink-400">{p.detail}</span>
                      </span>
                    </label>

                    {method === p.id && p.id === "upi" && (
                      <div className="animate-pop mx-2 mt-2 rounded-xl bg-ink-400/6 p-3">
                        <p className="text-[11px] font-bold uppercase tracking-wide text-ink-400">Your UPI ID</p>
                        <input
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          placeholder="yourname@okhdfcbank"
                          className="mt-1.5 w-full rounded-xl border bg-transparent px-3 py-2.5 text-sm outline-none focus:border-brand-500 hairline"
                        />
                        <p className="mt-2 text-[11px] text-ink-400">A collect request will be sent to your UPI app. Payment auto-verifies in seconds.</p>
                      </div>
                    )}

                    {method === p.id && p.id === "card" && (
                      <div className="animate-pop mx-2 mt-2 grid gap-2.5 rounded-xl bg-ink-400/6 p-3 sm:grid-cols-2">
                        <input
                          value={card.number}
                          onChange={(e) => setCard({ ...card, number: e.target.value.replace(/[^\d ]/g, "").slice(0, 19) })}
                          placeholder="Card number"
                          inputMode="numeric"
                          className="rounded-xl border bg-transparent px-3 py-2.5 text-sm outline-none focus:border-brand-500 hairline sm:col-span-2"
                        />
                        <input
                          value={card.name}
                          onChange={(e) => setCard({ ...card, name: e.target.value })}
                          placeholder="Name on card"
                          className="rounded-xl border bg-transparent px-3 py-2.5 text-sm outline-none focus:border-brand-500 hairline sm:col-span-2"
                        />
                        <input
                          value={card.expiry}
                          onChange={(e) => setCard({ ...card, expiry: e.target.value.slice(0, 5) })}
                          placeholder="MM / YY"
                          className="rounded-xl border bg-transparent px-3 py-2.5 text-sm outline-none focus:border-brand-500 hairline"
                        />
                        <input
                          value={card.cvv}
                          onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, "").slice(0, 3) })}
                          placeholder="CVV"
                          type="password"
                          className="rounded-xl border bg-transparent px-3 py-2.5 text-sm outline-none focus:border-brand-500 hairline"
                        />
                        <p className="text-[11px] text-ink-400 sm:col-span-2">🔒 Card details are tokenised by our PCI-DSS certified gateway and never stored on FASTO servers.</p>
                      </div>
                    )}
                  </div>
                ))}

                <button
                  type="button"
                  onClick={pay}
                  disabled={placing}
                  className="mt-2 w-full rounded-xl bg-flame-500 py-4 text-sm font-black text-white shadow-float transition hover:bg-flame-600 disabled:opacity-60"
                >
                  {placing ? "Processing payment…" : method === "cod" ? `Place order · ${rupees(totals?.total ?? 0)}` : `Pay ${rupees(totals?.total ?? 0)} securely`}
                </button>
                <p className="text-center text-[11px] text-ink-400">
                  By placing this order you agree to FASTO&apos;s Terms &amp; Conditions and Refund Policy.
                </p>
              </div>
            ) : (
              <p className="mt-2 text-xs text-ink-400">Available once your summary is confirmed.</p>
            )}
          </section>
        </div>

        <aside className="panel h-fit rounded-2xl p-5 lg:sticky lg:top-40">
          <p className="text-xs font-black uppercase tracking-wide text-ink-400">Price details</p>
          <dl className="mt-3 space-y-2.5 text-sm">
            <div className="flex justify-between">
              <dt className="text-ink-600 dark:text-ink-300">Items ({totals?.itemCount ?? 0})</dt>
              <dd className="font-bold">{rupees(totals?.mrpTotal ?? 0)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-600 dark:text-ink-300">Discounts</dt>
              <dd className="font-bold text-emerald-600 dark:text-emerald-400">− {rupees((totals?.catalogueDiscount ?? 0) + (totals?.couponDiscount ?? 0))}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-ink-600 dark:text-ink-300">Delivery</dt>
              <dd className="font-bold">{(totals?.deliveryFee ?? 0) === 0 ? "FREE" : rupees(totals?.deliveryFee ?? 0)}</dd>
            </div>
            <div className="flex justify-between border-t pt-3 hairline">
              <dt className="font-black text-ink-900 dark:text-white">Amount payable</dt>
              <dd className="text-lg font-black text-ink-900 dark:text-white">{rupees(totals?.total ?? 0)}</dd>
            </div>
          </dl>
          <p className="mt-3 rounded-xl bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-700 dark:text-emerald-400">
            You save {rupees(totals?.savings ?? 0)}
          </p>
          <p className="mt-4 text-[11px] leading-relaxed text-ink-400">
            Expected delivery by <strong className="text-ink-600 dark:text-ink-200">{deliveryPromise(address?.pincode)}</strong>
            <br />
            Gateway: Razorpay-ready integration · sandbox enabled
          </p>
        </aside>
      </div>
    </div>
  );
}
