"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useState } from "react";
import { rupees } from "@/lib/format";

type Props = {
  categories: Array<{ name: string; slug: string; icon: string }>;
  brands: Array<{ brand: string; count: number }>;
  priceMin: number;
  priceMax: number;
  total: number;
};

const SIZES = ["XS", "S", "M", "L", "XL", "XXL", "6", "7", "8", "9", "10", "11", "Free size"];
const COLORS = ["Black", "White", "Blue", "Green", "Brown", "Gold", "Silver", "Pink", "Red", "Indigo", "Teal", "Ivory"];

export default function SearchFilters({ categories, brands, priceMin, priceMax, total }: Props) {
  const router = useRouter();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);

  const current = useCallback((key: string) => params.get(key) ?? "", [params]);

  const push = useCallback(
    (mutate: (next: URLSearchParams) => void) => {
      const next = new URLSearchParams(params.toString());
      mutate(next);
      next.delete("page");
      router.push(`/products?${next.toString()}`);
    },
    [params, router],
  );

  const toggleMulti = (key: string, value: string) =>
    push((next) => {
      const values = (next.get(key) ?? "").split(",").filter(Boolean);
      const updated = values.includes(value) ? values.filter((v) => v !== value) : [...values, value];
      if (updated.length) next.set(key, updated.join(","));
      else next.delete(key);
    });

  const isSelected = (key: string, value: string) => (params.get(key) ?? "").split(",").filter(Boolean).includes(value);

  const activeCount = ["category", "brand", "size", "color", "rating", "minPrice", "maxPrice", "inStock", "tag"].filter((k) => params.get(k)).length;

  const section = "border-b py-4 hairline";
  const heading = "mb-2.5 text-[11px] font-black uppercase tracking-[0.14em] text-ink-400";
  const row = "flex w-full items-center gap-2.5 rounded-lg px-1 py-1.5 text-left text-sm transition hover:text-brand-600";

  const body = (
    <div className="px-1">
      <div className="flex items-center justify-between pb-3">
        <p className="text-sm font-black text-ink-900 dark:text-white">Filters</p>
        {activeCount > 0 && (
          <button
            type="button"
            onClick={() => router.push(`/products${params.get("q") ? `?q=${encodeURIComponent(params.get("q")!)}` : ""}`)}
            className="text-xs font-bold text-brand-600 dark:text-brand-300"
          >
            Clear all ({activeCount})
          </button>
        )}
      </div>

      <div className={section}>
        <p className={heading}>Category</p>
        <button type="button" onClick={() => push((n) => n.delete("category"))} className={row}>
          <Dot on={!current("category")} /> All categories
        </button>
        {categories.map((c) => (
          <button key={c.slug} type="button" onClick={() => push((n) => (n.get("category") === c.slug ? n.delete("category") : n.set("category", c.slug)))} className={row}>
            <Dot on={current("category") === c.slug} />
            <span aria-hidden className="text-sm">{c.icon}</span>
            {c.name}
          </button>
        ))}
      </div>

      <div className={section}>
        <p className={heading}>Price</p>
        <div className="flex flex-wrap gap-1.5">
          {[
            ["Under ₹999", "", "999"],
            ["₹1000 - ₹4999", "1000", "4999"],
            ["₹5000 - ₹14999", "5000", "14999"],
            ["₹15000 - ₹29999", "15000", "29999"],
            ["Over ₹30000", "30000", ""],
          ].map(([label, min, max]) => (
            <button
              key={label}
              type="button"
              onClick={() =>
                push((n) => {
                  if (min) n.set("minPrice", min);
                  else n.delete("minPrice");
                  if (max) n.set("maxPrice", max);
                  else n.delete("maxPrice");
                })
              }
              className={`rounded-full border px-3 py-1.5 text-[11px] font-bold transition ${
                (min === (params.get("minPrice") ?? "") || (!min && !params.get("minPrice"))) &&
                (max === (params.get("maxPrice") ?? "") || (!max && !params.get("maxPrice")))
                  ? "border-brand-600 bg-brand-500/10 text-brand-600 dark:text-brand-300"
                  : "hairline text-ink-600 dark:text-ink-200"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-ink-400">
          Catalogue range {rupees(priceMin)} – {rupees(priceMax)}
        </p>
      </div>

      <div className={section}>
        <p className={heading}>Customer rating</p>
        {[4.5, 4, 3.5, 3].map((r) => (
          <button key={r} type="button" onClick={() => push((n) => (current("rating") === String(r) ? n.delete("rating") : n.set("rating", String(r))))} className={row}>
            <Dot on={current("rating") === String(r)} />
            <span className="text-amber-500">{r}★</span> & above
          </button>
        ))}
      </div>

      <div className={section}>
        <p className={heading}>Brand</p>
        <div className="max-h-56 space-y-0.5 overflow-y-auto pr-1">
          {brands.map((b) => (
            <button key={b.brand} type="button" onClick={() => toggleMulti("brand", b.brand)} className={row}>
              <Dot on={isSelected("brand", b.brand)} />
              <span className="flex-1">{b.brand}</span>
              <span className="text-[11px] text-ink-400">{b.count}</span>
            </button>
          ))}
        </div>
      </div>

      <div className={section}>
        <p className={heading}>Size</p>
        <div className="flex flex-wrap gap-1.5">
          {SIZES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => toggleMulti("size", s)}
              className={`min-w-[42px] rounded-lg border px-2 py-1.5 text-[11px] font-bold transition ${
                isSelected("size", s) ? "border-brand-600 bg-brand-500/10 text-brand-600 dark:text-brand-300" : "hairline text-ink-600 dark:text-ink-200"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className={section}>
        <p className={heading}>Colour</p>
        <div className="flex flex-wrap gap-1.5">
          {COLORS.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => toggleMulti("color", c)}
              className={`rounded-full border px-3 py-1.5 text-[11px] font-bold transition ${
                isSelected("color", c) ? "border-brand-600 bg-brand-500/10 text-brand-600 dark:text-brand-300" : "hairline text-ink-600 dark:text-ink-200"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div className="py-4">
        <p className={heading}>Availability & offers</p>
        {[
          ["inStock", "In stock only"],
          ["tag", "Flash sale items", "flash"],
        ].map(([key, label, value]) => (
          <button key={key} type="button" onClick={() => push((n) => (n.get(key as string) ? n.delete(key as string) : n.set(key as string, (value as string) ?? "1")))} className={row}>
            <Dot on={Boolean(params.get(key as string))} />
            {label}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <>
      <div className="mb-3 flex items-center justify-between lg:hidden">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="rounded-xl border px-4 py-2 text-sm font-bold hairline text-ink-700 dark:text-ink-100"
        >
          ⚙️ Filters {activeCount > 0 && <span className="ml-1 rounded-full bg-brand-600 px-1.5 text-[10px] text-white">{activeCount}</span>}
        </button>
        <SortSelect />
      </div>

      {open && <div className="panel animate-pop mb-4 rounded-2xl lg:hidden">{body}</div>}

      <aside className="panel sticky top-40 hidden h-fit w-64 shrink-0 overflow-hidden rounded-2xl lg:block">
        <div className="max-h-[calc(100vh-11rem)] overflow-y-auto">{body}</div>
      </aside>
      <span className="hidden">{total}</span>
    </>
  );
}

export function SortSelect() {
  const router = useRouter();
  const params = useSearchParams();

  return (
    <label className="flex items-center gap-2 text-xs font-bold text-ink-400">
      <span className="hidden sm:inline">Sort by</span>
      <select
        value={params.get("sort") ?? "popular"}
        onChange={(e) => {
          const next = new URLSearchParams(params.toString());
          next.set("sort", e.target.value);
          next.delete("page");
          router.push(`/products?${next.toString()}`);
        }}
        className="rounded-xl border bg-transparent px-3 py-2 text-xs font-bold text-ink-800 outline-none hairline dark:text-white"
      >
        <option value="popular">Popularity</option>
        <option value="price_asc">Price: low to high</option>
        <option value="price_desc">Price: high to low</option>
        <option value="discount">Discount</option>
        <option value="rating">Customer rating</option>
        <option value="newest">Newest first</option>
      </select>
    </label>
  );
}

function Dot({ on }: { on: boolean }) {
  return (
    <span
      className={`grid h-4 w-4 shrink-0 place-items-center rounded-full border-2 transition ${
        on ? "border-brand-600 bg-brand-600" : "border-ink-400/60"
      }`}
    >
      {on && <span className="h-1.5 w-1.5 rounded-full bg-white" />}
    </span>
  );
}
