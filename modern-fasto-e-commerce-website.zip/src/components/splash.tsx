"use client";

import { useEffect, useState } from "react";
import { FastoMark } from "./logo";

const SPLASH_KEY = "fasto_splash_seen";

export default function Splash() {
  const [phase, setPhase] = useState<"hidden" | "showing" | "leaving">("hidden");

  useEffect(() => {
    let seen = "false";
    try {
      seen = sessionStorage.getItem(SPLASH_KEY) ?? "false";
    } catch {
      seen = "false";
    }
    if (seen === "true") return;
    setPhase("showing");
    document.body.style.overflow = "hidden";
    const leaveTimer = window.setTimeout(() => setPhase("leaving"), 2100);
    const hideTimer = window.setTimeout(() => {
      setPhase("hidden");
      document.body.style.overflow = "";
      try {
        sessionStorage.setItem(SPLASH_KEY, "true");
      } catch {
        /* ignore */
      }
    }, 2700);
    return () => {
      window.clearTimeout(leaveTimer);
      window.clearTimeout(hideTimer);
      document.body.style.overflow = "";
    };
  }, []);

  if (phase === "hidden") return null;

  return (
    <div
      aria-hidden
      className={`fixed inset-0 z-[200] grid place-items-center overflow-hidden transition-opacity duration-500 ${
        phase === "leaving" ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
      style={{ background: "radial-gradient(120% 120% at 50% 20%, #2b0f8f 0%, #140a3a 45%, #07040f 100%)" }}
    >
      <div
        className="absolute -inset-24 opacity-40 blur-3xl"
        style={{
          background:
            "conic-gradient(from 180deg at 50% 50%, rgba(109,61,255,0.55), rgba(255,122,24,0.35), rgba(109,61,255,0.55))",
          animation: "spin 14s linear infinite",
        }}
      />
      <div className="relative flex flex-col items-center gap-7 px-6 text-center">
        <div className="animate-pop relative">
          <svg width="120" height="120" viewBox="0 0 120 120" fill="none" className="absolute -inset-4">
            <circle cx="60" cy="60" r="52" stroke="rgba(255,255,255,0.16)" strokeWidth="2" />
            <circle
              cx="60"
              cy="60"
              r="52"
              stroke="url(#ringGrad)"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray="320"
              style={{ animation: "fasto-ring 1.9s cubic-bezier(0.65,0,0.35,1) forwards" }}
            />
            <defs>
              <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#ff7a18" />
                <stop offset="100%" stopColor="#ffffff" />
              </linearGradient>
            </defs>
          </svg>
          <FastoMark className="h-20 w-20 drop-shadow-[0_18px_40px_rgba(109,61,255,0.75)]" />
        </div>

        <div className="flex overflow-hidden">
          {"FASTO".split("").map((letter, i) => (
            <span
              key={letter + i}
              className="text-5xl font-black tracking-[0.16em] text-white sm:text-6xl"
              style={{
                animation: "fasto-rise 0.7s cubic-bezier(0.22,1,0.36,1) both",
                animationDelay: `${0.18 + i * 0.08}s`,
              }}
            >
              {letter}
            </span>
          ))}
        </div>

        <p
          className="text-xs font-semibold uppercase tracking-[0.42em] text-white/70"
          style={{ animation: "fasto-rise 0.8s ease both", animationDelay: "0.7s" }}
        >
          Shop faster. Live better.
        </p>

        <div className="mt-2 h-1 w-44 overflow-hidden rounded-full bg-white/15">
          <div
            className="h-full rounded-full bg-gradient-to-r from-flame-500 via-white to-brand-400"
            style={{ animation: "loadbar 2s cubic-bezier(0.4,0,0.2,1) forwards" }}
          />
        </div>
      </div>

      <style>{`@keyframes loadbar{from{width:0%}to{width:100%}}@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
