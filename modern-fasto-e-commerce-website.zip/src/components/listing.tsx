import Link from "next/link";
import { Suspense } from "react";
import ProductCard from "@/components/product-card";
import SearchFilters, { SortSelect } from "@/components/search-filters";
import { EmptyState } from "@/components/ui";
import type { Product } from "@/db/schema";
import { getCategories } from "@/lib/catalog";

type SearchParams = Record<string, string | string[] | undefined>;

const PAGE_SIZE = 20;

function one(params: SearchParams, key: string): string | undefined {
  const v = params[key];
  return Array.isArray(v) ? v[0] : v;
}

function many(params: SearchParams, key: string): string[] | undefined {
  const v = one(params, key);
  return v ? v.split(",").filter(Boolean) : undefined;
}

export default async function Listing({
  params,
  heading,
  subtitle,
  basePath = "products",
}: {
  params: SearchParams;
  heading: string;
  subtitle: string;
  basePath?: string;
}) {
  const page = Number(one(params, "page") ?? 1);
  const query = {
    q: one(params, "q"),
    category: one(params, "category"),
    brands: many(params, "brand"),
    sizes: many(params, "size"),
    colors: many(params, "color"),
    minPrice: one(params, "minPrice") ? Number(one(params, "minPrice")) : undefined,
    maxPrice: one(params, "maxPrice") ? Number(one(params, "maxPrice")) : undefined,
    rating: one(params, "rating") ? Number(one(params, "rating")) : undefined,
    inStock: one(params, "inStock") === "1",
    tag: one(params, "tag"),
    sort: one(params, "sort"),
    page,
    perPage: PAGE_SIZE,
  };

  const { searchProducts } = await import("@/lib/catalog");
  const [result, categories] = await Promise.all([searchProducts(query), getCategories()]);

  const qs = (extra: Record<string, string>) => {
    const next = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      const value = Array.isArray(v) ? v[0] : v;
      if (value) next.set(k, value);
    });
    Object.entries(extra).forEach(([k, v]) => next.set(k, v));
    return `/${basePath}?${next.toString()}`;
  };

  return (
    <div className="flex gap-6">
      <Suspense fallback={<div className="hidden w-64 shrink-0 lg:block" />}>
        <SearchFilters
          categories={categories.map((c) => ({ name: c.name, slug: c.slug, icon: c.icon }))}
          brands={result.facets.brands}
          priceMin={result.facets.priceMin}
          priceMax={result.facets.priceMax}
          total={result.total}
        />
      </Suspense>

      <section className="min-w-0 flex-1">
        <div className="panel mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl px-4 py-3">
          <div>
            <h1 className="text-lg font-black tracking-tight text-ink-900 dark:text-white sm:text-xl">{heading}</h1>
            <p className="text-xs text-ink-400">{subtitle}</p>
          </div>
          <div className="hidden lg:block">
            <Suspense fallback={null}>
              <SortSelect />
            </Suspense>
          </div>
        </div>

        {result.items.length === 0 ? (
          <EmptyState
            icon="🔍"
            title="No products matched your filters"
            body="Try removing a filter, checking the spelling, or searching for something broader like 'shoes' or 'earbuds'."
            action={
              <Link href="/products" className="rounded-xl bg-brand-600 px-5 py-3 text-sm font-bold text-white">
                Reset filters
              </Link>
            }
          />
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
              {result.items.map((p: Product) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>

            {result.pages > 1 && (
              <nav className="mt-8 flex flex-wrap items-center justify-center gap-1.5" aria-label="Pagination">
                {page > 1 && (
                  <Link href={qs({ page: String(page - 1) })} className="rounded-xl border px-3.5 py-2 text-xs font-bold hairline">
                    ← Prev
                  </Link>
                )}
                {Array.from({ length: Math.min(6, result.pages) }, (_, i) => {
                  const n = Math.max(1, Math.min(result.pages - 5, page - 3)) + i;
                  if (n > result.pages) return null;
                  return (
                    <Link
                      key={n}
                      href={qs({ page: String(n) })}
                      className={`rounded-xl px-3.5 py-2 text-xs font-bold transition ${
                        n === page ? "bg-brand-600 text-white" : "border hairline text-ink-600 dark:text-ink-200"
                      }`}
                    >
                      {n}
                    </Link>
                  );
                })}
                {page < result.pages && (
                  <Link href={qs({ page: String(page + 1) })} className="rounded-xl border px-3.5 py-2 text-xs font-bold hairline">
                    Next →
                  </Link>
                )}
              </nav>
            )}
          </>
        )}
      </section>
    </div>
  );
}
