import Link from "next/link";
import { FastoMark } from "./logo";

const COLUMNS: Array<{ title: string; links: Array<[string, string]> }> = [
  {
    title: "About FASTO",
    links: [
      ["About us", "/about"],
      ["Careers", "/about#careers"],
      ["Press & media", "/about#press"],
      ["FASTO Green", "/about#green"],
      ["Sell on FASTO", "/about#sell"],
    ],
  },
  {
    title: "Help & support",
    links: [
      ["Customer care", "/contact"],
      ["FAQ", "/faq"],
      ["Track your order", "/account?tab=orders"],
      ["Returns & refunds", "/account?tab=returns"],
      ["Report a product", "/contact"],
    ],
  },
  {
    title: "Policies",
    links: [
      ["Privacy policy", "/privacy"],
      ["Terms & conditions", "/terms"],
      ["Shipping policy", "/faq#shipping"],
      ["Cancellation policy", "/faq#returns"],
      ["Referral terms", "/faq#referral"],
    ],
  },
  {
    title: "Shop by category",
    links: [
      ["Mobiles & tablets", "/category/mobiles"],
      ["Electronics", "/category/electronics"],
      ["Fashion & footwear", "/category/fashion"],
      ["Home & kitchen", "/category/home"],
      ["Beauty & wellness", "/category/beauty"],
    ],
  },
];

export default function Footer() {
  return (
    <footer className="mt-14 border-t bg-[var(--panel)] hairline">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-[1.3fr_2.6fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <FastoMark className="h-10 w-10" />
              <div>
                <p className="text-xl font-extrabold tracking-tight text-ink-900 dark:text-white">
                  FAST<span className="text-flame-500">O</span>
                </p>
                <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-ink-400">Shop faster. Live better.</p>
              </div>
            </div>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-ink-400">
              FASTO is an Indian online marketplace built for speed, honest pricing and effortless returns. Over 42 lakh
              shoppers across 19,000+ pin codes trust us for mobiles, fashion, home and daily essentials.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {["UPI", "Visa", "Mastercard", "RuPay", "Net banking", "COD", "EMI"].map((m) => (
                <span key={m} className="rounded-lg bg-ink-400/10 px-2.5 py-1 text-[11px] font-bold text-ink-600 dark:text-ink-200">
                  {m}
                </span>
              ))}
            </div>
            <div className="mt-5 flex gap-2">
              {[
                ["Twitter", "𝕏"],
                ["Instagram", "◎"],
                ["LinkedIn", "in"],
                ["YouTube", "▶"],
              ].map(([label, icon]) => (
                <span
                  key={label}
                  aria-label={label}
                  className="grid h-9 w-9 place-items-center rounded-full bg-ink-400/10 text-sm font-bold text-ink-600 transition hover:bg-brand-500 hover:text-white dark:text-ink-200"
                >
                  {icon}
                </span>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {COLUMNS.map((col) => (
              <div key={col.title}>
                <p className="mb-3 text-[11px] font-black uppercase tracking-[0.16em] text-ink-900 dark:text-white">{col.title}</p>
                <ul className="space-y-2">
                  {col.links.map(([label, href]) => (
                    <li key={label}>
                      <Link href={href} className="text-sm text-ink-400 transition hover:text-brand-600 dark:hover:text-brand-300">
                        {label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-10 grid gap-4 border-t pt-6 hairline sm:grid-cols-3">
          {[
            ["🚚", "Fast delivery", "Same-day in 14 cities, 2-day nationwide"],
            ["🔒", "100% secure payments", "PCI-DSS compliant gateway & 3D Secure"],
            ["↩️", "7-day easy returns", "Doorstep pickup, refund in 3 working days"],
          ].map(([icon, title, body]) => (
            <div key={title} className="flex items-start gap-3">
              <span aria-hidden className="text-xl">{icon}</span>
              <div>
                <p className="text-sm font-bold text-ink-900 dark:text-white">{title}</p>
                <p className="text-xs text-ink-400">{body}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t pt-6 text-xs text-ink-400 hairline sm:flex-row">
          <p>© {new Date().getFullYear()} FASTO Retail Pvt. Ltd. CIN U52100KA2024PTC188420. Bengaluru, India.</p>
          <p className="flex items-center gap-1.5">
            Made with <span aria-hidden>🧡</span> in India
          </p>
        </div>
      </div>
      <div className="h-16 lg:h-0" />
    </footer>
  );
}
