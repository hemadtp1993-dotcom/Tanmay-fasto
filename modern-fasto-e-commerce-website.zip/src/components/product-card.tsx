"use client";

import Link from "next/link";
import { useState } from "react";
import type { Product } from "@/db/schema";
import { rupees, discountPercent } from "@/lib/format";
import { bump, useShop } from "./store";
import { RatingPill } from "./ui";

export function CompareToggle({ product, compact = false }: { product: Product; compact?: boolean }) {
  const { toast } = useShop();
  const [on, setOn] = useState(false);

  function toggle() {
    let list: number[] = [];
    try {
      list = JSON.parse(localStorage.getItem("fasto_compare") ?? "[]") as number[];
    } catch {
      list = [];
    }
    let next: number[];
    if (list.includes(product.id)) {
      next = list.filter((id) => id !== product.id);
      setOn(false);
      toast("Removed from compare", "info");
    } else {
      if (list.length >= 4) {
        toast("You can compare up to 4 products", "error");
        return;
      }
      next = [...list, product.id];
      setOn(true);
      toast("Added to compare");
    }
    localStorage.setItem("fasto_compare", JSON.stringify(next));
    window.dispatchEvent(new Event("fasto:compare"));
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={on}
      className={`rounded-full border px-2.5 py-1 text-[11px] font-bold transition ${
        on ? "border-brand-500 bg-brand-500 text-white" : "hairline text-ink-400 hover:text-brand-600"
      }`}
      title="Add to compare"
    >
      ⇄{!compact && " Compare"}
    </button>
  );
}

export function WishlistButton({ product, className = "" }: { product: Product; className?: string }) {
  const { toast, requireLogin } = useShop();
  const [busy, setBusy] = useState(false);

  async function toggle() {
    if (!requireLogin(`/product/${product.slug}`)) return;
    setBusy(true);
    const res = await fetch("/api/wishlist", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id }),
    });
    const data = (await res.json()) as { wishlisted: boolean };
    toast(data.wishlisted ? "Saved to wishlist" : "Removed from wishlist", data.wishlisted ? "success" : "info");
    bump();
    setBusy(false);
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={busy}
      aria-label="Toggle wishlist"
      className={`grid place-items-center rounded-full ${className}`}
    >
      <svg width="18" height="18" viewBox="0 0 24 24" className="text-rose-500" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l8.8 8.8 8.8-8.8a5.5 5.5 0 0 0 0-7.8z" />
      </svg>
    </button>
  );
}

export default function ProductCard({ product, horizontal = false }: { product: Product; horizontal?: boolean }) {
  const { toast, requireLogin } = useShop();
  const [busy, setBusy] = useState(false);
  const off = discountPercent(product.mrp, product.price);

  async function addToCart() {
    if (!requireLogin(`/product/${product.slug}`)) return;
    setBusy(true);
    const res = await fetch("/api/cart", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id, quantity: 1 }),
    });
    if (res.ok) {
      toast("Added to cart");
      bump();
    } else {
      toast("Could not add to cart", "error");
    }
    setBusy(false);
  }

  if (horizontal) {
    return (
      <Link
        href={`/product/${product.slug}`}
        className="lift panel flex w-[172px] shrink-0 flex-col overflow-hidden rounded-2xl sm:w-[196px]"
      >
        <div className="relative aspect-square overflow-hidden bg-ink-50 dark:bg-ink-900">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={product.images[0]}
            alt={product.title}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition duration-500 hover:scale-105"
          />
          {product.isFlashSale && (
            <span className="absolute left-2 top-2 rounded-full bg-flame-500 px-2 py-0.5 text-[10px] font-black uppercase text-white">
              Flash
            </span>
          )}
        </div>
        <div className="flex flex-1 flex-col gap-1 p-3">
          <p className="line-clamp-2 text-xs font-semibold text-ink-800 dark:text-ink-100">{product.title}</p>
          <RatingPill value={product.rating} count={product.reviewCount} />
          <p className="mt-auto flex items-baseline gap-1.5 pt-1">
            <span className="text-sm font-extrabold text-ink-900 dark:text-white">{rupees(product.price)}</span>
            {off > 0 && <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">{off}% off</span>}
          </p>
        </div>
      </Link>
    );
  }

  return (
    <article className="lift panel group relative flex flex-col overflow-hidden rounded-2xl">
      <Link href={`/product/${product.slug}`} className="relative block aspect-square overflow-hidden bg-ink-50 dark:bg-ink-900">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.images[0]}
          alt={product.title}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.06]"
        />
        <div className="absolute left-2 top-2 flex flex-col gap-1">
          {off >= 40 && (
            <span className="rounded-full bg-flame-500 px-2 py-0.5 text-[10px] font-black uppercase text-white shadow">
              {off}% off
            </span>
          )}
          {product.badges.map((b) => (
            <span key={b} className="rounded-full bg-brand-600 px-2 py-0.5 text-[10px] font-black uppercase text-white shadow">
              {b}
            </span>
          ))}
          {product.newArrival && (
            <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-black uppercase text-white shadow">New</span>
          )}
        </div>
        {product.stock === 0 && (
          <div className="absolute inset-0 grid place-items-center bg-ink-950/55">
            <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-ink-900">Out of stock</span>
          </div>
        )}
      </Link>

      <div className="absolute right-2 top-2 flex flex-col gap-1.5 opacity-0 transition group-hover:opacity-100 focus-within:opacity-100 max-sm:opacity-100">
        <WishlistButton product={product} className="h-8 w-8 bg-white/90 shadow backdrop-blur dark:bg-ink-800/90" />
        <CompareToggle product={product} compact />
      </div>

      <div className="flex flex-1 flex-col gap-1.5 p-3">
        <p className="text-[11px] font-bold uppercase tracking-wide text-brand-600 dark:text-brand-300">{product.brand}</p>
        <Link href={`/product/${product.slug}`} className="line-clamp-2 text-sm font-semibold text-ink-900 hover:text-brand-600 dark:text-white">
          {product.title}
        </Link>
        <RatingPill value={product.rating} count={product.reviewCount} />
        <div className="mt-auto pt-1">
          <p className="flex items-baseline gap-1.5">
            <span className="text-base font-extrabold text-ink-900 dark:text-white">{rupees(product.price)}</span>
            <span className="text-xs text-ink-400 line-through">{rupees(product.mrp)}</span>
          </p>
          <p className="mt-0.5 text-[11px] font-medium text-ink-400">
            {product.stock > 0 ? (product.stock < 10 ? `Only ${product.stock} left` : "In stock") : "Notify me"}
          </p>
        </div>
        <button
          type="button"
          onClick={addToCart}
          disabled={busy || product.stock === 0}
          className="mt-2 w-full rounded-xl bg-brand-600 py-2.5 text-xs font-bold text-white transition hover:bg-brand-700 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50"
        >
          {product.stock === 0 ? "Sold out" : busy ? "Adding…" : "Add to cart"}
        </button>
      </div>
    </article>
  );
}

export function ProductRail({ products, title }: { products: Product[]; title?: string }) {
  return (
    <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
      {products.map((p) => (
        <div key={p.id} className="shrink-0">
          <span className="sr-only">{title}</span>
          <Link href={`/product/${p.slug}`} className="hidden" aria-hidden tabIndex={-1}>
            {p.title}
          </Link>
          <HorizontalCardWrapper product={p} />
        </div>
      ))}
    </div>
  );
}

function HorizontalCardWrapper({ product }: { product: Product }) {
  return (
    <div className="w-[172px] sm:w-[196px]">
      <ProductCardInner product={product} />
    </div>
  );
}

function ProductCardInner({ product }: { product: Product }) {
  return <ProductCard product={product} horizontal />;
}
