"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import type { Product } from "@/db/schema";
import { discountPercent, deliveryPromise, rupees } from "@/lib/format";
import { bump, useShop } from "./store";
import { CtaLink, EmptyState, RatingPill, SectionHeader } from "./ui";

type Totals = {
  itemCount: number;
  itemsTotal: number;
  mrpTotal: number;
  catalogueDiscount: number;
  couponDiscount: number;
  deliveryFee: number;
  total: number;
  savings: number;
};

type Line = { id: number; quantity: number; size: string | null; color: string | null; savedForLater: boolean; product: Product };
type CouponInfo = { ok: boolean; code: string; message: string; discount: number; freeShipping: boolean };

export default function CartView() {
  const { toast, requireLogin } = useShop();
  const [lines, setLines] = useState<Line[]>([]);
  const [totals, setTotals] = useState<Totals | null>(null);
  const [coupons, setCoupons] = useState<Array<{ id: number; code: string; title: string; description: string; minCart: number }>>([]);
  const [coupon, setCoupon] = useState<CouponInfo | null>(null);
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const res = await fetch("/api/cart", { cache: "no-store" });
    if (res.ok) {
      const data = (await res.json()) as { lines: Line[]; totals: Totals };
      setLines(data.lines);
      setTotals(data.totals);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    fetch("/api/coupons")
      .then((r) => r.json())
      .then((d: { coupons?: typeof coupons }) => setCoupons(d.coupons ?? []))
      .catch(() => undefined);
  }, [load]);

  async function patch(id: number, body: Record<string, unknown>) {
    await fetch("/api/cart", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ id, ...body }) });
    await load();
    bump();
  }

  async function remove(id: number) {
    await fetch(`/api/cart?id=${id}`, { method: "DELETE" });
    toast("Removed from cart", "info");
    await load();
    bump();
  }

  async function applyCoupon(nextCode: string) {
    const res = await fetch("/api/coupon", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ code: nextCode }),
    });
    const data = (await res.json()) as { ok: boolean; coupon: CouponInfo; totals: Totals };
    setCoupon(data.coupon);
    setTotals(data.totals);
    toast(data.coupon.message, data.ok ? "success" : "error");
    if (data.ok) sessionStorage.setItem("fasto_coupon", data.coupon.code);
  }

  const active = lines.filter((l) => !l.savedForLater);
  const saved = lines.filter((l) => l.savedForLater);

  if (loading) return <div className="shimmer h-72 rounded-3xl" />;

  if (!active.length && !saved.length)
    return (
      <EmptyState
        icon="🛒"
        title="Your FASTO cart is empty"
        body="Add products you love — we keep your cart safe across devices once you sign in."
        action={<CtaLink href="/products">Shop today&apos;s deals</CtaLink>}
      />
    );

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
      <div className="space-y-4">
        <SectionHeader title={`Shopping cart (${totals?.itemCount ?? 0} items)`} subtitle="Free delivery on orders above ₹499" />

        {active.map((line) => (
          <CartRow key={line.id} line={line} onPatch={patch} onRemove={remove} />
        ))}

        {/* coupon */}
        <div className="panel rounded-2xl p-4">
          <p className="text-xs font-black uppercase tracking-wide text-ink-400">Apply coupon</p>
          <div className="mt-2 flex gap-2">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="Enter code e.g. FASTO100"
              className="flex-1 rounded-xl border bg-transparent px-3 py-2.5 text-sm font-mono font-bold uppercase tracking-wider outline-none focus:border-brand-500 hairline"
            />
            <button
              type="button"
              onClick={() => (code ? applyCoupon(code) : toast("Enter a coupon code first", "error"))}
              className="rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-bold text-white"
            >
              Apply
            </button>
          </div>
          {coupon?.ok && (
            <p className="mt-2 flex items-center justify-between rounded-xl bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-700 dark:text-emerald-400">
              <span>✓ {coupon.code} — {coupon.message}</span>
              <button
                type="button"
                onClick={() => {
                  setCoupon(null);
                  sessionStorage.removeItem("fasto_coupon");
                  void load();
                }}
                className="text-rose-600"
              >
                Remove
              </button>
            </p>
          )}
          {coupons.length > 0 && (
            <div className="mt-3 space-y-1.5">
              {coupons.slice(0, 3).map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setCode(c.code);
                    void applyCoupon(c.code);
                  }}
                  className="flex w-full items-center gap-3 rounded-xl border border-dashed border-brand-500/40 bg-brand-500/5 px-3 py-2 text-left transition hover:bg-brand-500/10"
                >
                  <span className="font-mono text-xs font-black text-brand-600 dark:text-brand-300">{c.code}</span>
                  <span className="flex-1 text-[11px] leading-snug text-ink-500 dark:text-ink-300">{c.title}</span>
                  <span className="text-[11px] font-bold text-brand-600 dark:text-brand-300">Apply</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {saved.length > 0 && (
          <div className="space-y-3">
            <SectionHeader title={`Saved for later (${saved.length})`} subtitle="Move items back to your cart whenever you're ready" />
            {saved.map((line) => (
              <CartRow key={line.id} line={line} onPatch={patch} onRemove={remove} />
            ))}
          </div>
        )}
      </div>

      {/* price details */}
      <aside className="lg:sticky lg:top-40 lg:h-fit">
        <div className="panel rounded-2xl p-5">
          <p className="text-xs font-black uppercase tracking-wide text-ink-400">Price details</p>
          <dl className="mt-3 space-y-2.5 text-sm">
            <Row label={`Price (${totals?.itemCount ?? 0} items)`} value={rupees(totals?.mrpTotal ?? 0)} />
            <Row label="Product discounts" value={`− ${rupees(totals?.catalogueDiscount ?? 0)}`} tone="emerald" />
            {coupon?.ok && <Row label={`Coupon ${coupon.code}`} value={`− ${rupees(totals?.couponDiscount ?? 0)}`} tone="emerald" />}
            <Row
              label="Delivery charges"
              value={(totals?.deliveryFee ?? 0) === 0 ? "FREE" : rupees(totals?.deliveryFee ?? 0)}
              tone={(totals?.deliveryFee ?? 0) === 0 ? "emerald" : undefined}
            />
            <div className="border-t pt-3 hairline">
              <Row label="Total payable" value={rupees(totals?.total ?? 0)} bold />
            </div>
          </dl>
          <p className="mt-3 rounded-xl bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-700 dark:text-emerald-400">
            🎉 You save {rupees(totals?.savings ?? 0)} on this order
          </p>

          <Link
            href="/checkout"
            onClick={(e) => {
              if (!requireLogin("/checkout")) e.preventDefault();
            }}
            className="mt-4 block rounded-xl bg-flame-500 py-3.5 text-center text-sm font-black text-white shadow-float transition hover:bg-flame-600"
          >
            Proceed to checkout →
          </Link>
          <p className="mt-3 text-[11px] leading-relaxed text-ink-400">
            🔒 Safe and secure payments · Easy returns · 100% authentic products
          </p>
          <p className="mt-2 text-[11px] text-ink-400">
            Estimated delivery by <strong className="text-ink-600 dark:text-ink-200">{deliveryPromise()}</strong>
          </p>
        </div>
      </aside>
    </div>
  );
}

function CartRow({
  line,
  onPatch,
  onRemove,
}: {
  line: Line;
  onPatch: (id: number, body: Record<string, unknown>) => Promise<void>;
  onRemove: (id: number) => Promise<void>;
}) {
  const p = line.product;
  const off = discountPercent(p.mrp, p.price);
  return (
    <div className="panel flex gap-3 rounded-2xl p-3 sm:gap-4 sm:p-4">
      <Link href={`/product/${p.slug}`} className="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-ink-50 sm:h-28 sm:w-28 dark:bg-ink-900">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={p.images[0]} alt={p.title} loading="lazy" className="h-full w-full object-cover" />
      </Link>
      <div className="min-w-0 flex-1">
        <Link href={`/product/${p.slug}`} className="line-clamp-2 text-sm font-bold text-ink-900 hover:text-brand-600 dark:text-white">
          {p.title}
        </Link>
        <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-wide text-brand-600 dark:text-brand-300">{p.brand}</p>
        {line.size || line.color ? (
          <p className="mt-1 text-[11px] text-ink-400">
            {line.size ? `Size: ${line.size}` : ""} {line.color ? ` · ${line.color}` : ""}
          </p>
        ) : null}
        <div className="mt-1">
          <RatingPill value={p.rating} count={p.reviewCount} />
        </div>
        <p className="mt-1.5 flex flex-wrap items-baseline gap-2">
          <span className="text-base font-extrabold text-ink-900 dark:text-white">{rupees(p.price)}</span>
          <span className="text-xs text-ink-400 line-through">{rupees(p.mrp)}</span>
          <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">{off}% off</span>
        </p>

        <div className="mt-2.5 flex flex-wrap items-center gap-2">
          {!line.savedForLater ? (
            <div className="flex items-center overflow-hidden rounded-xl border hairline">
              <button
                type="button"
                onClick={() => onPatch(line.id, { quantity: Math.max(1, line.quantity - 1) })}
                disabled={line.quantity <= 1}
                aria-label="Decrease quantity"
                className="px-3 py-1.5 text-sm font-bold text-ink-600 disabled:opacity-40 dark:text-ink-200"
              >
                −
              </button>
              <span className="min-w-8 text-center text-sm font-bold text-ink-900 dark:text-white">{line.quantity}</span>
              <button
                type="button"
                onClick={() => onPatch(line.id, { quantity: Math.min(10, line.quantity + 1) })}
                aria-label="Increase quantity"
                className="px-3 py-1.5 text-sm font-bold text-ink-600 dark:text-ink-200"
              >
                +
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => onPatch(line.id, { savedForLater: false })}
              className="rounded-xl bg-brand-500/12 px-3.5 py-2 text-xs font-bold text-brand-700 dark:text-brand-200"
            >
              Move to cart
            </button>
          )}
          {!line.savedForLater && (
            <button
              type="button"
              onClick={() => onPatch(line.id, { savedForLater: true })}
              className="rounded-xl border px-3.5 py-2 text-xs font-bold text-ink-600 hairline dark:text-ink-200"
            >
              Save for later
            </button>
          )}
          <button type="button" onClick={() => onRemove(line.id)} className="text-xs font-bold text-rose-600">
            Remove
          </button>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, tone, bold }: { label: string; value: string; tone?: "emerald"; bold?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className={`${bold ? "font-black text-ink-900 dark:text-white" : "text-ink-600 dark:text-ink-300"}`}>{label}</dt>
      <dd
        className={`${bold ? "text-lg font-black text-ink-900 dark:text-white" : "font-bold"} ${
          tone === "emerald" ? "text-emerald-600 dark:text-emerald-400" : bold ? "" : "text-ink-800 dark:text-ink-100"
        }`}
      >
        {value}
      </dd>
    </div>
  );
}
