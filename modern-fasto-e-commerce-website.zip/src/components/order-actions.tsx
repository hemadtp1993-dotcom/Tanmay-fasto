"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { useShop } from "./store";

export function OrderActions({ orderId, orderNumber, status }: { orderId: number; orderNumber: string; status: string }) {
  const router = useRouter();
  const { toast } = useShop();
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);

  async function call(body: Record<string, unknown>, message: string) {
    setBusy(true);
    const res = await fetch("/api/account", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = (await res.json()) as { ok: boolean; error?: string; message?: string };
    setBusy(false);
    toast(data.ok ? (data.message ?? message) : (data.error ?? "Action failed"), data.ok ? "success" : "error");
    if (data.ok) router.refresh();
  }

  function downloadInvoice() {
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>Invoice ${orderNumber}</title>
    <style>body{font-family:system-ui,sans-serif;padding:32px}h1{margin:0}</style></head>
    <body><h1>FASTO Retail Pvt. Ltd.</h1><p>Tax invoice for ${orderNumber}</p>
    <p>Open your FASTO account → My Orders → Download invoice for the itemised GST copy.</p></body></html>`;
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `FASTO-Invoice-${orderNumber}.html`;
    a.click();
    URL.revokeObjectURL(url);
    toast("Invoice downloaded");
  }

  const canCancel = ["confirmed", "packed"].includes(status);
  const canReturn = status === "delivered";

  return (
    <div className="panel rounded-3xl p-5">
      <p className="text-xs font-black uppercase tracking-wide text-ink-400">Order actions</p>
      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" onClick={downloadInvoice} className="rounded-xl bg-brand-600 px-4 py-2.5 text-xs font-bold text-white">
          ⬇ Download invoice
        </button>
        {canCancel && (
          <button
            type="button"
            disabled={busy}
            onClick={() => call({ action: "order.cancel", orderId }, "Order cancelled")}
            className="rounded-xl border border-rose-500/40 px-4 py-2.5 text-xs font-bold text-rose-600"
          >
            Cancel order
          </button>
        )}
        {canReturn && (
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="rounded-xl border px-4 py-2.5 text-xs font-bold text-ink-600 hairline dark:text-ink-200"
          >
            Return / Replace
          </button>
        )}
        <button type="button" onClick={() => toast("Our care team will call you in 15 minutes", "info")} className="rounded-xl border px-4 py-2.5 text-xs font-bold text-ink-600 hairline dark:text-ink-200">
          Need help?
        </button>
      </div>

      {open && (
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            const data = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as Record<string, string>;
            await call({ action: "return.create", orderId, ...data }, "Request raised");
            setOpen(false);
          }}
          className="animate-pop mt-3 grid gap-2.5 rounded-2xl border p-3.5 hairline"
        >
          <select name="kind" className="rounded-xl border bg-transparent px-3 py-2.5 text-sm hairline">
            <option value="return">Return & refund</option>
            <option value="replace">Replacement</option>
          </select>
          <select name="reason" className="rounded-xl border bg-transparent px-3 py-2.5 text-sm hairline">
            {["Damaged / defective", "Wrong item delivered", "Size or fit issue", "Changed my mind", "Quality not as expected"].map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
          <textarea name="comments" rows={3} placeholder="Additional details (optional)" className="rounded-xl border bg-transparent px-3 py-2.5 text-sm hairline" />
          <button type="submit" disabled={busy} className="rounded-xl bg-brand-600 py-2.5 text-xs font-bold text-white">
            Submit request
          </button>
        </form>
      )}
    </div>
  );
}
