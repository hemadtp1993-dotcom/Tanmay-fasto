import {
  boolean,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/* ------------------------------- identity ------------------------------- */

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  passwordHash: text("password_hash"),
  role: text("role").notNull().default("customer"),
  provider: text("provider").notNull().default("credentials"),
  avatarUrl: text("avatar_url"),
  referralCode: text("referral_code"),
  referredBy: text("referred_by"),
  walletBalance: integer("wallet_balance").notNull().default(0),
  fastoCoins: integer("fasto_coins").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("users_email_unique").on(t.email)]);

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: integer("user_id").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const passwordResets = pgTable("password_resets", {
  token: text("token").primaryKey(),
  userId: integer("user_id").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
});

/* ------------------------------- catalogue ------------------------------ */

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  icon: text("icon").notNull().default("🛍️"),
  tagline: text("tagline"),
  imageUrl: text("image_url"),
  featured: boolean("featured").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
}, (t) => [uniqueIndex("categories_slug_unique").on(t.slug)]);

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull(),
  title: text("title").notNull(),
  brand: text("brand").notNull(),
  categorySlug: text("category_slug").notNull(),
  shortDescription: text("short_description").notNull().default(""),
  description: text("description").notNull().default(""),
  specs: jsonb("specs").$type<{ label: string; value: string }[]>().notNull().default([]),
  highlights: jsonb("highlights").$type<string[]>().notNull().default([]),
  images: jsonb("images").$type<string[]>().notNull().default([]),
  colors: jsonb("colors").$type<string[]>().notNull().default([]),
  sizes: jsonb("sizes").$type<string[]>().notNull().default([]),
  price: integer("price").notNull(),
  mrp: integer("mrp").notNull(),
  stock: integer("stock").notNull().default(0),
  rating: doublePrecision("rating").notNull().default(4.2),
  reviewCount: integer("review_count").notNull().default(0),
  soldCount: integer("sold_count").notNull().default(0),
  badges: jsonb("badges").$type<string[]>().notNull().default([]),
  isFlashSale: boolean("is_flash_sale").notNull().default(false),
  flashEndsAt: timestamp("flash_ends_at", { withTimezone: true }),
  trending: boolean("trending").notNull().default(false),
  bestseller: boolean("bestseller").notNull().default(false),
  newArrival: boolean("new_arrival").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("products_slug_unique").on(t.slug)]);

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  userId: integer("user_id"),
  authorName: text("author_name").notNull(),
  rating: integer("rating").notNull(),
  title: text("title").notNull().default(""),
  body: text("body").notNull().default(""),
  verified: boolean("verified").notNull().default(true),
  helpfulCount: integer("helpful_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------ shopping ------------------------------- */

export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  visitorId: text("visitor_id").notNull(),
  userId: integer("user_id"),
  productId: integer("product_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  size: text("size"),
  color: text("color"),
  savedForLater: boolean("saved_for_later").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const wishlistItems = pgTable("wishlist_items", {
  id: serial("id").primaryKey(),
  visitorId: text("visitor_id").notNull(),
  userId: integer("user_id"),
  productId: integer("product_id").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const recentlyViewed = pgTable("recently_viewed", {
  id: serial("id").primaryKey(),
  visitorId: text("visitor_id").notNull(),
  userId: integer("user_id"),
  productId: integer("product_id").notNull(),
  viewedAt: timestamp("viewed_at", { withTimezone: true }).notNull().defaultNow(),
});

export const addresses = pgTable("addresses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  label: text("label").notNull().default("Home"),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  line1: text("line1").notNull(),
  line2: text("line2"),
  landmark: text("landmark"),
  city: text("city").notNull(),
  state: text("state").notNull(),
  pincode: text("pincode").notNull(),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  kind: text("kind").notNull(),
  label: text("label").notNull(),
  detail: text("detail").notNull(),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const coupons = pgTable("coupons", {
  id: serial("id").primaryKey(),
  code: text("code").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  type: text("type").notNull().default("percent"),
  value: integer("value").notNull(),
  minCart: integer("min_cart").notNull().default(0),
  maxDiscount: integer("max_discount").notNull().default(100000),
  active: boolean("active").notNull().default(true),
  usedCount: integer("used_count").notNull().default(0),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
}, (t) => [uniqueIndex("coupons_code_unique").on(t.code)]);

/* -------------------------------- orders -------------------------------- */

export type OrderTimelineStep = { label: string; at: string | null; done: boolean };

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull(),
  userId: integer("user_id"),
  visitorId: text("visitor_id"),
  email: text("email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  shippingAddress: jsonb("shipping_address").$type<Record<string, string>>().notNull().default({}),
  itemsTotal: integer("items_total").notNull().default(0),
  discount: integer("discount").notNull().default(0),
  deliveryFee: integer("delivery_fee").notNull().default(0),
  couponCode: text("coupon_code"),
  total: integer("total").notNull().default(0),
  paymentMethod: text("payment_method").notNull().default("cod"),
  paymentStatus: text("payment_status").notNull().default("pending"),
  paymentRef: text("payment_ref"),
  status: text("status").notNull().default("confirmed"),
  timeline: jsonb("timeline").$type<OrderTimelineStep[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("orders_number_unique").on(t.orderNumber)]);

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  productId: integer("product_id").notNull(),
  slug: text("slug").notNull(),
  title: text("title").notNull(),
  image: text("image").notNull().default(""),
  price: integer("price").notNull(),
  quantity: integer("quantity").notNull().default(1),
  size: text("size"),
  color: text("color"),
  itemStatus: text("item_status").notNull().default("active"),
});

export const returnRequests = pgTable("return_requests", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  orderItemId: integer("order_item_id"),
  userId: integer("user_id"),
  orderNumber: text("order_number").notNull(),
  kind: text("kind").notNull().default("return"),
  reason: text("reason").notNull(),
  comments: text("comments").notNull().default(""),
  status: text("status").notNull().default("requested"),
  refundAmount: integer("refund_amount").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ----------------------------- engagement ------------------------------ */

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  kind: text("kind").notNull().default("info"),
  href: text("href"),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const banners = pgTable("banners", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  subtitle: text("subtitle").notNull().default(""),
  ctaText: text("cta_text").notNull().default("Shop now"),
  ctaHref: text("cta_href").notNull().default("/products"),
  imageUrl: text("image_url"),
  gradient: text("gradient").notNull().default("from-violet-600 to-indigo-600"),
  placement: text("placement").notNull().default("hero"),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const searchLogs = pgTable("search_logs", {
  id: serial("id").primaryKey(),
  term: text("term").notNull(),
  hits: integer("hits").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Banner = typeof banners.$inferSelect;
export type User = typeof users.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;
export type Coupon = typeof coupons.$inferSelect;
export type Address = typeof addresses.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
