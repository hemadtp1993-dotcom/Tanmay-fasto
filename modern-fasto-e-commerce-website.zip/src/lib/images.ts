const px = (id: number, size = 700, ext: "jpeg" | "png" = "jpeg") =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.${ext}?auto=compress&cs=tinysrgb&fit=crop&w=${size}&h=${size}`;

export const IMG = {
  tech: [
    px(18311089), px(18311088), px(3394650), px(3568521), px(4533076),
    px(4225229), px(3394653), px(4765366), px(12880803), px(11120516),
  ],
  fashion: [
    px(27256470), px(27256456), px(27256473), px(19166246), px(27256464),
    px(27256459), px(27256452), px(10259873), px(27113471), px(27256462),
  ],
  home: [
    px(5556176), px(36573009), px(31557569), px(37552794), px(16927367),
    px(27569266, 700, "png"), px(6246099), px(20276493), px(38986381), px(36240645),
  ],
  beauty: [
    px(3750640), px(24602077), px(5911961), px(31251024), px(16329382),
    px(16556516), px(18441533), px(17307534), px(1776331), px(17511744),
  ],
  fitness: [
    px(11433027), px(32610335), px(8436582), px(14762165), px(9073247),
    px(8436400), px(8436562), px(28970123), px(29242386), px(6815665),
  ],
  daily: [
    px(6901810), px(9951401), px(31188631), px(31359734), px(31899749),
    px(15466471), px(31899745), px(14211426),
  ],
};

export type PoolKey = keyof typeof IMG;

export function gallery(pool: PoolKey, index: number, count = 4): string[] {
  const list = IMG[pool];
  const out: string[] = [];
  for (let i = 0; i < count; i += 1) out.push(list[(index + i) % list.length]);
  return out;
}

export const BANNER_ART = {
  hero: px(18311089, 900),
  mega: px(27256470, 700),
  home: px(36573009, 700),
};
