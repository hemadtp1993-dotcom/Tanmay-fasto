import { and, desc, eq, inArray, isNull, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  cartItems,
  coupons,
  notifications,
  orderItems,
  orders,
  products,
  recentlyViewed,
  returnRequests,
  wishlistItems,
  type Product,
} from "@/db/schema";
import { scope } from "./auth";

export const FREE_DELIVERY_THRESHOLD = 499;
export const DELIVERY_FEE = 49;

export type CartLine = {
  id: number;
  quantity: number;
  size: string | null;
  color: string | null;
  savedForLater: boolean;
  product: Product;
};

export async function getCart(includeSaved = true): Promise<CartLine[]> {
  const { visitorId, userId } = await scope();
  const owner = userId ? or(eq(cartItems.userId, userId), eq(cartItems.visitorId, visitorId)) : eq(cartItems.visitorId, visitorId);
  const rows = await db
    .select({ line: cartItems, product: products })
    .from(cartItems)
    .innerJoin(products, eq(products.id, cartItems.productId))
    .where(owner)
    .orderBy(desc(cartItems.createdAt));
  return rows
    .filter((r) => includeSaved || !r.line.savedForLater)
    .map((r) => ({
      id: r.line.id,
      quantity: r.line.quantity,
      size: r.line.size,
      color: r.line.color,
      savedForLater: r.line.savedForLater,
      product: r.product,
    }));
}

export async function addToCart(input: { productId: number; quantity?: number; size?: string | null; color?: string | null }) {
  const { visitorId, userId } = await scope();
  const existing = await db
    .select()
    .from(cartItems)
    .where(
      and(
        eq(cartItems.visitorId, visitorId),
        eq(cartItems.productId, input.productId),
        eq(cartItems.savedForLater, false),
        input.size ? eq(cartItems.size, input.size) : isNull(cartItems.size),
        input.color ? eq(cartItems.color, input.color) : isNull(cartItems.color),
      ),
    )
    .limit(1);

  if (existing[0]) {
    await db
      .update(cartItems)
      .set({ quantity: Math.min(10, existing[0].quantity + (input.quantity ?? 1)), userId, savedForLater: false })
      .where(eq(cartItems.id, existing[0].id));
    return existing[0].id;
  }
  const [row] = await db
    .insert(cartItems)
    .values({
      visitorId,
      userId,
      productId: input.productId,
      quantity: input.quantity ?? 1,
      size: input.size ?? null,
      color: input.color ?? null,
    })
    .returning({ id: cartItems.id });
  return row.id;
}

export async function getWishlistIds(): Promise<number[]> {
  const { visitorId, userId } = await scope();
  const owner = userId ? or(eq(wishlistItems.userId, userId), eq(wishlistItems.visitorId, visitorId)) : eq(wishlistItems.visitorId, visitorId);
  const rows = await db.select({ productId: wishlistItems.productId }).from(wishlistItems).where(owner);
  return [...new Set(rows.map((r) => r.productId))];
}

export async function getWishlistProducts(): Promise<Product[]> {
  const ids = await getWishlistIds();
  if (!ids.length) return [];
  return db.select().from(products).where(inArray(products.id, ids));
}

export async function toggleWishlist(productId: number): Promise<boolean> {
  const { visitorId, userId } = await scope();
  const existing = await db
    .select()
    .from(wishlistItems)
    .where(and(eq(wishlistItems.visitorId, visitorId), eq(wishlistItems.productId, productId)))
    .limit(1);
  if (existing[0]) {
    await db.delete(wishlistItems).where(eq(wishlistItems.id, existing[0].id));
    return false;
  }
  await db.insert(wishlistItems).values({ visitorId, userId, productId });
  return true;
}

export async function trackView(productId: number): Promise<void> {
  try {
    const { visitorId, userId } = await scope();
    await db
      .delete(recentlyViewed)
      .where(and(eq(recentlyViewed.visitorId, visitorId), eq(recentlyViewed.productId, productId)));
    await db.insert(recentlyViewed).values({ visitorId, userId, productId });
  } catch (error) {
    console.error("[fasto] trackView", error);
  }
}

export async function getRecentlyViewed(limit = 10): Promise<Product[]> {
  const { visitorId, userId } = await scope();
  if (visitorId === "anon") return [];
  const owner = userId ? or(eq(recentlyViewed.userId, userId), eq(recentlyViewed.visitorId, visitorId)) : eq(recentlyViewed.visitorId, visitorId);
  const rows = await db
    .select({ product: products, viewedAt: recentlyViewed.viewedAt })
    .from(recentlyViewed)
    .innerJoin(products, eq(products.id, recentlyViewed.productId))
    .where(owner)
    .orderBy(desc(recentlyViewed.viewedAt))
    .limit(limit);
  return rows.map((r) => r.product);
}

/* -------------------------------- coupons -------------------------------- */

export type CouponResult = {
  ok: boolean;
  code: string;
  message: string;
  discount: number;
  freeShipping: boolean;
};

export async function evaluateCoupon(code: string, subtotal: number): Promise<CouponResult> {
  const normalized = code.trim().toUpperCase();
  const rows = await db.select().from(coupons).where(eq(coupons.code, normalized)).limit(1);
  const coupon = rows[0];
  if (!coupon || !coupon.active) return { ok: false, code: normalized, message: "That coupon code is not valid.", discount: 0, freeShipping: false };
  if (coupon.expiresAt && coupon.expiresAt.getTime() < Date.now())
    return { ok: false, code: normalized, message: "This coupon has expired.", discount: 0, freeShipping: false };
  if (subtotal < coupon.minCart)
    return {
      ok: false,
      code: normalized,
      message: `Add items worth ₹${(coupon.minCart - subtotal).toLocaleString("en-IN")} more to use ${normalized}.`,
      discount: 0,
      freeShipping: false,
    };

  if (coupon.type === "percent") {
    const discount = Math.min(Math.round((subtotal * coupon.value) / 100), coupon.maxDiscount);
    return { ok: true, code: normalized, message: `${coupon.value}% off applied`, discount, freeShipping: false };
  }
  if (coupon.value === 0) return { ok: true, code: normalized, message: "Free delivery applied", discount: 0, freeShipping: true };
  return { ok: true, code: normalized, message: `Flat ₹${coupon.value} off applied`, discount: Math.min(coupon.value, subtotal), freeShipping: false };
}

export async function listCoupons() {
  return db.select().from(coupons).where(eq(coupons.active, true)).orderBy(desc(coupons.minCart));
}

/* -------------------------------- totals --------------------------------- */

export function computeTotals(
  lines: CartLine[],
  options: { discount?: number; freeShipping?: boolean; coinsUsed?: number } = {},
) {
  const active = lines.filter((l) => !l.savedForLater);
  const itemsTotal = active.reduce((sum, l) => sum + l.product.price * l.quantity, 0);
  const mrpTotal = active.reduce((sum, l) => sum + l.product.mrp * l.quantity, 0);
  const catalogueDiscount = mrpTotal - itemsTotal;
  const couponDiscount = Math.min(options.discount ?? 0, itemsTotal);
  const netAfterCoupon = itemsTotal - couponDiscount;
  const deliveryFee = options.freeShipping || netAfterCoupon >= FREE_DELIVERY_THRESHOLD || netAfterCoupon === 0 ? 0 : DELIVERY_FEE;
  const coinsUsed = Math.min(options.coinsUsed ?? 0, Math.floor(netAfterCoupon / 2));
  const total = Math.max(0, netAfterCoupon + deliveryFee - coinsUsed);
  return {
    itemCount: active.reduce((n, l) => n + l.quantity, 0),
    itemsTotal,
    mrpTotal,
    catalogueDiscount,
    couponDiscount,
    deliveryFee,
    coinsUsed,
    total,
    savings: catalogueDiscount + couponDiscount + coinsUsed,
  };
}

/* -------------------------------- orders --------------------------------- */

export type PlaceOrderInput = {
  address: Record<string, string>;
  paymentMethod: string;
  paymentStatus: string;
  paymentRef?: string | null;
  couponCode?: string | null;
  discount: number;
  freeShipping: boolean;
  coinsUsed?: number;
  email: string;
  phone: string;
};

export async function placeOrder(input: PlaceOrderInput) {
  const { visitorId, userId } = await scope();
  const lines = (await getCart(false)).filter((l) => !l.savedForLater);
  if (!lines.length) throw new Error("Your cart is empty");

  const totals = computeTotals(lines, {
    discount: input.discount,
    freeShipping: input.freeShipping,
    coinsUsed: input.coinsUsed,
  });

  const orderNumber = `FASTO-${Date.now().toString().slice(-8)}`;
  const timeline = [
    { label: "Order placed", at: new Date().toISOString(), done: true },
    { label: "Packed at FASTO hub", at: null, done: false },
    { label: "Shipped", at: null, done: false },
    { label: "Out for delivery", at: null, done: false },
    { label: "Delivered", at: null, done: false },
  ];

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber,
      userId,
      visitorId,
      email: input.email,
      phone: input.phone,
      shippingAddress: input.address,
      itemsTotal: totals.itemsTotal,
      discount: totals.couponDiscount,
      deliveryFee: totals.deliveryFee,
      couponCode: input.couponCode ?? null,
      total: totals.total,
      paymentMethod: input.paymentMethod,
      paymentStatus: input.paymentStatus,
      paymentRef: input.paymentRef ?? null,
      status: "confirmed",
      timeline,
    })
    .returning();

  await db.insert(orderItems).values(
    lines.map((l) => ({
      orderId: order.id,
      productId: l.product.id,
      slug: l.product.slug,
      title: l.product.title,
      image: l.product.images[0] ?? "",
      price: l.product.price,
      quantity: l.quantity,
      size: l.size,
      color: l.color,
      itemStatus: "active",
    })),
  );

  for (const l of lines) {
    await db
      .update(products)
      .set({
        stock: sql`greatest(0, ${products.stock} - ${l.quantity})`,
        soldCount: sql`${products.soldCount} + ${l.quantity}`,
      })
      .where(eq(products.id, l.product.id));
  }

  if (userId) {
    await db.insert(notifications).values({
      userId,
      title: `Order ${orderNumber} confirmed`,
      body: `We received your payment of ₹${totals.total.toLocaleString("en-IN")}. Tracking updates will appear here.`,
      kind: "order",
      href: `/account/orders/${orderNumber}`,
    });
  }

  await db
    .delete(cartItems)
    .where(
      userId
        ? or(eq(cartItems.userId, userId), eq(cartItems.visitorId, visitorId))
        : and(eq(cartItems.visitorId, visitorId), eq(cartItems.savedForLater, false)),
    );

  return { order, totals };
}

export async function getOrdersForUser(userId: number) {
  const rows = await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  if (!rows.length) return [];
  const items = await db
    .select()
    .from(orderItems)
    .where(inArray(orderItems.orderId, rows.map((r) => r.id)));
  return rows.map((o) => ({ ...o, items: items.filter((i) => i.orderId === o.id) }));
}

export async function getOrderByNumber(orderNumber: string) {
  const rows = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  const order = rows[0];
  if (!order) return null;
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  return { ...order, items };
}

export async function getReturnsForUser(userId: number) {
  return db.select().from(returnRequests).where(eq(returnRequests.userId, userId)).orderBy(desc(returnRequests.createdAt));
}
