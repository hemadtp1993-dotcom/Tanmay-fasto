import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  addresses,
  banners,
  categories,
  coupons,
  notifications,
  orderItems,
  orders,
  paymentMethods,
  products,
  reviews,
  searchLogs,
  users,
} from "@/db/schema";
import { hashPassword, referralCode } from "./auth";
import { gallery } from "./images";
import { SEED_BANNERS, SEED_CATEGORIES, SEED_COUPONS, SEED_PRODUCTS } from "./seed-data";
import { slugify } from "./format";

let seedPromise: Promise<void> | null = null;

const REVIEW_AUTHORS = [
  ["Ananya Sharma", "Worth every rupee", "Ordered on Monday, delivered Wednesday. Quality is exactly as described in the listing — no surprises."],
  ["Rohit Verma", "Great value for money", "Compared 4 options before buying this. Packaging was excellent and the finish feels premium."],
  ["Meera Iyer", "Exactly as shown", "Second purchase from FASTO. The product photos are accurate which is why I keep coming back."],
  ["Karthik Reddy", "Good, with one small note", "Works well overall. Delivery was quick to Bengaluru and support answered my question in 10 minutes."],
  ["Simran Kaur", "Gifted it, loved it", "Bought this for my sister. She uses it daily now. Would recommend without hesitation."],
];

function daysAgo(n: number): Date {
  return new Date(Date.now() - n * 24 * 60 * 60 * 1000);
}

function timeline(status: string) {
  const flow = [
    { label: "Order placed", key: "confirmed" },
    { label: "Packed at FASTO hub", key: "packed" },
    { label: "Shipped", key: "shipped" },
    { label: "Out for delivery", key: "out_for_delivery" },
    { label: "Delivered", key: "delivered" },
  ];
  const index = Math.max(0, flow.findIndex((f) => f.key === status));
  return flow.map((f, i) => ({
    label: f.label,
    at: i <= index ? daysAgo(6 - i * 1).toISOString() : null,
    done: i <= index && status !== "cancelled",
  }));
}

async function runSeed(): Promise<void> {
  const existing = await db.select({ count: sql<number>`count(*)::int` }).from(products);
  if ((existing[0]?.count ?? 0) > 0) return;

  const catRows = await db
    .insert(categories)
    .values(
      SEED_CATEGORIES.map((c, i) => ({
        name: c.name,
        slug: c.slug,
        icon: c.icon,
        tagline: c.tagline,
        featured: true,
        sortOrder: i,
      })),
    )
    .onConflictDoNothing()
    .returning();

  const flashEnds = new Date(Date.now() + 3 * 60 * 60 * 1000);
  const productRows = await db
    .insert(products)
    .values(
      SEED_PRODUCTS.map((p, i) => ({
        slug: slugify(p.title),
        title: p.title,
        brand: p.brand,
        categorySlug: p.category,
        shortDescription: p.highlights[0] ?? "",
        description: p.description,
        specs: p.specs.map(([label, value]) => ({ label, value })),
        highlights: p.highlights,
        images: gallery(p.pool, p.img),
        colors: p.colors ?? [],
        sizes: p.sizes ?? [],
        price: p.price,
        mrp: p.mrp,
        stock: p.stock,
        rating: p.rating,
        reviewCount: p.reviewCount,
        soldCount: p.sold,
        badges: p.badges ?? [],
        isFlashSale: (p.flags ?? []).includes("flash"),
        flashEndsAt: (p.flags ?? []).includes("flash") ? flashEnds : null,
        trending: (p.flags ?? []).includes("trending"),
        bestseller: (p.flags ?? []).includes("best"),
        newArrival: (p.flags ?? []).includes("new"),
        createdAt: daysAgo(60 - i),
      })),
    )
    .returning({ id: products.id, slug: products.slug });

  const reviewValues = productRows.flatMap((row, idx) =>
    [0, 1, 2].map((r) => {
      const [authorName, title, body] = REVIEW_AUTHORS[(idx + r) % REVIEW_AUTHORS.length];
      return {
        productId: row.id,
        authorName,
        rating: [5, 4, 5, 4, 5][(idx + r) % 5],
        title,
        body,
        helpfulCount: 4 + ((idx * 7 + r * 3) % 40),
        createdAt: daysAgo((idx + r) % 40),
      };
    }),
  );
  await db.insert(reviews).values(reviewValues);

  await db.insert(coupons).values(
    SEED_COUPONS.map((c) => ({
      code: c.code,
      title: c.title,
      description: c.description,
      type: c.type,
      value: c.value,
      minCart: c.minCart,
      maxDiscount: c.maxDiscount,
      active: true,
      expiresAt: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
    })),
  ).onConflictDoNothing();

  await db.insert(banners).values(SEED_BANNERS.map((b) => ({ ...b, active: true })));

  const inserted = await db
    .insert(users)
    .values([
      {
        name: "FASTO Admin",
        email: "admin@fasto.in",
        phone: "9876543210",
        passwordHash: hashPassword("Admin@123"),
        role: "admin",
        referralCode: referralCode("FASTO Admin"),
        fastoCoins: 0,
      },
      {
        name: "Aarav Mehta",
        email: "demo@fasto.in",
        phone: "9812345678",
        passwordHash: hashPassword("Demo@123"),
        role: "customer",
        referralCode: referralCode("Aarav Mehta"),
        walletBalance: 250,
        fastoCoins: 1240,
        createdAt: daysAgo(120),
      },
    ])
    .onConflictDoNothing()
    .returning({ id: users.id, email: users.email });

  const demo = inserted.find((u) => u.email === "demo@fasto.in");
  if (demo) {
    await db.insert(addresses).values([
      {
        userId: demo.id,
        label: "Home",
        fullName: "Aarav Mehta",
        phone: "9812345678",
        line1: "402, Sunrise Residency, 12th Main Road",
        line2: "Indiranagar",
        landmark: "Near Metro Station",
        city: "Bengaluru",
        state: "Karnataka",
        pincode: "560038",
        isDefault: true,
      },
      {
        userId: demo.id,
        label: "Work",
        fullName: "Aarav Mehta",
        phone: "9812345678",
        line1: "WeWork Galaxy, 4th Floor, Residency Road",
        city: "Bengaluru",
        state: "Karnataka",
        pincode: "560025",
        isDefault: false,
      },
    ]);

    await db.insert(paymentMethods).values([
      { userId: demo.id, kind: "upi", label: "HDFC UPI", detail: "aarav@okhdfcbank", isDefault: true },
      { userId: demo.id, kind: "card", label: "Visa Credit", detail: "Visa •••• 4291", isDefault: false },
    ]);

    await db.insert(notifications).values([
      { userId: demo.id, title: "Your order is out for delivery", body: "FASTO-240881 will arrive today between 4 PM and 7 PM.", kind: "order", href: "/account?tab=orders" },
      { userId: demo.id, title: "Mega Saver Days are live", body: "Up to 70% off on phones, fashion and home essentials.", kind: "offer", href: "/products?sort=discount" },
      { userId: demo.id, title: "You earned 240 FASTO coins", body: "Coins from your last order are now usable at checkout.", kind: "reward" },
    ]);

    const orderSeeds: Array<{ status: string; payment: string; paymentStatus: string; picks: number[]; day: number }> = [
      { status: "delivered", payment: "upi", paymentStatus: "paid", picks: [0, 2], day: 9 },
      { status: "out_for_delivery", payment: "card", paymentStatus: "paid", picks: [14, 20], day: 3 },
      { status: "packed", payment: "cod", paymentStatus: "pending", picks: [26], day: 1 },
    ];

    for (let i = 0; i < orderSeeds.length; i += 1) {
      const o = orderSeeds[i];
      const items = o.picks.map((pi) => {
        const row = SEED_PRODUCTS[pi];
        return {
          productId: productRows[pi].id,
          slug: productRows[pi].slug,
          title: row.title,
          image: gallery(row.pool, row.img)[0],
          price: row.price,
          quantity: 1,
          size: row.sizes?.[0] ?? null,
          color: row.colors?.[0] ?? null,
          itemStatus: "active",
        };
      });
      const itemsTotal = items.reduce((s, it) => s + it.price * it.quantity, 0);
      const discount = Math.round(itemsTotal * 0.08);
      const deliveryFee = itemsTotal - discount > 499 ? 0 : 49;
      const [order] = await db
        .insert(orders)
        .values({
          orderNumber: `FASTO-${240881 + i}`,
          userId: demo.id,
          email: "demo@fasto.in",
          phone: "9812345678",
          shippingAddress: {
            fullName: "Aarav Mehta",
            phone: "9812345678",
            line1: "402, Sunrise Residency, 12th Main Road",
            city: "Bengaluru",
            state: "Karnataka",
            pincode: "560038",
          },
          itemsTotal,
          discount,
          deliveryFee,
          couponCode: "MEGA20",
          total: itemsTotal - discount + deliveryFee,
          paymentMethod: o.payment,
          paymentStatus: o.paymentStatus,
          paymentRef: o.paymentStatus === "paid" ? `pay_${1000 + i}KxQz` : null,
          status: o.status,
          timeline: timeline(o.status),
          createdAt: daysAgo(o.day),
        })
        .returning({ id: orders.id });
      await db.insert(orderItems).values(items.map((it) => ({ ...it, orderId: order.id })));
    }
  }

  await db.insert(searchLogs).values(
    ["wireless earbuds", "running shoes", "iphone alternative", "vitamin c serum", "air fryer", "oversized tshirt", "smartwatch", "coffee maker"].map(
      (term, i) => ({ term, hits: 980 - i * 61 }),
    ),
  );

  void catRows;
}

/** Idempotently populates the catalogue. Safe to call on every request. */
export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      console.error("[fasto] seed failed", error);
    });
  }
  return seedPromise;
}
