export const INR = "₹";

export function rupees(value: number): string {
  return `${INR}${Math.round(value).toLocaleString("en-IN")}`;
}

export function rupeesDetailed(value: number): string {
  return `${INR}${value.toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}

export function discountPercent(mrp: number, price: number): number {
  if (!mrp || mrp <= price) return 0;
  return Math.round(((mrp - price) / mrp) * 100);
}

export function formatDate(value: Date | string | null | undefined): string {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

export function formatDateTime(value: Date | string | null | undefined): string {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  return `${formatDate(d)}, ${d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}`;
}

export function deliveryPromise(pincode?: string | null): string {
  const base = pincode ? pincode.charCodeAt(0) % 3 : 1;
  const days = 2 + base;
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toLocaleDateString("en-IN", { weekday: "short", day: "2-digit", month: "short" });
}

export function initials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

export const ORDER_STATUS_LABEL: Record<string, string> = {
  confirmed: "Order confirmed",
  packed: "Packed at fulfilment centre",
  shipped: "Shipped",
  out_for_delivery: "Out for delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export const ORDER_FLOW = ["confirmed", "packed", "shipped", "out_for_delivery", "delivered"] as const;

export function statusTone(status: string): string {
  switch (status) {
    case "delivered":
    case "paid":
      return "bg-emerald-500/12 text-emerald-600 dark:text-emerald-400";
    case "shipped":
    case "out_for_delivery":
    case "packed":
      return "bg-brand-500/12 text-brand-600 dark:text-brand-300";
    case "cancelled":
    case "failed":
      return "bg-rose-500/12 text-rose-600 dark:text-rose-400";
    case "pending":
      return "bg-amber-500/15 text-amber-600 dark:text-amber-400";
    default:
      return "bg-ink-400/12 text-ink-600 dark:text-ink-200";
  }
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .slice(0, 70);
}
