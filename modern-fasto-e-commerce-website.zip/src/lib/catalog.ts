import { and, asc, desc, eq, gte, ilike, inArray, lte, ne, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { banners, categories, products, reviews, searchLogs, type Product } from "@/db/schema";
import { ensureSeeded } from "./seed";

export type { Product };

export async function getCategories() {
  await ensureSeeded();
  return db.select().from(categories).orderBy(asc(categories.sortOrder));
}

export async function getBanners(placement?: string) {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(banners)
    .where(placement ? and(eq(banners.active, true), eq(banners.placement, placement)) : eq(banners.active, true))
    .orderBy(asc(banners.sortOrder));
  return rows;
}

type Flag = "flash" | "trending" | "bestseller" | "newArrival";

async function byFlag(flag: Flag, limit: number) {
  await ensureSeeded();
  const column = {
    flash: products.isFlashSale,
    trending: products.trending,
    bestseller: products.bestseller,
    newArrival: products.newArrival,
  }[flag];
  return db.select().from(products).where(eq(column, true)).orderBy(desc(products.rating)).limit(limit);
}

export const getFlashDeals = (limit = 8) => byFlag("flash", limit);
export const getTrending = (limit = 12) => byFlag("trending", limit);
export const getBestsellers = (limit = 12) => byFlag("bestseller", limit);
export const getNewArrivals = (limit = 12) => byFlag("newArrival", limit);

export async function getRecommended(limit = 12) {
  await ensureSeeded();
  return db.select().from(products).orderBy(desc(products.soldCount)).limit(limit);
}

export async function getTopDeals(limit = 10) {
  await ensureSeeded();
  return db
    .select()
    .from(products)
    .where(gte(products.mrp, sql`${products.price} * 2`))
    .orderBy(desc(sql`(${products.mrp} - ${products.price})::float / ${products.mrp}`))
    .limit(limit);
}

export async function getProductBySlug(slug: string) {
  await ensureSeeded();
  const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getProductsByIds(ids: number[]) {
  if (!ids.length) return [];
  return db.select().from(products).where(inArray(products.id, ids));
}

export async function getSimilar(product: Product, limit = 8) {
  return db
    .select()
    .from(products)
    .where(and(eq(products.categorySlug, product.categorySlug), ne(products.id, product.id)))
    .orderBy(desc(products.rating))
    .limit(limit);
}

export async function getProductReviews(productId: number, limit = 12) {
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.productId, productId))
    .orderBy(desc(reviews.helpfulCount))
    .limit(limit);
}

export async function getPopularSearches(limit = 8) {
  await ensureSeeded();
  return db.select().from(searchLogs).orderBy(desc(searchLogs.hits)).limit(limit);
}

/* --------------------------------- search -------------------------------- */

export type SearchParams = {
  q?: string;
  category?: string;
  brands?: string[];
  sizes?: string[];
  colors?: string[];
  minPrice?: number;
  maxPrice?: number;
  rating?: number;
  inStock?: boolean;
  tag?: string;
  sort?: string;
  page?: number;
  perPage?: number;
};

function buildWhere(p: SearchParams) {
  const clauses = [];
  if (p.q) {
    const like = `%${p.q}%`;
    clauses.push(
      or(ilike(products.title, like), ilike(products.brand, like), ilike(products.categorySlug, like), ilike(products.shortDescription, like)),
    );
  }
  if (p.category) clauses.push(eq(products.categorySlug, p.category));
  if (p.brands?.length) clauses.push(inArray(products.brand, p.brands));
  if (p.minPrice != null) clauses.push(gte(products.price, p.minPrice));
  if (p.maxPrice != null) clauses.push(lte(products.price, p.maxPrice));
  if (p.rating != null) clauses.push(gte(products.rating, p.rating));
  if (p.inStock) clauses.push(gte(products.stock, 1));
  if (p.sizes?.length) clauses.push(sql`${products.sizes}::text ilike any(array[${sql.join(p.sizes.map((s) => sql`${`%${s}%`}`), sql`, `)}])`);
  if (p.colors?.length) clauses.push(sql`${products.colors}::text ilike any(array[${sql.join(p.colors.map((c) => sql`${`%${c}%`}`), sql`, `)}])`);
  if (p.tag === "flash") clauses.push(eq(products.isFlashSale, true));
  if (p.tag === "new") clauses.push(eq(products.newArrival, true));
  if (p.tag === "best") clauses.push(eq(products.bestseller, true));
  if (p.tag === "trending") clauses.push(eq(products.trending, true));
  return clauses.length ? and(...clauses) : undefined;
}

function orderBy(sort?: string) {
  switch (sort) {
    case "price_asc":
      return asc(products.price);
    case "price_desc":
      return desc(products.price);
    case "rating":
      return desc(products.rating);
    case "newest":
      return desc(products.createdAt);
    case "discount":
      return desc(sql`(${products.mrp} - ${products.price})::float / ${products.mrp}`);
    default:
      return desc(products.soldCount);
  }
}

export async function searchProducts(p: SearchParams) {
  await ensureSeeded();
  const perPage = p.perPage ?? 20;
  const page = Math.max(1, p.page ?? 1);
  const where = buildWhere(p);

  const items = await db
    .select()
    .from(products)
    .where(where)
    .orderBy(orderBy(p.sort))
    .limit(perPage)
    .offset((page - 1) * perPage);

  const countRows = await db.select({ count: sql<number>`count(*)::int` }).from(products).where(where);
  const total = countRows[0]?.count ?? 0;

  // Facets are derived from the query text + category only, so filters stay usable.
  const facetWhere = buildWhere({ q: p.q, category: p.category, tag: p.tag });
  const brandFacets = await db
    .select({ brand: products.brand, count: sql<number>`count(*)::int` })
    .from(products)
    .where(facetWhere)
    .groupBy(products.brand)
    .orderBy(desc(sql`count(*)`))
    .limit(14);

  const rangeRows = await db
    .select({ min: sql<number>`coalesce(min(${products.price}),0)::int`, max: sql<number>`coalesce(max(${products.price}),0)::int` })
    .from(products)
    .where(facetWhere);

  return {
    items,
    total,
    page,
    perPage,
    pages: Math.max(1, Math.ceil(total / perPage)),
    facets: {
      brands: brandFacets,
      priceMin: rangeRows[0]?.min ?? 0,
      priceMax: rangeRows[0]?.max ?? 100000,
    },
  };
}

export async function suggest(term: string, limit = 8) {
  await ensureSeeded();
  if (!term.trim()) return [];
  const like = `%${term.trim()}%`;
  return db
    .select({
      id: products.id,
      slug: products.slug,
      title: products.title,
      brand: products.brand,
      price: products.price,
      mrp: products.mrp,
      images: products.images,
      rating: products.rating,
    })
    .from(products)
    .where(or(ilike(products.title, like), ilike(products.brand, like)))
    .orderBy(desc(products.soldCount))
    .limit(limit);
}

export async function getAdminStats() {
  await ensureSeeded();
  const [productAgg] = await db
    .select({
      count: sql<number>`count(*)::int`,
      outOfStock: sql<number>`count(*) filter (where ${products.stock} = 0)::int`,
      lowStock: sql<number>`count(*) filter (where ${products.stock} > 0 and ${products.stock} < 10)::int`,
    })
    .from(products);

  const categoryAgg = await db
    .select({ category: products.categorySlug, count: sql<number>`count(*)::int`, avgRating: sql<number>`round(avg(${products.rating})::numeric, 2)::float` })
    .from(products)
    .groupBy(products.categorySlug)
    .orderBy(desc(sql`count(*)`));

  return { productAgg, categoryAgg };
}
