import type { PoolKey } from "./images";

export type SeedCategory = {
  name: string;
  slug: string;
  icon: string;
  tagline: string;
};

export const SEED_CATEGORIES: SeedCategory[] = [
  { name: "Mobiles & Tablets", slug: "mobiles", icon: "📱", tagline: "5G flagships & tabs" },
  { name: "Electronics", slug: "electronics", icon: "💻", tagline: "Laptops, audio, gear" },
  { name: "Fashion", slug: "fashion", icon: "👕", tagline: "Everyday & festive wear" },
  { name: "Footwear", slug: "footwear", icon: "👟", tagline: "Sneakers to formals" },
  { name: "Watches & Wearables", slug: "watches", icon: "⌚", tagline: "Smart & analog" },
  { name: "Home & Kitchen", slug: "home", icon: "🏠", tagline: "Upgrade your space" },
  { name: "Beauty & Wellness", slug: "beauty", icon: "💄", tagline: "Skin, hair, self-care" },
  { name: "Sports & Fitness", slug: "fitness", icon: "🏋️", tagline: "Train anywhere" },
  { name: "Grocery & Gourmet", slug: "grocery", icon: "🛒", tagline: "Daily essentials" },
  { name: "Toys & Baby", slug: "toys", icon: "🧸", tagline: "Play, learn, grow" },
];

export type SeedProduct = {
  title: string;
  brand: string;
  category: string;
  pool: PoolKey;
  img: number;
  price: number;
  mrp: number;
  stock: number;
  rating: number;
  reviewCount: number;
  sold: number;
  colors?: string[];
  sizes?: string[];
  flags?: Array<"flash" | "trending" | "best" | "new">;
  badges?: string[];
  highlights: string[];
  description: string;
  specs: Array<[string, string]>;
};

const P = (
  title: string,
  brand: string,
  category: string,
  pool: PoolKey,
  img: number,
  price: number,
  mrp: number,
  rating: number,
  reviewCount: number,
  sold: number,
  highlights: string[],
  description: string,
  specs: Array<[string, string]>,
  extra: Partial<SeedProduct> = {},
): SeedProduct => ({
  title,
  brand,
  category,
  pool,
  img,
  price,
  mrp,
  rating,
  reviewCount,
  sold,
  highlights,
  description,
  specs,
  stock: extra.stock ?? 45,
  badges: extra.badges ?? [],
  colors: extra.colors ?? [],
  sizes: extra.sizes ?? [],
  flags: extra.flags ?? [],
});

export const SEED_PRODUCTS: SeedProduct[] = [
  /* ------------------------------ mobiles ------------------------------ */
  P("Nexora N14 Pro 5G (256 GB, Nebula Black)", "Nexora", "mobiles", "tech", 0, 32999, 44999, 4.5, 12840, 31200,
    ["6.7\" 120Hz AMOLED display", "50MP OIS AirLight camera", "5000 mAh | 80W turbo charge", "4 years of security updates"],
    "The Nexora N14 Pro is built for people who refuse to wait. A 120Hz AMOLED panel keeps scrolling buttery smooth while the vapour-chamber cooled Snapdragon-class chipset handles long gaming sessions without throttling. The 50MP OIS main sensor locks focus fast, so festival shots and night street photography come out sharp every single time.",
    [["Display", "6.7-inch FHD+ AMOLED, 120Hz"], ["Processor", "Octa-core 4nm flagship"], ["Memory", "8 GB RAM, 256 GB UFS 3.1"], ["Camera", "50MP OIS + 8MP UW + 2MP Macro"], ["Battery", "5000 mAh, 80W wired"], ["Warranty", "1 year manufacturer"]],
    { colors: ["Nebula Black", "Frost Silver", "Aurora Green"], badges: ["FASTO's Choice"], flags: ["trending", "best", "flash"] }),

  P("Nexora Tab S9 11-inch Wi-Fi + LTE", "Nexora", "mobiles", "tech", 4, 21499, 28999, 4.3, 4120, 8600,
    ["11-inch 2.5K 90Hz screen", "Quad speakers with Dolby tuning", "8200 mAh all-day battery", "Kids space + stylus support"],
    "A genuinely useful tablet for study, streaming and sketching. The 2.5K panel is TUV certified for low blue light, quad speakers make movie nights loud and clear, and the optional stylus supports 4096 pressure levels for note taking.",
    [["Display", "11-inch 2.5K IPS, 90Hz"], ["Audio", "Quad speakers"], ["Battery", "8200 mAh"], ["Storage", "128 GB + microSD"], ["Warranty", "1 year manufacturer"]],
    { colors: ["Graphite", "Mist Blue"], flags: ["new"] }),

  P("Voltrix Vibe Buds 3 ANC TWS Earbuds", "Voltrix", "mobiles", "tech", 2, 1899, 4999, 4.2, 30210, 96500,
    ["42dB hybrid active noise cancelling", "60 hours total playback", "Low-latency game mode (45ms)", "IPX5 sweat resistant"],
    "Block the metro, not your music. Vibe Buds 3 use hybrid ANC with six microphones to cancel commute noise, and a transparent mode that lets conversations in. 10 minutes of charging buys you 5 hours of playback.",
    [["Driver", "12mm titanium coated"], ["ANC", "Hybrid, up to 42dB"], ["Playback", "60 hours with case"], ["Bluetooth", "v5.3, dual device pairing"], ["Warranty", "1 year"]],
    { colors: ["Ivory", "Midnight", "Neon Lime"], flags: ["best", "flash", "trending"] }),

  P("Voltrix Pulse Fit 2 Smartwatch AMOLED", "Voltrix", "watches", "tech", 8, 2799, 7999, 4.1, 8940, 41200,
    ["1.85\" AMOLED always-on display", "SpO2, HR & sleep tracking", "120+ sports modes", "7 day battery, IP68"],
    "Pulse Fit 2 tracks the numbers that matter and stays readable in harsh Indian sunlight. Bluetooth calling, 120 sports modes and a 7-day battery make it the easiest fitness upgrade you can gift.",
    [["Display", "1.85-inch AMOLED"], ["Sensors", "HR, SpO2, accelerometer"], ["Battery", "7 days typical use"], ["Water resistance", "IP68"], ["Warranty", "1 year"]],
    { colors: ["Jet Black", "Rose Gold", "Steel"], sizes: ["Free size"], flags: ["trending", "flash"] }),

  P("Chronova Regal Automatic Watch, Sapphire", "Chronova", "watches", "fashion", 6, 8499, 16999, 4.6, 1240, 3100,
    ["Japanese automatic movement", "Sapphire crystal glass", "316L stainless steel case", "5 ATM water resistance"],
    "A proper mechanical watch with an exhibition case back, skeleton dial and a brushed-steel bracelet that wears far above its price. No batteries, no charging — just 40 hours of power reserve.",
    [["Movement", "Automatic, 21 jewels"], ["Case", "40mm stainless steel"], ["Glass", "Sapphire"], ["Water resistance", "5 ATM"], ["Warranty", "2 years"]],
    { colors: ["Silver-Blue", "Gold-Black"], flags: ["new"] }),

  /* ---------------------------- electronics ---------------------------- */
  P("Voltrix AirBook 14 Thin & Light Laptop", "Voltrix", "electronics", "tech", 1, 46990, 62990, 4.4, 3210, 7400,
    ["14\" 2.2K IPS, 100% sRGB", "16 GB LPDDR5 | 512 GB NVMe", "1.24 kg magnesium alloy body", "Backlit keyboard, fingerprint login"],
    "A work machine that disappears into your bag. The AirBook 14 runs cool and quiet through full-day spreadsheets, code and calls, and charges over USB-C so one brick does laptop and phone.",
    [["Display", "14-inch 2.2K IPS"], ["Processor", "Octa-core, 12 threads"], ["Memory", "16 GB LPDDR5"], ["Storage", "512 GB NVMe SSD"], ["Weight", "1.24 kg"], ["Warranty", "1 year onsite"]],
    { colors: ["Space Grey", "Silver"], flags: ["best"] }),

  P("Zephyr Studio 27 QHD Monitor", "Zephyr", "electronics", "tech", 3, 18999, 26999, 4.3, 980, 2600,
    ["27\" QHD IPS, 100Hz", "99% sRGB factory calibrated", "Height + pivot adjustable stand", "USB-C 65W power delivery"],
    "Colour-accurate out of the box with a single-cable USB-C setup for laptops. Slim bezels make dual-monitor setups almost seamless.",
    [["Panel", "27-inch QHD IPS"], ["Refresh", "100Hz"], ["Ports", "2x HDMI, DP, USB-C 65W"], ["Stand", "Height, tilt, pivot"], ["Warranty", "3 years"]],
    { flags: ["new"] }),

  P("Voltrix BoomBox 40W Party Speaker", "Voltrix", "electronics", "tech", 9, 3499, 6999, 4.2, 6710, 15800,
    ["40W stereo with dual passive radiator", "IPX6 splash proof", "24 hour playtime", "TWS pairing for 80W"],
    "Room-filling sound with punchy bass that survives a balcony party. Pair two for true stereo or let one run the whole night on a single charge.",
    [["Output", "40W RMS"], ["Battery", "24 hours"], ["Rating", "IPX6"], ["Inputs", "Bluetooth 5.3, AUX, USB"], ["Warranty", "1 year"]],
    { colors: ["Black", "Teal"], flags: ["flash", "trending"] }),

  P("Mistral Mech 75 Hot-Swap Keyboard", "Mistral", "electronics", "tech", 5, 4299, 7499, 4.5, 2140, 5200,
    ["Gasket mounted, hot-swap sockets", "Tri-mode: BT / 2.4G / USB-C", "South-facing RGB, PBT keycaps", "4000 mAh battery"],
    "A thocky, pre-lubed 75% board that feels like a hobbyist build on day one. Hot-swap sockets mean you can change switches without a soldering iron.",
    [["Layout", "75% (82 keys)"], ["Switches", "Pre-lubed linear, hot-swap"], ["Connectivity", "BT 5.0 / 2.4G / wired"], ["Keycaps", "PBT double shot"], ["Warranty", "1 year"]],
    { colors: ["Off-White", "Charcoal"], flags: ["new", "trending"] }),

  /* ------------------------------ fashion ------------------------------ */
  P("Urban Loom Oversized Cotton Drop-Shoulder Tee", "Urban Loom", "fashion", "fashion", 3, 649, 1499, 4.2, 15420, 61000,
    ["240 GSM combed cotton", "Pre-shrunk, bio-washed", "Unisex oversized fit", "Colour-locked dyes"],
    "Heavyweight cotton that holds its shape after dozens of washes. Cut with a wider drop shoulder and a boxy body for the relaxed silhouette everyone asks for.",
    [["Fabric", "100% combed cotton, 240 GSM"], ["Fit", "Oversized, drop shoulder"], ["Sleeve", "Half sleeve"], ["Care", "Machine wash cold"], ["Origin", "Made in India"]],
    { colors: ["Off White", "Sage", "Washed Black", "Clay"], sizes: ["S", "M", "L", "XL", "XXL"], flags: ["best", "flash"] }),

  P("Urban Loom Straight-Fit Stretch Denim Jeans", "Urban Loom", "fashion", "fashion", 8, 1199, 2999, 4.1, 8760, 33400,
    ["2% elastane for all-day stretch", "Deep indigo, enzyme wash", "Reinforced pocket bags", "5-pocket classic styling"],
    "Denim that moves with you through a commute and still looks sharp at dinner. Mid-rise, straight leg, no break at the ankle.",
    [["Fabric", "98% cotton, 2% elastane"], ["Rise", "Mid rise"], ["Fit", "Straight"], ["Wash care", "Machine wash inside out"], ["Origin", "Made in India"]],
    { colors: ["Deep Indigo", "Black", "Light Blue"], sizes: ["28", "30", "32", "34", "36", "38"], flags: ["trending"] }),

  P("Aerobloom Printed Rayon Anarkali Kurta", "Aerobloom", "fashion", "fashion", 9, 1099, 2599, 4.3, 4310, 12900,
    ["Flowy rayon with lining", "Hand-block inspired print", "Pocket on both sides", "Festive ready in minutes"],
    "A light, twirl-friendly kurta that photographs beautifully. Pair with juttis and oxidised earrings for an instant festive look.",
    [["Fabric", "Rayon with cotton lining"], ["Length", "Calf length"], ["Sleeve", "Three-quarter"], ["Care", "Gentle machine wash"], ["Origin", "Made in India"]],
    { colors: ["Indigo", "Marigold", "Wine"], sizes: ["XS", "S", "M", "L", "XL", "XXL"], flags: ["new"] }),

  P("Aerobloom Everyday Bralette Pack of 3", "Aerobloom", "fashion", "beauty", 7, 799, 1799, 4.0, 3120, 9800,
    ["Seamless bonded edges", "Breathable modal blend", "No underwire, full comfort", "Pack of 3 assorted"],
    "Soft, wireless and invisible under kurtas and tees. Bonded edges mean no lines and no itch.",
    [["Fabric", "Modal + spandex blend"], ["Pack", "3 pieces"], ["Closure", "Pull-on"], ["Care", "Hand wash"], ["Origin", "Made in India"]],
    { colors: ["Nude", "Black", "Pastel Blue"], sizes: ["S", "M", "L", "XL"] }),

  /* ------------------------------ footwear ----------------------------- */
  P("Zephyr Cloudstep Running Shoes", "Zephyr", "footwear", "fitness", 7, 2299, 4999, 4.4, 9860, 42500,
    ["Memory foam midsole", "Breathable knit upper", "Anti-skid rubber outsole", "Just 240g per shoe"],
    "Built for morning runs and long airport walks. The Cloudstep midsole returns energy on each stride while the knit upper keeps feet cool through Indian summers.",
    [["Upper", "Engineered knit mesh"], ["Midsole", "EVA memory foam"], ["Outsole", "Carbon rubber"], ["Weight", "240 g (UK 8)"], ["Warranty", "6 months"]],
    { colors: ["All Black", "White-Grey", "Neon Coral"], sizes: ["6", "7", "8", "9", "10", "11"], flags: ["best", "flash", "trending"] }),

  P("Zephyr Court Classic Sneakers", "Zephyr", "footwear", "fashion", 8, 1799, 3999, 4.2, 5410, 21800,
    ["Vegan leather upper", "Cupsole for daily wear", "Cushioned heel cradle", "Easy-clean finish"],
    "A clean minimal sneaker that works with jeans, chinos and even kurta-pajama. Wipe clean with a damp cloth.",
    [["Upper", "Vegan leather"], ["Sole", "Cupsole rubber"], ["Closure", "Lace-up"], ["Warranty", "6 months"], ["Origin", "Made in India"]],
    { colors: ["Triple White", "Off White-Gum", "Navy"], sizes: ["6", "7", "8", "9", "10", "11"], flags: ["trending"] }),

  P("Chronova Formal Leather Loafers", "Chronova", "footwear", "fashion", 7, 2599, 5499, 4.3, 1870, 5400,
    ["Genuine leather upper", "Cushioned memory footbed", "Hand-stitched apron", "Slip-resistant TPR sole"],
    "Boardroom-ready loafers that need zero break-in. The footbed is removable, so insoles can be swapped for orthotics.",
    [["Upper", "Genuine leather"], ["Sole", "TPR slip resistant"], ["Footbed", "Removable memory foam"], ["Warranty", "6 months"], ["Origin", "Made in India"]],
    { colors: ["Tan", "Black", "Coffee Brown"], sizes: ["6", "7", "8", "9", "10", "11"], flags: ["best"] }),

  /* -------------------------------- home ------------------------------- */
  P("Casa Nova Brew Pro Espresso Machine", "Casa Nova", "home", "home", 1, 15999, 24999, 4.4, 1420, 3900,
    ["20 bar Italian pump", "Steam wand for latte art", "30-second heat up", "Die-cast body, 1.8L tank"],
    "Cafe-grade shots at home with real 20-bar pressure and a steam wand that actually makes microfoam. Includes a pressurised basket for beginners and a precision basket for pros.",
    [["Pressure", "20 bar"], ["Tank", "1.8 L removable"], ["Heat up", "30 seconds"], ["Power", "1350 W"], ["Warranty", "2 years"]],
    { colors: ["Matte Black", "Brushed Steel"], flags: ["trending", "flash"] }),

  P("Casa Nova Triply Cookware Set (5 pcs)", "Casa Nova", "home", "home", 0, 4999, 9999, 4.5, 2860, 8100,
    ["Triply steel — no hot spots", "Induction + gas compatible", "Riveted cool-touch handles", "Dishwasher safe"],
    "A five-piece foundation set that will outlive your rental agreements. Triply construction spreads heat evenly so dals and gravies never catch at the bottom.",
    [["Material", "Stainless steel triply"], ["Pieces", "2 pans, 2 kadhai, 1 lid"], ["Compatible", "Induction, gas, oven"], ["Warranty", "5 years"], ["Origin", "Made in India"]],
    { flags: ["best"] }),

  P("Casa Nova Linen Weave Curtain Set of 2", "Casa Nova", "home", "home", 7, 1299, 2799, 4.1, 1240, 4200,
    ["Semi-sheer light filtering", "8 eyelets per panel", "5 ft & 7 ft options", "Machine washable"],
    "Soft, textured curtains that diffuse harsh afternoon light without turning your room into a cave.",
    [["Material", "Polyester linen weave"], ["Size", "7 ft x 4 ft each"], ["Pack", "2 panels"], ["Care", "Machine wash cold"], ["Origin", "Made in India"]],
    { colors: ["Ivory", "Sage", "Terracotta", "Charcoal"], sizes: ["5 ft", "7 ft"] }),

  P("Casa Nova Minimal Oak Table Lamp", "Casa Nova", "home", "home", 8, 1799, 3499, 4.3, 890, 2600,
    ["Solid rubberwood base", "Warm 2700K LED included", "Touch dimmer, 3 levels", "1.6 m braided cord"],
    "A quiet, sculptural lamp for bedside tables and study desks. Replaceable LED bulb, no app, no fuss.",
    [["Material", "Rubberwood + fabric shade"], ["Bulb", "E27 LED 9W included"], ["Dimmer", "3-level touch"], ["Warranty", "1 year"], ["Origin", "Made in India"]],
    { flags: ["new"] }),

  /* ------------------------------- beauty ------------------------------ */
  P("Glowveda Vitamin C + Turmeric Face Serum", "Glowveda", "beauty", "beauty", 5, 449, 999, 4.3, 18240, 71000,
    ["10% stable vitamin C", "Turmeric & liquorice root", "Non-sticky, fragrance free", "Dermatologically tested"],
    "A lightweight serum that fades dullness and uneven tone without the sting. Formulated for Indian skin tones and humid weather, it layers cleanly under sunscreen.",
    [["Volume", "30 ml"], ["Key actives", "Vitamin C 10%, Turmeric"], ["Skin type", "All, incl. sensitive"], ["Free from", "Parabens, sulphates"], ["Shelf life", "24 months"]],
    { colors: ["30 ml", "50 ml"], flags: ["best", "flash"] }),

  P("Glowveda Rosehip Cold-Pressed Hair Oil", "Glowveda", "beauty", "beauty", 5, 379, 799, 4.2, 9420, 38500,
    ["Cold pressed, 7 oil blend", "Reduces frizz in 2 washes", "Non-sticky dry-touch finish", "No mineral oil"],
    "A dry-touch oil blend for weekly champi without the greasy aftermath. Rosehip and argan smooth the cuticle, bhringraj supports the scalp.",
    [["Volume", "100 ml"], ["Type", "Cold pressed blend"], ["Free from", "Mineral oil, silicones"], ["Shelf life", "18 months"], ["Origin", "Made in India"]],
    { colors: ["100 ml", "200 ml"] }),

  P("Aerobloom Matte Liquid Lipstick Set of 4", "Aerobloom", "beauty", "beauty", 8, 699, 1599, 4.1, 6320, 21400,
    ["Transfer-proof 10 hr wear", "Enriched with vitamin E", "Indian-skin tuned shades", "Non-drying formula"],
    "Four everyday-nude-to-festive-red shades that survive chai and biryani. The doe-foot applicator gives a crisp edge without a liner.",
    [["Shades", "4 x 4 ml"], ["Finish", "Ultra matte"], ["Wear", "Up to 10 hours"], ["Free from", "Parabens"], ["Origin", "Made in India"]],
    { flags: ["trending"] }),

  P("Glowveda Clay & Charcoal Detox Mask", "Glowveda", "beauty", "beauty", 6, 349, 749, 4.0, 4210, 12600,
    ["Kaolin + activated charcoal", "Unclogs pores in 10 min", "No over-drying", "Suitable for oily skin"],
    "A weekly reset for oily and combination skin. Rinse off to visibly smaller-looking pores without that tight, squeaky feeling.",
    [["Volume", "100 g"], ["Type", "Wash-off clay mask"], ["Use", "1-2 times a week"], ["Free from", "Parabens"], ["Shelf life", "24 months"]],
    { flags: ["new"] }),

  /* ------------------------------- fitness ----------------------------- */
  P("FlexiFit Hex Rubber Dumbbell Set 10 kg", "FlexiFit", "fitness", "fitness", 1, 2299, 4299, 4.4, 5620, 19800,
    ["Rubber coated, floor safe", "Chrome contoured handle", "Sold as a pair", "Rust resistant core"],
    "Home-training staples that will not mark your tiles. Hexagon heads stay put for renegade rows and push-up resets.",
    [["Weight", "5 kg x 2"], ["Material", "Cast iron + rubber"], ["Handle", "Chrome, knurled"], ["Warranty", "1 year"], ["Origin", "Made in India"]],
    { sizes: ["10 kg", "20 kg", "30 kg"], flags: ["best", "flash"] }),

  P("FlexiFit Grip Cork Yoga Mat 6 mm", "FlexiFit", "fitness", "fitness", 2, 1299, 2699, 4.5, 3210, 11400,
    ["Natural cork + TPE base", "Grips harder as you sweat", "6 mm joint cushioning", "Carry strap included"],
    "Cork is naturally antimicrobial and gets grippier with sweat — perfect for hot yoga and Mumbai summers.",
    [["Size", "183 x 61 cm"], ["Thickness", "6 mm"], ["Material", "Cork + TPE"], ["Weight", "1.1 kg"], ["Warranty", "6 months"]],
    { colors: ["Natural Cork", "Charcoal Cork"], flags: ["trending"] }),

  P("FlexiFit Adjustable Resistance Band Kit", "FlexiFit", "fitness", "fitness", 9, 749, 1699, 4.2, 7140, 26300,
    ["5 bands, 5-50 kg range", "Door anchor + handles", "Latex, snap resistant", "Travel pouch"],
    "A full gym in a pouch — rows, presses, pull-aparts and assisted pull-ups at home or on work trips.",
    [["Bands", "5 stackable"], ["Resistance", "5 to 50 kg"], ["Accessories", "Handles, anchor, ankle straps"], ["Material", "Natural latex"], ["Warranty", "6 months"]],
    { flags: ["flash"] }),

  /* ------------------------------- grocery ----------------------------- */
  P("Daily Harvest Cold Pressed Groundnut Oil 5 L", "Daily Harvest", "grocery", "daily", 0, 1249, 1699, 4.4, 4820, 22000,
    ["Wood pressed, unrefined", "Zero chemicals", "High smoke point", "Tin can, light safe"],
    "Filter-free wood-pressed groundnut oil with the aroma your grandmother's kitchen had. Great for everyday tadka and deep frying.",
    [["Volume", "5 L"], ["Type", "Wood pressed, unrefined"], ["Packaging", "Food-grade tin"], ["Shelf life", "9 months"], ["Origin", "Made in India"]],
    { flags: ["best"] }),

  P("Daily Harvest Roasted Almonds 1 kg", "Daily Harvest", "grocery", "daily", 4, 749, 1299, 4.3, 9140, 44000,
    ["California almonds, slow roasted", "Zero oil, zero salt", "Resealable zip pack", "Packed in India"],
    "Crunchy, fresh and never bitter. Slow-roasted in small batches so the natural oils do not turn rancid.",
    [["Weight", "1 kg"], ["Type", "Roasted & unsalted"], ["Packaging", "Resealable pouch"], ["Shelf life", "9 months"], ["Origin", "Packed in India"]],
    { sizes: ["250 g", "500 g", "1 kg"], flags: ["flash", "trending"] }),

  P("Daily Harvest Artisan Dark Chocolate Bar", "Daily Harvest", "grocery", "daily", 5, 299, 549, 4.5, 3120, 9800,
    ["70% cocoa, single origin", "No vegetable fat", "Vegan friendly", "Bean to bar in Kerala"],
    "A properly bitter-sweet 70% bar with red fruit notes. Three ingredients, nothing you cannot pronounce.",
    [["Weight", "90 g"], ["Cocoa", "70%"], ["Type", "Dark, vegan"], ["Shelf life", "9 months"], ["Origin", "Made in India"]],
    { flags: ["new"] }),

  P("Daily Harvest Instant Masala Chai Premix", "Daily Harvest", "grocery", "daily", 6, 349, 599, 4.1, 2210, 7600,
    ["20 cups per pack", "Real Assam CTC + spices", "No preservatives", "Ready in 2 minutes"],
    "Cardamom, ginger and a whisper of clove. Just add hot water and milk — no boiling, no straining.",
    [["Net weight", "400 g"], ["Servings", "20 cups"], ["Type", "Instant premix"], ["Shelf life", "9 months"], ["Origin", "Made in India"]],
    { flags: ["trending"] }),

  /* -------------------------------- toys ------------------------------- */
  P("Playloom Wooden Montessori Activity Cube", "Playloom", "toys", "daily", 1, 1499, 2999, 4.6, 1840, 5300,
    ["Neem wood, non-toxic paint", "5 activities in 1 cube", "Rounded, splinter-free edges", "Ages 18m - 4y"],
    "A screen-free attention builder — bead maze, shape sorter, gears, abacus and clock on five faces. Made from sustainably sourced neem wood.",
    [["Material", "Neem wood, water-based paint"], ["Age", "18 months - 4 years"], ["Dimensions", "24 x 24 x 24 cm"], ["Safety", "BIS certified EN71"], ["Origin", "Made in India"]],
    { flags: ["best", "new"] }),

  P("Playloom STEM Circuit Robot Kit", "Playloom", "toys", "tech", 5, 1899, 3499, 4.4, 1210, 3600,
    ["12 buildable experiments", "No soldering required", "Illustrated guidebook", "Ages 8+"],
    "Kids build working sensors, alarms and a line-following bot while absorbing real electronics fundamentals. All parts snap together safely.",
    [["Experiments", "12 projects"], ["Age", "8 years and above"], ["Power", "AA batteries (not included)"], ["Safety", "BIS certified"], ["Origin", "Made in India"]],
    { flags: ["trending"] }),

  P("Playloom Ultra-Soft Baby Blanket Set", "Playloom", "toys", "daily", 7, 999, 2199, 4.3, 2420, 8100,
    ["Micro-plush, OEKO-TEX fabric", "Pack of 2 (swaddle + receving)", "Skin friendly for newborns", "Machine washable"],
    "Feather-light blankets that keep newborns warm without overheating. Tested free of azo dyes and formaldehyde.",
    [["Material", "Micro plush polyester"], ["Size", "75 x 75 cm each"], ["Pack", "2 blankets"], ["Care", "Machine wash cold"], ["Origin", "Made in India"]],
    { colors: ["Sky", "Blush", "Mint"], flags: ["flash"] }),
];

export const SEED_COUPONS = [
  { code: "FASTO100", title: "₹100 off on first order", description: "New users get flat ₹100 off on orders above ₹999.", type: "flat", value: 100, minCart: 999, maxDiscount: 100 },
  { code: "MEGA20", title: "20% off up to ₹1500", description: "Get 20% instant discount on carts above ₹2999.", type: "percent", value: 20, minCart: 2999, maxDiscount: 1500 },
  { code: "FASHION500", title: "₹500 off fashion fest", description: "Flat ₹500 off on fashion & footwear above ₹1999.", type: "flat", value: 500, minCart: 1999, maxDiscount: 500 },
  { code: "BANK10", title: "Extra 10% on UPI", description: "10% off up to ₹600 when you pay with UPI.", type: "percent", value: 10, minCart: 1499, maxDiscount: 600 },
  { code: "FREESHIP", title: "Free delivery", description: "Waives the delivery fee on any cart value.", type: "flat", value: 0, minCart: 0, maxDiscount: 99 },
];

export const SEED_BANNERS = [
  { title: "The FASTO Mega Saver Days", subtitle: "Up to 70% off across phones, fashion & home. Ends Sunday midnight.", ctaText: "Shop the sale", ctaHref: "/products?sort=discount", gradient: "from-brand-600 via-brand-500 to-flame-500", placement: "hero", sortOrder: 1 },
  { title: "Flash deals every 3 hours", subtitle: "Limited stock, unbeatable prices — refresh and grab.", ctaText: "See flash sale", ctaHref: "/products?tag=flash", gradient: "from-flame-600 to-rose-500", placement: "strip", sortOrder: 2 },
  { title: "Home upgrade fest", subtitle: "Cookware, decor & appliances from ₹399", ctaText: "Explore home", ctaHref: "/category/home", gradient: "from-emerald-600 to-teal-500", placement: "tile", sortOrder: 3 },
  { title: "Beauty under ₹499", subtitle: "Serums, masks & lipsticks loved by 2 lakh shoppers", ctaText: "Shop beauty", ctaHref: "/category/beauty", gradient: "from-fuchsia-600 to-brand-600", placement: "tile", sortOrder: 4 },
];
