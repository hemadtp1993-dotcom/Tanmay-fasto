import { Suspense } from "react";
import AuthForm from "@/components/auth-form";

export const metadata = { title: "Forgot password" };
export const dynamic = "force-dynamic";

export default function ForgotPasswordPage() {
  return (
    <Suspense fallback={null}>
      <AuthForm mode="forgot" />
    </Suspense>
  );
}
