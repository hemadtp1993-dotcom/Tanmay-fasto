import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Terms & conditions",
  description: "The terms that govern your use of FASTO's marketplace, orders, payments and returns.",
};

const SECTIONS: Array<[string, string[]]> = [
  [
    "1. About these terms",
    [
      "These terms form a binding agreement between you and FASTO Retail Pvt. Ltd. (CIN U52100KA2024PTC188420), having its registered office at Prestige Tech Park, Bengaluru 560103, India.",
      "By creating an account, browsing or placing an order you accept these terms and our privacy policy.",
    ],
  ],
  [
    "2. Eligibility & account",
    [
      "You must be at least 18 years old, or use FASTO under the supervision of a parent or guardian.",
      "You are responsible for the accuracy of your details and for keeping your password confidential. Notify us immediately of any unauthorised access.",
      "We may suspend accounts used for fraud, abuse of returns, reselling misrepresented goods or repeated payment failures.",
    ],
  ],
  [
    "3. Products, pricing & availability",
    [
      "Product images are indicative; colours may vary slightly across screens. Specifications are provided by the brand or seller.",
      "An order is an offer to purchase. A contract is formed only when we confirm dispatch — at which point payment is captured.",
      "Prices, discounts and availability may change without notice. Obvious pricing errors may be cancelled with a full refund.",
      "MRP is displayed as required under the Legal Metrology (Packaged Commodities) Rules, 2011.",
    ],
  ],
  [
    "4. Payments",
    [
      "We accept UPI, cards, net banking, FASTO wallet, EMI and cash on delivery where available.",
      "For prepaid orders the amount is captured when the order is confirmed. Failed transactions are auto-reversed by your bank within 5–7 working days.",
      "Cash on delivery is limited to orders below ₹50,000 and may be unavailable for select pin codes or high-risk accounts.",
    ],
  ],
  [
    "5. Delivery & risk",
    [
      "Estimated delivery dates are good-faith estimates and may be affected by weather, strikes or natural events.",
      "Title and risk in the products pass to you on delivery to the address you provided.",
      "Please inspect the parcel at delivery and refuse it if the packaging is visibly damaged or tampered with.",
    ],
  ],
  [
    "6. Returns, replacements & refunds",
    [
      "Return windows are shown on each product page and are typically 7 days from delivery.",
      "Products must be returned with all original accessories, free gifts, tags and packaging for the refund to be processed.",
      "Refunds are issued to the original payment method within 3–5 working days of the quality check, or to your bank/wallet for COD orders.",
      "Certain categories — innerwear, cosmetics, groceries, perishables and customised items — are non-returnable unless damaged, defective or incorrect.",
    ],
  ],
  [
    "7. Acceptable use",
    [
      "Do not scrape, reverse engineer, overload or attempt to gain unauthorised access to the platform.",
      "Reviews must be your own honest opinion and must not contain unlawful, defamatory or promotional content.",
      "Coupons are non-transferable, cannot be exchanged for cash and may carry minimum cart values or category restrictions.",
    ],
  ],
  [
    "8. Intellectual property",
    [
      "The FASTO name, logo, wordmark, interface design and original content are our intellectual property and may not be copied without written permission.",
      "Brand names and product images belong to their respective owners and are used for identification only.",
    ],
  ],
  [
    "9. Liability & governing law",
    [
      "Our aggregate liability for any claim is limited to the value of the order giving rise to that claim.",
      "We are not liable for indirect or consequential losses, including loss of profit or data.",
      "These terms are governed by Indian law. Courts at Bengaluru, Karnataka have exclusive jurisdiction.",
    ],
  ],
];

export default function TermsPage() {
  return (
    <div className="space-y-5">
      <div className="panel rounded-3xl p-6 sm:p-8">
        <p className="text-xs font-black uppercase tracking-[0.2em] text-brand-600 dark:text-brand-300">Legal</p>
        <h1 className="mt-2 text-2xl font-black tracking-tight text-ink-900 dark:text-white sm:text-3xl">Terms &amp; conditions</h1>
        <p className="mt-2 text-sm text-ink-400">Effective 12 January 2026 · FASTO Retail Pvt. Ltd., Bengaluru, India</p>
      </div>

      {SECTIONS.map(([title, items]) => (
        <section key={title} className="panel rounded-3xl p-5 sm:p-6">
          <h2 className="text-base font-black tracking-tight text-ink-900 dark:text-white">{title}</h2>
          <ul className="mt-3 space-y-2">
            {items.map((item) => (
              <li key={item} className="flex gap-2.5 text-sm leading-relaxed text-ink-500 dark:text-ink-300">
                <span aria-hidden className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" />
                {item}
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}
