import Link from "next/link";
import CheckoutFlow from "@/components/checkout-flow";
import { getCart } from "@/lib/shop";
import { EmptyState, CtaLink } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Secure checkout" };

export default async function CheckoutPage() {
  const lines = await getCart(false);
  if (!lines.filter((l) => !l.savedForLater).length) {
    return (
      <EmptyState
        icon="🧾"
        title="Nothing to check out"
        body="Your cart is empty. Add a few products and come back to complete your purchase."
        action={<CtaLink href="/products">Browse products</CtaLink>}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-black tracking-tight text-ink-900 dark:text-white">Secure checkout</h1>
        <Link href="/cart" className="text-xs font-bold text-brand-600 dark:text-brand-300">
          ← Back to cart
        </Link>
      </div>
      <CheckoutFlow />
    </div>
  );
}
