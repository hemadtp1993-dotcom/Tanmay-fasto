import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Contact FASTO customer care",
  description: "Reach FASTO support by chat, phone, email or post. We reply in under 2 minutes on chat.",
};

export default function ContactPage() {
  return (
    <div className="space-y-6">
      <div className="panel rounded-3xl p-6 sm:p-8">
        <p className="text-xs font-black uppercase tracking-[0.2em] text-brand-600 dark:text-brand-300">We&apos;re here to help</p>
        <h1 className="mt-2 text-2xl font-black tracking-tight text-ink-900 dark:text-white sm:text-3xl">Contact FASTO</h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-400">
          Real humans, seven days a week. Average first response time is under two minutes on chat and under four hours on email.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["💬", "Live chat", "8 AM – midnight, all days", "Tap the 💬 bubble bottom-right"],
          ["📞", "Phone support", "1800-202-FASTO (toll free)", "9 AM – 9 PM, Mon–Sat"],
          ["✉️", "Email", "care@fasto.in", "Replies within 4 hours"],
          ["🏢", "Head office", "4th Floor, Prestige Tech Park, Kadubeesanahalli, Bengaluru 560103", "Mon–Fri, 10 AM – 6 PM"],
        ].map(([icon, title, primary, secondary]) => (
          <div key={title} className="panel lift rounded-3xl p-5">
            <span aria-hidden className="text-2xl">{icon}</span>
            <h2 className="mt-2 text-sm font-black text-ink-900 dark:text-white">{title}</h2>
            <p className="mt-1 text-sm font-semibold text-brand-600 dark:text-brand-300">{primary}</p>
            <p className="mt-0.5 text-xs text-ink-400">{secondary}</p>
          </div>
        ))}
      </div>

      <section className="panel rounded-3xl p-6 sm:p-8">
        <h2 className="text-lg font-black tracking-tight text-ink-900 dark:text-white">Raise a written request</h2>
        <p className="mt-1 text-sm text-ink-400">
          Signed in? Raise a trackable ticket from{" "}
          <Link href="/account?tab=support" className="font-bold text-brand-600 dark:text-brand-300">
            Account → Help &amp; support
          </Link>{" "}
          so we can see your order history instantly. Prefer email? Write to{" "}
          <a href="mailto:care@fasto.in" className="font-bold text-brand-600 dark:text-brand-300">
            care@fasto.in
          </a>
          .
        </p>
        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          {[
            ["Orders & delivery", "Track, reschedule, or change the delivery address of a live order."],
            ["Returns & refunds", "Raise a return, replacement or refund escalation with full visibility."],
            ["Partnerships & sellers", "Onboard as a seller or discuss brand tie-ups at partners@fasto.in."],
          ].map(([title, body]) => (
            <div key={title} className="rounded-2xl bg-ink-400/6 p-4">
              <p className="text-sm font-bold text-ink-900 dark:text-white">{title}</p>
              <p className="mt-1 text-xs leading-relaxed text-ink-400">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="panel rounded-3xl p-6 sm:p-8">
        <h2 className="text-lg font-black tracking-tight text-ink-900 dark:text-white">Grievance officer</h2>
        <p className="mt-2 text-sm leading-relaxed text-ink-500 dark:text-ink-300">
          In accordance with the Consumer Protection (E-Commerce) Rules, 2020, our grievance officer is{" "}
          <strong className="text-ink-900 dark:text-white">Ms. Divya Raghavan</strong>. Write to grievance@fasto.in or call
          1800-202-FASTO. Complaints are acknowledged within 48 hours and resolved within one month.
        </p>
      </section>
    </div>
  );
}
