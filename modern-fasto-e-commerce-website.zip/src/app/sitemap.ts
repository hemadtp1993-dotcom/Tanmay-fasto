import type { MetadataRoute } from "next";
import { getCategories } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = "https://fasto.in";
  const staticRoutes = ["", "/products", "/categories", "/cart", "/wishlist", "/compare", "/about", "/contact", "/faq", "/privacy", "/terms", "/login", "/signup"];

  let categoryRoutes: string[] = [];
  try {
    const categories = await getCategories();
    categoryRoutes = categories.map((c) => `/category/${c.slug}`);
  } catch {
    categoryRoutes = [];
  }

  return [...staticRoutes, ...categoryRoutes].map((route) => ({
    url: `${base}${route}`,
    lastModified: new Date(),
    changeFrequency: route === "" || route === "/products" ? "daily" : "weekly",
    priority: route === "" ? 1 : 0.7,
  }));
}
