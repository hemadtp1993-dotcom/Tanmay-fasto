import Link from "next/link";
import { Suspense } from "react";
import { desc, eq, sql } from "drizzle-orm";
import AdminConsole from "@/components/admin-console";
import { db } from "@/db";
import {
  banners as bannersTable,
  categories as categoriesTable,
  coupons as couponsTable,
  orderItems,
  orders as ordersTable,
  products as productsTable,
  returnRequests,
  users as usersTable,
} from "@/db/schema";
import { currentUser } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin dashboard", robots: { index: false, follow: false } };

export default async function AdminPage() {
  await ensureSeeded();
  const user = await currentUser();

  if (!user || user.role !== "admin") {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-4 text-center">
        <span className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-500/10 text-3xl">🔐</span>
        <h1 className="mt-4 text-2xl font-black tracking-tight text-ink-900 dark:text-white">Admin access required</h1>
        <p className="mt-2 text-sm text-ink-400">
          This control centre is restricted to FASTO operations staff. Sign in with an admin account to continue.
        </p>
        <div className="mt-6 w-full rounded-2xl bg-ink-400/8 p-4 text-left text-xs text-ink-500 dark:text-ink-300">
          <p className="font-bold uppercase tracking-wide text-ink-400">Demo admin credentials</p>
          <p className="mt-1">admin@fasto.in / Admin@123</p>
        </div>
        <Link href="/login?next=%2Fadmin" className="mt-5 w-full rounded-xl bg-brand-600 py-3 text-sm font-bold text-white">
          Sign in as admin
        </Link>
      </div>
    );
  }

  const [products, orderRows, itemRows, users, coupons, banners, categories, returns] = await Promise.all([
    db.select().from(productsTable).orderBy(desc(productsTable.createdAt)),
    db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(80),
    db.select().from(orderItems),
    db.select().from(usersTable).orderBy(desc(usersTable.createdAt)),
    db.select().from(couponsTable).orderBy(desc(couponsTable.minCart)),
    db.select().from(bannersTable).orderBy(bannersTable.sortOrder),
    db.select().from(categoriesTable).orderBy(categoriesTable.sortOrder),
    db.select().from(returnRequests).orderBy(desc(returnRequests.createdAt)).limit(40),
  ]);

  const orders = orderRows.map((o) => ({ ...o, items: itemRows.filter((i) => i.orderId === o.id) }));
  const valid = orders.filter((o) => o.status !== "cancelled");
  const revenue = valid.reduce((s, o) => s + o.total, 0);
  const pending = orders.filter((o) => ["confirmed", "packed"].includes(o.status)).length;

  const revenueByDay = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const key = date.toDateString();
    const dayOrders = valid.filter((o) => new Date(o.createdAt).toDateString() === key);
    return {
      day: date.toLocaleDateString("en-IN", { weekday: "short" }),
      revenue: dayOrders.reduce((s, o) => s + o.total, 0),
      orders: dayOrders.length,
    };
  });

  const soldMap = new Map<string, { title: string; sold: number; revenue: number }>();
  for (const item of itemRows) {
    const entry = soldMap.get(item.slug) ?? { title: item.title, sold: 0, revenue: 0 };
    entry.sold += item.quantity;
    entry.revenue += item.quantity * item.price;
    soldMap.set(item.slug, entry);
  }
  const topProducts = [...soldMap.values()].sort((a, b) => b.sold - a.sold).slice(0, 6);

  const [productAgg] = await db
    .select({
      count: sql<number>`count(*)::int`,
      lowStock: sql<number>`count(*) filter (where ${productsTable.stock} < 10)::int`,
    })
    .from(productsTable);

  const adminUsers = users.map((u) => {
    const userOrders = valid.filter((o) => o.userId === u.id);
    return {
      id: u.id,
      name: u.name,
      email: u.email,
      phone: u.phone,
      role: u.role,
      createdAt: u.createdAt,
      orders: userOrders.length,
      spent: userOrders.reduce((s, o) => s + o.total, 0),
    };
  });

  void eq;

  return (
    <Suspense fallback={<div className="shimmer m-6 h-96 rounded-3xl" />}>
      <AdminConsole
        stats={{
          revenue,
          orders: orders.length,
          aov: valid.length ? Math.round(revenue / valid.length) : 0,
          customers: users.filter((u) => u.role !== "admin").length,
          pending,
          products: productAgg?.count ?? products.length,
          lowStock: productAgg?.lowStock ?? 0,
        }}
        products={products}
        orders={orders}
        users={adminUsers}
        coupons={coupons}
        banners={banners}
        categories={categories}
        returns={returns}
        revenueByDay={revenueByDay}
        topProducts={topProducts}
      />
    </Suspense>
  );
}
