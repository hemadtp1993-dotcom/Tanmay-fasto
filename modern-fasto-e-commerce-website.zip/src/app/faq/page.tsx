import type { Metadata } from "next";
import Link from "next/link";
import { CtaLink, SectionHeader } from "@/components/ui";

export const metadata: Metadata = {
  title: "FAQ — frequently asked questions",
  description: "Answers about FASTO orders, delivery, payments, returns, refunds, referrals and seller onboarding.",
};

const GROUPS: Array<{ id: string; title: string; items: Array<[string, string]> }> = [
  {
    id: "orders",
    title: "Orders & tracking",
    items: [
      ["How do I track my order?", "Go to Account → My Orders → Track order. You'll see a live timeline from packing to doorstep, plus the courier partner's details once shipped."],
      ["Can I change my delivery address after ordering?", "Yes, until the order is packed. Open the order and tap 'Need help' — our team updates it within minutes."],
      ["What if I miss the delivery?", "Our partner attempts delivery up to three times. You can also reschedule from the tracking page or choose a FASTO pickup point."],
      ["Do you deliver outside India?", "Currently we ship only within India, covering 19,400+ pin codes including most North-East and island regions."],
    ],
  },
  {
    id: "shipping",
    title: "Shipping & delivery",
    items: [
      ["What are the delivery charges?", "Delivery is free on eligible orders above ₹499. Below that a flat ₹49 handling fee applies. FASTO Plus members always get free delivery."],
      ["How fast is FASTO delivery?", "Same-day in 14 metros for orders placed before 6 PM, next-day in 96 cities, and 2–4 days across the rest of India."],
      ["Are all products genuine?", "Every listing is sourced from the brand or an authorised distributor. Look for the FASTO Assured badge — it carries a 100% authenticity guarantee."],
    ],
  },
  {
    id: "returns",
    title: "Returns, refunds & cancellations",
    items: [
      ["What is the return window?", "Most categories carry a 7-day return window from delivery. Innerwear, cosmetics, groceries and perishables are non-returnable for hygiene reasons unless damaged."],
      ["How do I raise a return?", "Account → Returns & refunds → Raise a request. Choose return or replacement, pick a reason and we schedule a free doorstep pickup within 48 hours."],
      ["When will I get my refund?", "Prepaid orders are refunded to the original payment method in 3–5 working days after the quality check. COD orders are refunded to your bank or FASTO wallet."],
      ["Can I cancel an order?", "Yes, free cancellation while the order is confirmed or packed. Once shipped, please raise a return instead."],
    ],
  },
  {
    id: "payments",
    title: "Payments & security",
    items: [
      ["Which payment methods do you accept?", "UPI (GPay, PhonePe, Paytm, BHIM), credit and debit cards, net banking from 58 banks, FASTO wallet, no-cost EMI on orders above ₹3,000, and cash on delivery."],
      ["Is it safe to save my card?", "Card details are tokenised by our PCI-DSS Level 1 certified payment gateway. FASTO never stores raw card numbers."],
      ["My payment failed but money was deducted.", "Banks usually auto-reverse within 5–7 working days. If it hasn't, raise a ticket from Account → Help & support and we'll escalate with the reference number."],
    ],
  },
  {
    id: "referral",
    title: "Referrals, coupons & FASTO coins",
    items: [
      ["How does the referral programme work?", "Share your code from Account → Coupons & rewards. Your friend gets ₹200 off their first order above ₹999 and you get ₹200 in your wallet once it is delivered."],
      ["How many coupons can I use per order?", "One coupon per order. Coupon discounts stack on top of product-level offers unless the product page states otherwise."],
      ["What are FASTO coins?", "You earn 1 coin for every ₹100 spent. 4 coins = ₹1 and they can cover up to half your order value at checkout."],
    ],
  },
];

export default function FaqPage() {
  return (
    <div className="space-y-6">
      <SectionHeader title="Frequently asked questions" subtitle="Everything about ordering, delivery, payments and returns on FASTO" />

      <nav className="panel flex flex-wrap gap-2 rounded-2xl p-3">
        {GROUPS.map((g) => (
          <a key={g.id} href={`#${g.id}`} className="rounded-full bg-ink-400/10 px-3.5 py-1.5 text-xs font-bold text-ink-600 transition hover:bg-brand-500 hover:text-white dark:text-ink-200">
            {g.title}
          </a>
        ))}
      </nav>

      {GROUPS.map((group) => (
        <section key={group.id} id={group.id} className="panel scroll-mt-40 rounded-3xl p-5 sm:p-6">
          <h2 className="text-lg font-black tracking-tight text-ink-900 dark:text-white">{group.title}</h2>
          <div className="mt-4 divide-y hairline">
            {group.items.map(([q, a]) => (
              <details key={q} className="group py-3.5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-bold text-ink-900 dark:text-white">
                  {q}
                  <span aria-hidden className="shrink-0 text-brand-600 transition group-open:rotate-45 dark:text-brand-300">
                    ＋
                  </span>
                </summary>
                <p className="mt-2 text-sm leading-relaxed text-ink-500 dark:text-ink-300">{a}</p>
              </details>
            ))}
          </div>
        </section>
      ))}

      <div className="panel flex flex-wrap items-center justify-between gap-4 rounded-3xl p-6">
        <div>
          <p className="text-base font-black text-ink-900 dark:text-white">Still need help?</p>
          <p className="text-sm text-ink-400">Our care team replies in under 2 minutes on chat, 8 AM to midnight.</p>
        </div>
        <div className="flex gap-3">
          <CtaLink href="/contact">Contact us</CtaLink>
          <CtaLink href="/account?tab=support" variant="outline">
            Raise a ticket
          </CtaLink>
        </div>
      </div>
    </div>
  );
}
