import Link from "next/link";
import ProductCard from "@/components/product-card";
import { CategoryStrip, Countdown, HeroCarousel, StatStrip } from "@/components/home-blocks";
import { CtaLink, SectionHeader } from "@/components/ui";
import {
  getBanners,
  getBestsellers,
  getCategories,
  getFlashDeals,
  getNewArrivals,
  getRecommended,
  getTopDeals,
  getTrending,
} from "@/lib/catalog";
import { getRecentlyViewed, listCoupons } from "@/lib/shop";
import { rupees } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [heroBanners, tileBanners, categories, flash, deals, trending, best, fresh, recommended, recent, coupons] =
    await Promise.all([
      getBanners("hero"),
      getBanners("tile"),
      getCategories(),
      getFlashDeals(10),
      getTopDeals(10),
      getTrending(10),
      getBestsellers(10),
      getNewArrivals(10),
      getRecommended(10),
      getRecentlyViewed(10),
      listCoupons(),
    ]);

  const flashEnds = flash[0]?.flashEndsAt ?? new Date(Date.now() + 3 * 3600 * 1000);

  return (
    <div className="space-y-10">
      {/* hero + promo tiles */}
      <section className="grid gap-4 lg:grid-cols-[2.2fr_1fr]">
        <HeroCarousel slides={heroBanners} />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
          {tileBanners.map((b, i) => (
            <Link
              key={b.id}
              href={b.ctaHref}
              className={`lift relative flex min-h-[132px] flex-col justify-center gap-1 overflow-hidden rounded-3xl bg-gradient-to-br ${b.gradient} p-5 text-white lg:min-h-[172px]`}
              style={{ animation: "fasto-rise .5s ease both", animationDelay: `${i * 0.06}s` }}
            >
              <span className="absolute -right-6 -top-8 h-28 w-28 rounded-full bg-white/15 blur-xl" />
              <p className="text-lg font-black leading-tight">{b.title}</p>
              <p className="text-xs text-white/90">{b.subtitle}</p>
              <span className="mt-1 text-xs font-bold underline underline-offset-4">{b.ctaText} →</span>
            </Link>
          ))}
        </div>
      </section>

      {/* categories */}
      <section>
        <SectionHeader title="Shop by category" subtitle="Handpicked catalogues refreshed every week" href="/categories" />
        <CategoryStrip items={categories} />
      </section>

      {/* flash sale */}
      {flash.length > 0 && (
        <section className="overflow-hidden rounded-3xl bg-gradient-to-r from-flame-600 via-flame-500 to-amber-400 p-4 sm:p-6">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="flex items-center gap-2 text-xl font-black text-white sm:text-2xl">
                ⚡ Flash Sale
              </h2>
              <p className="text-xs font-medium text-white/90">Prices this low vanish when the clock hits zero</p>
            </div>
            <div className="flex items-center gap-2 rounded-2xl bg-white/95 px-3 py-2 shadow">
              <span className="text-[11px] font-black uppercase tracking-wide text-ink-600">Ends in</span>
              <Countdown endsAt={new Date(flashEnds).toISOString()} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {flash.slice(0, 5).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
          <Link href="/products?tag=flash" className="mt-4 inline-block rounded-xl bg-ink-950/85 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-ink-950">
            View all flash deals →
          </Link>
        </section>
      )}

      <StatStrip />

      {/* today's deals */}
      <section>
        <SectionHeader title="Today's Deals" subtitle="Biggest price drops of the day" href="/products?sort=discount" />
        <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
          {deals.map((p) => (
            <div key={p.id} className="w-[172px] shrink-0 sm:w-[196px]">
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      </section>

      {/* trending */}
      <section>
        <SectionHeader title="Trending now" subtitle="What India is buying this week" href="/products?tag=trending" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {trending.slice(0, 10).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* coupon strip */}
      <section className="panel grid gap-3 rounded-3xl p-5 sm:grid-cols-2 lg:grid-cols-4">
        {coupons.slice(0, 4).map((c) => (
          <div key={c.id} className="rounded-2xl border border-dashed border-brand-500/40 bg-brand-500/5 p-4">
            <p className="font-mono text-sm font-black tracking-wider text-brand-600 dark:text-brand-300">{c.code}</p>
            <p className="mt-1 text-sm font-bold text-ink-900 dark:text-white">{c.title}</p>
            <p className="mt-0.5 text-[11px] leading-snug text-ink-400">{c.description}</p>
            <p className="mt-2 text-[11px] font-semibold text-ink-400">
              {c.minCart > 0 ? `Min cart ${rupees(c.minCart)}` : "No minimum spend"}
            </p>
          </div>
        ))}
      </section>

      {/* best sellers */}
      <section>
        <SectionHeader title="Best sellers" subtitle="Proven favourites with thousands of 5-star reviews" href="/products?tag=best" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {best.slice(0, 10).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* new arrivals */}
      <section>
        <SectionHeader title="New arrivals" subtitle="Fresh drops from your favourite brands" href="/products?tag=new" />
        <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
          {fresh.map((p) => (
            <div key={p.id} className="w-[172px] shrink-0 sm:w-[196px]">
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      </section>

      {/* recommended */}
      <section>
        <SectionHeader title="Recommended for you" subtitle="Based on what shoppers like you are loving" href="/products" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {recommended.slice(0, 10).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* recently viewed */}
      {recent.length > 0 && (
        <section>
          <SectionHeader title="Recently viewed" subtitle="Pick up where you left off" href="/account?tab=recent" />
          <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
            {recent.map((p) => (
              <div key={p.id} className="w-[172px] shrink-0 sm:w-[196px]">
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* usp */}
      <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["🚀", "Same-day delivery", "In 14 metros, 2-day everywhere else"],
          ["🛡️", "FASTO Assured", "100% genuine, brand-authorised stock"],
          ["💳", "Pay your way", "UPI, cards, EMI, wallet & COD"],
          ["↩️", "No-question returns", "7-day window with doorstep pickup"],
        ].map(([icon, title, body]) => (
          <div key={title} className="panel lift rounded-2xl p-5">
            <span aria-hidden className="text-2xl">{icon}</span>
            <p className="mt-2 text-sm font-bold text-ink-900 dark:text-white">{title}</p>
            <p className="mt-0.5 text-xs text-ink-400">{body}</p>
          </div>
        ))}
      </section>

      {/* cta */}
      <section className="relative overflow-hidden rounded-3xl bg-ink-950 px-6 py-12 text-center text-white sm:px-12">
        <div className="absolute -left-16 -top-16 h-56 w-56 rounded-full bg-brand-600/40 blur-3xl" />
        <div className="absolute -bottom-20 -right-10 h-56 w-56 rounded-full bg-flame-500/30 blur-3xl" />
        <div className="relative">
          <h2 className="text-2xl font-black tracking-tight sm:text-3xl">Get ₹200 for every friend you invite</h2>
          <p className="mx-auto mt-2 max-w-lg text-sm text-white/70">
            Share your referral code, your friend gets ₹200 off their first order and your wallet gets ₹200 when they shop.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <CtaLink href="/account?tab=referral" variant="solid" className="!bg-white !text-ink-900 !shadow-none">
              Get my referral code
            </CtaLink>
            <CtaLink href="/products" variant="outline" className="!border-white/40 !bg-white/10 !text-white">
              Start shopping
            </CtaLink>
          </div>
        </div>
      </section>
    </div>
  );
}
