import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy policy",
  description: "How FASTO collects, uses, stores and protects your personal data.",
};

const SECTIONS: Array<[string, string[]]> = [
  [
    "1. Information we collect",
    [
      "Account data: your name, email address, mobile number and (if you add one) delivery addresses.",
      "Order data: products purchased, payment method used (never full card numbers), invoices and returns history.",
      "Usage data: pages viewed, searches performed, products added to cart or wishlist, and device/browser metadata.",
      "Communication data: support tickets, chat transcripts and any reviews you publish.",
    ],
  ],
  [
    "2. How we use your data",
    [
      "To process orders, arrange delivery, process refunds and provide customer support.",
      "To personalise your experience — recently viewed products, recommendations and relevant offers.",
      "To detect and prevent fraud, abuse and account takeovers.",
      "To send transactional notifications and, with your consent, marketing messages you can switch off at any time.",
    ],
  ],
  [
    "3. Payments",
    [
      "All payments are processed by PCI-DSS Level 1 certified payment aggregators. FASTO stores only a masked reference (for example Visa •••• 4291) and a payment identifier.",
      "UPI collect requests are initiated through the gateway; we never see or store your UPI PIN.",
    ],
  ],
  [
    "4. Cookies & local storage",
    [
      "We use a first-party session cookie to keep you signed in and a visitor identifier to keep your cart and wishlist working before you sign in.",
      "Theme preference and recent searches are stored locally on your device. You can clear them from your browser at any time.",
    ],
  ],
  [
    "5. Sharing with third parties",
    [
      "Logistics partners receive the minimum data required to deliver your parcel: name, address, phone and order contents.",
      "Payment gateways, SMS and email providers act under contract and cannot use your data for their own purposes.",
      "We never sell your personal data. We may disclose it if legally required by Indian law or a valid government order.",
    ],
  ],
  [
    "6. Data retention & security",
    [
      "Order and invoice records are retained for eight years as required by Indian tax law. Marketing preferences are retained until you withdraw consent.",
      "Data is encrypted in transit (TLS 1.3) and at rest. Access inside FASTO is role-based and logged.",
    ],
  ],
  [
    "7. Your rights",
    [
      "You can access, correct or delete your profile from Account → Profile. Deleting your account also removes your saved addresses and payment references.",
      "To exercise any other right, write to privacy@fasto.in and we will respond within 30 days.",
    ],
  ],
  [
    "8. Contact",
    [
      "Data Protection Officer, FASTO Retail Pvt. Ltd., 4th Floor, Prestige Tech Park, Kadubeesanahalli, Bengaluru 560103.",
      "Email: privacy@fasto.in · Grievance officer: grievance@fasto.in",
    ],
  ],
];

export default function PrivacyPage() {
  return (
    <div className="space-y-5">
      <div className="panel rounded-3xl p-6 sm:p-8">
        <p className="text-xs font-black uppercase tracking-[0.2em] text-brand-600 dark:text-brand-300">Legal</p>
        <h1 className="mt-2 text-2xl font-black tracking-tight text-ink-900 dark:text-white sm:text-3xl">Privacy policy</h1>
        <p className="mt-2 text-sm text-ink-400">Last updated 12 January 2026 · Applies to fasto.in and the FASTO mobile apps.</p>
      </div>

      {SECTIONS.map(([title, items]) => (
        <section key={title} className="panel rounded-3xl p-5 sm:p-6">
          <h2 className="text-base font-black tracking-tight text-ink-900 dark:text-white">{title}</h2>
          <ul className="mt-3 space-y-2">
            {items.map((item) => (
              <li key={item} className="flex gap-2.5 text-sm leading-relaxed text-ink-500 dark:text-ink-300">
                <span aria-hidden className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-500" />
                {item}
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}
