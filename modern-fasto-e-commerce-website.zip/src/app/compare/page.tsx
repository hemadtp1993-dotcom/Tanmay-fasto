import CompareBoard from "@/components/compare-board";
import { SectionHeader } from "@/components/ui";

export const metadata = { title: "Compare products" };

export default function ComparePage() {
  return (
    <div className="space-y-5">
      <SectionHeader title="Product comparison" subtitle="Line up price, specs, ratings and availability side by side" />
      <CompareBoard />
    </div>
  );
}
