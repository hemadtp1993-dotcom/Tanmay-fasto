import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Shell from "@/components/shell";
import Splash from "@/components/splash";
import { ShopProvider } from "@/components/store";
import { themeScript } from "@/components/theme-toggle";
import type { Category } from "@/db/schema";
import { getCategories, getPopularSearches } from "@/lib/catalog";

import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "FASTO — Shop faster. Live better. | India's fastest online marketplace",
    template: "%s | FASTO",
  },
  description:
    "FASTO is India's fast, friendly online marketplace — mobiles, electronics, fashion, home, beauty and groceries with free delivery above ₹499, 7-day returns and secure payments.",
  keywords: ["FASTO", "online shopping India", "mobiles", "electronics", "fashion", "grocery", "deals"],
  openGraph: {
    title: "FASTO — Shop faster. Live better.",
    description: "Up to 70% off across mobiles, fashion, home and daily essentials.",
    type: "website",
    siteName: "FASTO",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f6f7fb" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0d19" },
  ],
  width: "device-width",
  initialScale: 1,
};

async function shellData(): Promise<{ categories: Category[]; popular: string[] }> {
  try {
    const [categories, searches] = await Promise.all([getCategories(), getPopularSearches(8)]);
    return { categories, popular: searches.map((s) => s.term) };
  } catch {
    return { categories: [], popular: [] };
  }
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  const { categories, popular } = await shellData();

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="font-sans text-ink-800 antialiased dark:text-ink-100">
        <ShopProvider>
          <Splash />
          <Shell categories={categories} popular={popular}>
            {children}
          </Shell>
        </ShopProvider>
      </body>
    </html>
  );
}
