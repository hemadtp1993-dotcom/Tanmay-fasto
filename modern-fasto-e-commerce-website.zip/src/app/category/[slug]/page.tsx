import type { Metadata } from "next";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { categories } from "@/db/schema";
import Listing from "@/components/listing";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

async function getCategory(slug: string) {
  await ensureSeeded();
  const rows = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategory(slug);
  if (!category) return { title: "Category not found" };
  return { title: category.name, description: `Shop ${category.name} on FASTO — ${category.tagline ?? "best prices online"}` };
}

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const category = await getCategory(slug);
  if (!category) notFound();

  return (
    <Listing
      params={{ ...sp, category: slug }}
      heading={`${category.icon} ${category.name}`}
      subtitle={category.tagline ?? "Curated for FASTO shoppers"}
      basePath={`category/${slug}`}
    />
  );
}
