import { NextResponse } from "next/server";
import { and, eq, isNull, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, wishlistItems } from "@/db/schema";
import { currentUser, toSafeUser, visitorId } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await currentUser();
    const vid = await visitorId();
    const owner = user ? or(eq(cartItems.userId, user.id), eq(cartItems.visitorId, vid)) : eq(cartItems.visitorId, vid);

    const [cartRow] = await db
      .select({ count: sql<number>`coalesce(sum(${cartItems.quantity}),0)::int` })
      .from(cartItems)
      .where(and(owner, eq(cartItems.savedForLater, false)));

    const wishOwner = user ? or(eq(wishlistItems.userId, user.id), eq(wishlistItems.visitorId, vid)) : eq(wishlistItems.visitorId, vid);
    const [wishRow] = await db.select({ count: sql<number>`count(*)::int` }).from(wishlistItems).where(wishOwner);

    return NextResponse.json({
      cartCount: cartRow?.count ?? 0,
      wishlistCount: wishRow?.count ?? 0,
      user: user ? toSafeUser(user) : null,
    });
  } catch (error) {
    console.error("[fasto] summary", error);
    return NextResponse.json({ cartCount: 0, wishlistCount: 0, user: null });
  }
}

export async function POST() {
  const rows = await db.select().from(cartItems).where(isNull(cartItems.userId)).limit(1);
  return NextResponse.json({ ok: true, rows: rows.length });
}
