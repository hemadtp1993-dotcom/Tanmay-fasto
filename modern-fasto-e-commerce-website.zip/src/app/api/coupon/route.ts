import { NextResponse } from "next/server";
import { computeTotals, evaluateCoupon, getCart } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json()) as { code: string };
  const lines = await getCart();
  const active = lines.filter((l) => !l.savedForLater);
  const itemsTotal = active.reduce((sum, l) => sum + l.product.price * l.quantity, 0);
  const result = await evaluateCoupon(body.code ?? "", itemsTotal);
  const totals = computeTotals(lines, { discount: result.discount, freeShipping: result.freeShipping });
  return NextResponse.json({ ok: result.ok, coupon: result, totals });
}
