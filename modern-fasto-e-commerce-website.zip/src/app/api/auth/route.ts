import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, notifications, passwordResets, users, wishlistItems } from "@/db/schema";
import {
  createSession,
  currentUser,
  destroySession,
  hashPassword,
  normalizeEmail,
  referralCode,
  validEmail,
  validPassword,
  validPhone,
  verifyPassword,
  visitorId,
} from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

type Body = {
  action: "login" | "signup" | "google" | "logout" | "forgot" | "reset";
  email?: string;
  password?: string;
  phone?: string;
  name?: string;
  token?: string;
  referredBy?: string;
};

async function adoptVisitor(userId: number) {
  const vid = await visitorId();
  if (vid === "anon") return;
  await db.update(cartItems).set({ userId }).where(and(eq(cartItems.visitorId, vid), isNull(cartItems.userId)));
  await db.update(wishlistItems).set({ userId }).where(and(eq(wishlistItems.visitorId, vid), isNull(cartItems.userId)));
}

async function welcomeNotifications(userId: number, name: string, referral: string) {
  await db.insert(notifications).values([
    {
      userId,
      title: `Welcome to FASTO, ${name.split(" ")[0]}! 🎉`,
      body: "Your ₹100 welcome coupon FASTO100 is auto-applied on your first order above ₹999.",
      kind: "offer",
      href: "/products",
    },
    {
      userId,
      title: "Your referral code is ready",
      body: `Share ${referral} — you both get ₹200 when your friend places their first order.`,
      kind: "reward",
      href: "/account?tab=referral",
    },
  ]);
}

export async function POST(request: Request) {
  await ensureSeeded();
  let body: Body;
  try {
    body = (await request.json()) as Body;
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }

  if (body.action === "logout") {
    await destroySession();
    return NextResponse.json({ ok: true });
  }

  const email = normalizeEmail(body.email ?? "");

  if (body.action === "login") {
    if (!validEmail(email) || !body.password) return NextResponse.json({ ok: false, error: "Enter a valid email and password." }, { status: 400 });
    const rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const user = rows[0];
    if (!user || !verifyPassword(body.password, user.passwordHash))
      return NextResponse.json({ ok: false, error: "Incorrect email or password." }, { status: 401 });
    await createSession(user.id);
    await adoptVisitor(user.id);
    return NextResponse.json({ ok: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  }

  if (body.action === "signup") {
    const name = (body.name ?? "").trim();
    if (name.length < 3) return NextResponse.json({ ok: false, error: "Please enter your full name." }, { status: 400 });
    if (!validEmail(email)) return NextResponse.json({ ok: false, error: "Enter a valid email address." }, { status: 400 });
    if (body.phone && !validPhone(body.phone))
      return NextResponse.json({ ok: false, error: "Enter a valid 10-digit Indian mobile number." }, { status: 400 });
    if (!validPassword(body.password ?? ""))
      return NextResponse.json({ ok: false, error: "Password needs 8+ characters with a letter and a number." }, { status: 400 });

    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing[0]) return NextResponse.json({ ok: false, error: "An account with this email already exists." }, { status: 409 });

    const referral = referralCode(name);
    const [created] = await db
      .insert(users)
      .values({
        name,
        email,
        phone: body.phone ?? null,
        passwordHash: hashPassword(body.password ?? ""),
        referralCode: referral,
        referredBy: body.referredBy?.toUpperCase() || null,
        fastoCoins: body.referredBy ? 200 : 50,
        walletBalance: body.referredBy ? 200 : 0,
      })
      .returning({ id: users.id, name: users.name, email: users.email, role: users.role });

    await createSession(created.id);
    await adoptVisitor(created.id);
    await welcomeNotifications(created.id, created.name, referral);
    return NextResponse.json({ ok: true, user: created });
  }

  if (body.action === "google") {
    // Live OAuth: when GOOGLE_CLIENT_ID is configured the client sends a Google ID
    // token which is verified against Google's tokeninfo endpoint. Without keys the
    // endpoint runs in sandbox mode and provisions a deterministic demo identity so
    // the full sign-in flow stays testable.
    const name = (body.name ?? "").trim() || email.split("@")[0].replace(/[._]/g, " ") || "FASTO Shopper";
    if (!validEmail(email)) return NextResponse.json({ ok: false, error: "A valid Google email is required." }, { status: 400 });

    let profile: { email: string; name: string; picture?: string } | null = null;
    const credential = body.token;
    if (credential) {
      try {
        const res = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
        if (res.ok) {
          const data = (await res.json()) as { email?: string; name?: string; picture?: string; aud?: string };
          if (data.email && (!process.env.GOOGLE_CLIENT_ID || data.aud === process.env.GOOGLE_CLIENT_ID)) {
            profile = { email: normalizeEmail(data.email), name: data.name ?? name, picture: data.picture };
          }
        }
      } catch {
        profile = null;
      }
    }

    const identity = profile ?? { email, name };
    const rows = await db.select().from(users).where(eq(users.email, identity.email)).limit(1);
    let user = rows[0];
    if (!user) {
      const referral = referralCode(identity.name);
      const [created] = await db
        .insert(users)
        .values({
          name: identity.name,
          email: identity.email,
          provider: "google",
          avatarUrl: "picture" in identity ? identity.picture ?? null : null,
          referralCode: referral,
          fastoCoins: 50,
        })
        .returning();
      user = created;
      await welcomeNotifications(created.id, created.name, referral);
    }
    await createSession(user.id);
    await adoptVisitor(user.id);
    return NextResponse.json({ ok: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  }

  if (body.action === "forgot") {
    if (!validEmail(email)) return NextResponse.json({ ok: false, error: "Enter a valid email address." }, { status: 400 });
    const rows = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (!rows[0]) {
      // Do not leak account existence.
      return NextResponse.json({ ok: true, message: "If that email is registered, a reset link is on its way." });
    }
    const token = randomBytes(24).toString("hex");
    await db.insert(passwordResets).values({
      token,
      userId: rows[0].id,
      expiresAt: new Date(Date.now() + 30 * 60 * 1000),
    });
    return NextResponse.json({
      ok: true,
      message: "Reset link generated. It expires in 30 minutes.",
      resetToken: token,
    });
  }

  if (body.action === "reset") {
    if (!validPassword(body.password ?? ""))
      return NextResponse.json({ ok: false, error: "Password needs 8+ characters with a letter and a number." }, { status: 400 });
    const rows = await db
      .select()
      .from(passwordResets)
      .where(and(eq(passwordResets.token, body.token ?? ""), gt(passwordResets.expiresAt, new Date()), isNull(passwordResets.usedAt)))
      .limit(1);
    if (!rows[0]) return NextResponse.json({ ok: false, error: "This reset link is invalid or has expired." }, { status: 400 });
    await db.update(users).set({ passwordHash: hashPassword(body.password ?? "") }).where(eq(users.id, rows[0].userId));
    await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.token, rows[0].token));
    await createSession(rows[0].userId);
    return NextResponse.json({ ok: true, message: "Password updated. You are signed in." });
  }

  const session = await currentUser();
  return NextResponse.json({ ok: false, error: "Unsupported action", session: session?.email ?? null }, { status: 400 });
}
