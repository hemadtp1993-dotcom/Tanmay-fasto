import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { currentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Sign in to write a review" }, { status: 401 });

  const body = (await request.json()) as { productId: number; rating: number; title?: string; body?: string };
  const rating = Math.max(1, Math.min(5, Math.round(Number(body.rating) || 0)));
  if (!body.productId || rating < 1) return NextResponse.json({ ok: false, error: "Select a rating first" }, { status: 400 });

  await db.insert(reviews).values({
    productId: body.productId,
    userId: user.id,
    authorName: user.name,
    rating,
    title: (body.title ?? "").slice(0, 80),
    body: (body.body ?? "").slice(0, 800),
  });

  const [agg] = await db
    .select({ avg: sql<number>`round(avg(${reviews.rating})::numeric, 1)::float`, count: sql<number>`count(*)::int` })
    .from(reviews)
    .where(eq(reviews.productId, body.productId));

  await db.update(products).set({ rating: agg?.avg ?? rating, reviewCount: agg?.count ?? 1 }).where(eq(products.id, body.productId));

  return NextResponse.json({ ok: true, message: "Thanks! Your review is live." });
}
