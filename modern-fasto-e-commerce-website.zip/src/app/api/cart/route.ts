import { NextResponse } from "next/server";
import { and, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { cartItems } from "@/db/schema";
import { currentUser, visitorId } from "@/lib/auth";
import { addToCart, computeTotals, getCart, getWishlistIds, toggleWishlist } from "@/lib/shop";

export const dynamic = "force-dynamic";

async function ownerFilter() {
  const user = await currentUser();
  const vid = await visitorId();
  return user ? or(eq(cartItems.userId, user.id), eq(cartItems.visitorId, vid)) : eq(cartItems.visitorId, vid);
}

export async function GET() {
  const lines = await getCart();
  const [totals, wishlist] = await Promise.all([Promise.resolve(computeTotals(lines)), getWishlistIds()]);
  return NextResponse.json({ lines, totals, wishlist });
}

export async function POST(request: Request) {
  const body = (await request.json()) as { productId: number; quantity?: number; size?: string | null; color?: string | null };
  if (!body.productId) return NextResponse.json({ ok: false, error: "productId is required" }, { status: 400 });
  const id = await addToCart(body);
  const lines = await getCart();
  return NextResponse.json({ ok: true, id, totals: computeTotals(lines) });
}

export async function PATCH(request: Request) {
  const body = (await request.json()) as { id: number; quantity?: number; savedForLater?: boolean };
  const where = and(eq(cartItems.id, body.id), await ownerFilter());
  const patch: Record<string, unknown> = {};
  if (typeof body.quantity === "number") patch.quantity = Math.max(1, Math.min(10, body.quantity));
  if (typeof body.savedForLater === "boolean") patch.savedForLater = body.savedForLater;
  if (!Object.keys(patch).length) return NextResponse.json({ ok: false, error: "Nothing to update" }, { status: 400 });
  await db.update(cartItems).set(patch).where(where);
  const lines = await getCart();
  return NextResponse.json({ ok: true, totals: computeTotals(lines) });
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = Number(searchParams.get("id"));
  if (!id) return NextResponse.json({ ok: false, error: "id is required" }, { status: 400 });
  await db.delete(cartItems).where(and(eq(cartItems.id, id), await ownerFilter()));
  const lines = await getCart();
  return NextResponse.json({ ok: true, totals: computeTotals(lines) });
}

export async function PUT() {
  const ids = await getWishlistIds();
  return NextResponse.json({ ok: true, ids, toggled: ids.length > 0 ? await toggleWishlist(ids[0]) : false });
}
