import { NextResponse } from "next/server";
import { listCoupons } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function GET() {
  const coupons = await listCoupons();
  return NextResponse.json({ coupons });
}
