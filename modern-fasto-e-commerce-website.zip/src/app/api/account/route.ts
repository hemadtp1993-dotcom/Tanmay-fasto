import { NextResponse } from "next/server";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import {
  addresses,
  notifications,
  orderItems,
  orders,
  paymentMethods,
  returnRequests,
  supportTickets,
  users,
} from "@/db/schema";
import { currentUser } from "@/lib/auth";
import { getOrdersForUser } from "@/lib/shop";

export const dynamic = "force-dynamic";

type Body = Record<string, unknown> & { action: string };

export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ ok: false, error: "Sign in required" }, { status: 401 });
  const [adds, pays, notes, orderList] = await Promise.all([
    db.select().from(addresses).where(eq(addresses.userId, user.id)),
    db.select().from(paymentMethods).where(eq(paymentMethods.userId, user.id)),
    db.select().from(notifications).where(eq(notifications.userId, user.id)),
    getOrdersForUser(user.id),
  ]);
  return NextResponse.json({ ok: true, addresses: adds, paymentMethods: pays, notifications: notes, orders: orderList });
}

export async function POST(request: Request) {
  const user = await currentUser();
  const body = (await request.json()) as Body;
  const action = body.action;

  /* ------------------------------ support ------------------------------ */
  if (action === "support.create") {
    const [row] = await db
      .insert(supportTickets)
      .values({
        userId: user?.id ?? null,
        name: String(body.name ?? "FASTO shopper"),
        email: String(body.email ?? "guest@fasto.in"),
        subject: String(body.subject ?? "General query"),
        message: String(body.message ?? ""),
      })
      .returning({ id: supportTickets.id });
    return NextResponse.json({ ok: true, ticket: `FASTO-${1000 + row.id}`, message: "Our care team will reply within 4 hours." });
  }

  if (!user) return NextResponse.json({ ok: false, error: "Sign in required" }, { status: 401 });

  /* ------------------------------ profile ------------------------------ */
  if (action === "profile.update") {
    await db
      .update(users)
      .set({
        name: String(body.name ?? user.name).slice(0, 60),
        phone: body.phone ? String(body.phone) : user.phone,
      })
      .where(eq(users.id, user.id));
    return NextResponse.json({ ok: true, message: "Profile updated" });
  }

  /* ----------------------------- addresses ----------------------------- */
  if (action === "address.save") {
    const values = {
      userId: user.id,
      label: String(body.label ?? "Home"),
      fullName: String(body.fullName ?? user.name),
      phone: String(body.phone ?? user.phone ?? ""),
      line1: String(body.line1 ?? ""),
      line2: body.line2 ? String(body.line2) : null,
      landmark: body.landmark ? String(body.landmark) : null,
      city: String(body.city ?? ""),
      state: String(body.state ?? ""),
      pincode: String(body.pincode ?? ""),
      isDefault: Boolean(body.isDefault),
    };
    if (!values.fullName || !values.line1 || !values.city || !/^\d{6}$/.test(values.pincode))
      return NextResponse.json({ ok: false, error: "Please fill name, address, city and a valid 6-digit pincode." }, { status: 400 });

    if (values.isDefault) await db.update(addresses).set({ isDefault: false }).where(eq(addresses.userId, user.id));
    if (body.id) {
      await db.update(addresses).set(values).where(and(eq(addresses.id, Number(body.id)), eq(addresses.userId, user.id)));
    } else {
      await db.insert(addresses).values(values);
    }
    return NextResponse.json({ ok: true, message: "Address saved" });
  }

  if (action === "address.delete") {
    await db.delete(addresses).where(and(eq(addresses.id, Number(body.id)), eq(addresses.userId, user.id)));
    return NextResponse.json({ ok: true, message: "Address removed" });
  }

  if (action === "address.default") {
    const id = Number(body.id);
    await db.update(addresses).set({ isDefault: false }).where(eq(addresses.userId, user.id));
    await db.update(addresses).set({ isDefault: true }).where(and(eq(addresses.id, id), eq(addresses.userId, user.id)));
    return NextResponse.json({ ok: true });
  }

  /* -------------------------- payment methods -------------------------- */
  if (action === "payment.save") {
    await db.insert(paymentMethods).values({
      userId: user.id,
      kind: String(body.kind ?? "card"),
      label: String(body.label ?? "Saved method"),
      detail: String(body.detail ?? "").slice(-24),
    });
    return NextResponse.json({ ok: true, message: "Payment method saved securely" });
  }

  if (action === "payment.delete") {
    await db.delete(paymentMethods).where(and(eq(paymentMethods.id, Number(body.id)), eq(paymentMethods.userId, user.id)));
    return NextResponse.json({ ok: true, message: "Payment method removed" });
  }

  /* ---------------------------- notifications -------------------------- */
  if (action === "notifications.read") {
    await db.update(notifications).set({ readAt: new Date() }).where(eq(notifications.userId, user.id));
    return NextResponse.json({ ok: true });
  }

  if (action === "notification.read") {
    await db
      .update(notifications)
      .set({ readAt: new Date() })
      .where(and(eq(notifications.id, Number(body.id)), eq(notifications.userId, user.id)));
    return NextResponse.json({ ok: true });
  }

  /* ------------------------------- returns ----------------------------- */
  if (action === "return.create") {
    const orderId = Number(body.orderId);
    const rows = await db.select().from(orders).where(and(eq(orders.id, orderId), eq(orders.userId, user.id))).limit(1);
    if (!rows[0]) return NextResponse.json({ ok: false, error: "Order not found" }, { status: 404 });
    const itemId = body.orderItemId ? Number(body.orderItemId) : null;
    let amount = rows[0].total;
    if (itemId) {
      const item = await db.select().from(orderItems).where(and(eq(orderItems.id, itemId), eq(orderItems.orderId, orderId))).limit(1);
      amount = item[0] ? item[0].price * item[0].quantity : rows[0].total;
    }
    const [row] = await db
      .insert(returnRequests)
      .values({
        orderId,
        orderItemId: itemId,
        userId: user.id,
        orderNumber: rows[0].orderNumber,
        kind: String(body.kind ?? "return"),
        reason: String(body.reason ?? "Not as expected"),
        comments: String(body.comments ?? ""),
        refundAmount: amount,
      })
      .returning({ id: returnRequests.id });
    if (itemId) await db.update(orderItems).set({ itemStatus: String(body.kind ?? "return") }).where(eq(orderItems.id, itemId));
    await db.insert(notifications).values({
      userId: user.id,
      title: `${String(body.kind ?? "return") === "replace" ? "Replacement" : "Return"} request received`,
      body: `Request #${row.id} for ${rows[0].orderNumber}. Pickup will be scheduled within 48 hours.`,
      kind: "order",
      href: "/account?tab=returns",
    });
    return NextResponse.json({ ok: true, message: "Request raised. Pickup in 48 hours, refund in 3 working days." });
  }

  if (action === "return.cancel") {
    await db
      .update(returnRequests)
      .set({ status: "cancelled" })
      .where(and(eq(returnRequests.id, Number(body.id)), eq(returnRequests.userId, user.id)));
    return NextResponse.json({ ok: true, message: "Request cancelled" });
  }

  /* ------------------------------- orders ------------------------------ */
  if (action === "order.cancel") {
    const id = Number(body.orderId);
    const rows = await db.select().from(orders).where(and(eq(orders.id, id), eq(orders.userId, user.id))).limit(1);
    if (!rows[0]) return NextResponse.json({ ok: false, error: "Order not found" }, { status: 404 });
    if (["shipped", "out_for_delivery", "delivered", "cancelled"].includes(rows[0].status))
      return NextResponse.json({ ok: false, error: "This order can no longer be cancelled. Please raise a return instead." }, { status: 400 });
    await db
      .update(orders)
      .set({
        status: "cancelled",
        timeline: rows[0].timeline.map((s) => ({ ...s })),
        paymentStatus: rows[0].paymentStatus === "paid" ? "refund_initiated" : "cancelled",
      })
      .where(eq(orders.id, id));
    await db.update(orderItems).set({ itemStatus: "cancelled" }).where(eq(orderItems.orderId, id));
    await db.insert(notifications).values({
      userId: user.id,
      title: `Order ${rows[0].orderNumber} cancelled`,
      body: rows[0].paymentStatus === "paid" ? "Your refund has been initiated and will reach you in 3-5 working days." : "No amount was charged.",
      kind: "order",
      href: `/account/orders/${rows[0].orderNumber}`,
    });
    return NextResponse.json({ ok: true, message: "Order cancelled" });
  }

  if (action === "order.invoice") {
    const rows = await db.select().from(orders).where(and(eq(orders.id, Number(body.orderId)), eq(orders.userId, user.id))).limit(1);
    if (!rows[0]) return NextResponse.json({ ok: false, error: "Order not found" }, { status: 404 });
    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, rows[0].id));
    return NextResponse.json({ ok: true, order: rows[0], items });
  }

  if (action === "notification.clearAll") {
    await db.delete(notifications).where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)));
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ ok: false, error: `Unknown action: ${action}` }, { status: 400 });
}
