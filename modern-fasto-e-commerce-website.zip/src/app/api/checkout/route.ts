import { NextResponse } from "next/server";
import { createHmac, randomBytes } from "node:crypto";
import { currentUser } from "@/lib/auth";
import { computeTotals, evaluateCoupon, getCart, placeOrder } from "@/lib/shop";

export const dynamic = "force-dynamic";

type Body = {
  action: "summary" | "payment" | "verify" | "place";
  code?: string;
  coinsUsed?: number;
  amount?: number;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  razorpaySignature?: string;
  address?: Record<string, string>;
  paymentMethod?: string;
  email?: string;
  phone?: string;
};

function razorpayConfig() {
  return {
    keyId: process.env.RAZORPAY_KEY_ID ?? null,
    keySecret: process.env.RAZORPAY_KEY_SECRET ?? null,
  };
}

/** Creates a gateway-ready order payload. In sandbox mode (no keys) a deterministic
 *  mock order id is returned so the whole checkout journey stays testable. */
async function createGatewayOrder(amountPaise: number, receipt: string) {
  const { keyId, keySecret } = razorpayConfig();
  if (keyId && keySecret) {
    const res = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        authorization: `Basic ${Buffer.from(`${keyId}:${keySecret}`).toString("base64")}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({ amount: amountPaise, currency: "INR", receipt, payment_capture: 1 }),
    });
    if (res.ok) {
      const data = (await res.json()) as { id: string; amount: number; currency: string };
      return { id: data.id, amount: data.amount, currency: data.currency, live: true, keyId };
    }
  }
  return {
    id: `order_sbx${randomBytes(8).toString("hex")}`,
    amount: amountPaise,
    currency: "INR",
    live: false,
    keyId: keyId ?? "rzp_test_FASTOSANDBOX",
  };
}

export async function POST(request: Request) {
  const body = (await request.json()) as Body;
  const lines = await getCart(false);
  const itemsTotal = lines.reduce((s, l) => s + l.product.price * l.quantity, 0);

  let discount = 0;
  let freeShipping = false;
  let couponCode: string | null = null;
  if (body.code) {
    const result = await evaluateCoupon(body.code, itemsTotal);
    if (result.ok) {
      discount = result.discount;
      freeShipping = result.freeShipping;
      couponCode = result.code;
    }
  }

  const totals = computeTotals(lines, { discount, freeShipping, coinsUsed: body.coinsUsed });

  if (body.action === "summary") {
    return NextResponse.json({ ok: true, totals, coupon: { code: couponCode, discount, freeShipping }, itemCount: lines.length });
  }

  if (body.action === "payment") {
    const gateway = await createGatewayOrder(totals.total * 100, `fasto_${Date.now()}`);
    return NextResponse.json({ ok: true, gateway, totals });
  }

  if (body.action === "verify") {
    const { keySecret } = razorpayConfig();
    const { razorpayOrderId, razorpayPaymentId, razorpaySignature } = body;
    if (keySecret && razorpayOrderId && razorpayPaymentId && razorpaySignature) {
      const expected = createHmac("sha256", keySecret).update(`${razorpayOrderId}|${razorpayPaymentId}`).digest("hex");
      if (expected !== razorpaySignature) return NextResponse.json({ ok: false, error: "Payment signature mismatch" }, { status: 400 });
      return NextResponse.json({ ok: true, paymentRef: razorpayPaymentId, verified: true });
    }
    return NextResponse.json({
      ok: true,
      paymentRef: razorpayPaymentId ?? `pay_sbx${randomBytes(8).toString("hex")}`,
      verified: true,
      sandbox: true,
    });
  }

  if (body.action === "place") {
    const user = await currentUser();
    const address = body.address ?? {};
    if (!address.line1 || !address.pincode || !address.fullName)
      return NextResponse.json({ ok: false, error: "Delivery address is incomplete" }, { status: 400 });

    const method = body.paymentMethod ?? "cod";
    const isPrepaid = method !== "cod";
    let paymentRef: string | null = null;

    if (isPrepaid) {
      const gateway = await createGatewayOrder(totals.total * 100, `fasto_${Date.now()}`);
      paymentRef = `pay_${gateway.id.replace("order_", "").slice(0, 12)}`;
    }

    const { order } = await placeOrder({
      address,
      paymentMethod: method,
      paymentStatus: method === "cod" ? "pending" : "paid",
      paymentRef,
      couponCode,
      discount,
      freeShipping,
      coinsUsed: body.coinsUsed,
      email: body.email ?? user?.email ?? "guest@fasto.in",
      phone: body.phone ?? address.phone ?? user?.phone ?? "",
    });

    return NextResponse.json({ ok: true, orderNumber: order.orderNumber, total: order.total });
  }

  return NextResponse.json({ ok: false, error: "Unsupported action" }, { status: 400 });
}
