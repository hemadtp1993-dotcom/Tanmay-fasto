import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  banners,
  categories,
  coupons,
  orderItems,
  orders,
  products,
  returnRequests,
  users,
} from "@/db/schema";
import { currentUser } from "@/lib/auth";
import { slugify } from "@/lib/format";

export const dynamic = "force-dynamic";

type Body = Record<string, unknown> & { action: string };

async function requireAdmin() {
  const user = await currentUser();
  if (!user || user.role !== "admin") return null;
  return user;
}

const str = (v: unknown, fallback = "") => (typeof v === "string" && v.length ? v : fallback);
const num = (v: unknown, fallback = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.round(n) : fallback;
};
const list = (v: unknown) =>
  typeof v === "string"
    ? v.split(/[\n,]/).map((s) => s.trim()).filter(Boolean)
    : Array.isArray(v)
      ? (v as string[])
      : [];

export async function POST(request: Request) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ ok: false, error: "Admin access required" }, { status: 403 });

  const body = (await request.json()) as Body;
  const action = body.action;

  /* ------------------------------ products ----------------------------- */
  if (action === "product.save") {
    const title = str(body.title);
    if (!title) return NextResponse.json({ ok: false, error: "Product title is required" }, { status: 400 });
    const price = num(body.price);
    const mrp = num(body.mrp, price);
    if (price <= 0) return NextResponse.json({ ok: false, error: "Price must be greater than zero" }, { status: 400 });

    const values = {
      title,
      slug: str(body.slug) || slugify(title),
      brand: str(body.brand, "FASTO Essentials"),
      categorySlug: str(body.categorySlug, "electronics"),
      shortDescription: str(body.shortDescription, title),
      description: str(body.description, str(body.shortDescription, title)),
      specs: list(body.specs).map((line) => {
        const [label, ...rest] = line.split(":");
        return { label: label.trim(), value: rest.join(":").trim() };
      }),
      highlights: list(body.highlights),
      images: list(body.images).length ? list(body.images) : ["https://images.pexels.com/photos/3568521/pexels-photo-3568521.jpeg?auto=compress&cs=tinysrgb&w=700&h=700&fit=crop"],
      colors: list(body.colors),
      sizes: list(body.sizes),
      price,
      mrp,
      stock: num(body.stock, 0),
      rating: Math.min(5, Math.max(1, Number(body.rating) || 4.2)),
      reviewCount: num(body.reviewCount, 0),
      isFlashSale: Boolean(body.isFlashSale),
      trending: Boolean(body.trending),
      bestseller: Boolean(body.bestseller),
      newArrival: Boolean(body.newArrival),
    };

    if (body.id) {
      await db.update(products).set(values).where(eq(products.id, num(body.id)));
      return NextResponse.json({ ok: true, message: `“${title}” updated` });
    }
    await db.insert(products).values(values);
    return NextResponse.json({ ok: true, message: `“${title}” added to catalogue` });
  }

  if (action === "product.delete") {
    await db.delete(products).where(eq(products.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "Product removed" });
  }

  if (action === "product.stock") {
    await db.update(products).set({ stock: num(body.stock) }).where(eq(products.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "Inventory updated" });
  }

  if (action === "product.price") {
    await db.update(products).set({ price: num(body.price), mrp: num(body.mrp, num(body.price)) }).where(eq(products.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "Pricing updated" });
  }

  /* ----------------------------- categories ---------------------------- */
  if (action === "category.save") {
    const name = str(body.name);
    if (!name) return NextResponse.json({ ok: false, error: "Category name is required" }, { status: 400 });
    const values = {
      name,
      slug: str(body.slug) || slugify(name),
      icon: str(body.icon, "🛍️"),
      tagline: str(body.tagline),
      featured: body.featured === undefined ? true : Boolean(body.featured),
      sortOrder: num(body.sortOrder, 99),
    };
    if (body.id) await db.update(categories).set(values).where(eq(categories.id, num(body.id)));
    else await db.insert(categories).values(values);
    return NextResponse.json({ ok: true, message: `Category “${name}” saved` });
  }

  if (action === "category.delete") {
    await db.delete(categories).where(eq(categories.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "Category removed" });
  }

  /* ------------------------------ coupons ------------------------------ */
  if (action === "coupon.save") {
    const code = str(body.code).toUpperCase();
    if (!code) return NextResponse.json({ ok: false, error: "Coupon code is required" }, { status: 400 });
    const values = {
      code,
      title: str(body.title, code),
      description: str(body.description),
      type: str(body.type, "flat"),
      value: num(body.value),
      minCart: num(body.minCart),
      maxDiscount: num(body.maxDiscount, 100000),
      active: body.active === undefined ? true : Boolean(body.active),
    };
    if (body.id) await db.update(coupons).set(values).where(eq(coupons.id, num(body.id)));
    else await db.insert(coupons).values(values).onConflictDoNothing();
    return NextResponse.json({ ok: true, message: `Coupon ${code} saved` });
  }

  if (action === "coupon.toggle") {
    const id = num(body.id);
    const [row] = await db.select().from(coupons).where(eq(coupons.id, id)).limit(1);
    if (!row) return NextResponse.json({ ok: false, error: "Coupon not found" }, { status: 404 });
    await db.update(coupons).set({ active: !row.active }).where(eq(coupons.id, id));
    return NextResponse.json({ ok: true, message: `${row.code} is now ${!row.active ? "active" : "paused"}` });
  }

  if (action === "coupon.delete") {
    await db.delete(coupons).where(eq(coupons.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "Coupon deleted" });
  }

  /* ------------------------------- banners ----------------------------- */
  if (action === "banner.save") {
    const title = str(body.title);
    if (!title) return NextResponse.json({ ok: false, error: "Banner title is required" }, { status: 400 });
    const values = {
      title,
      subtitle: str(body.subtitle),
      ctaText: str(body.ctaText, "Shop now"),
      ctaHref: str(body.ctaHref, "/products"),
      imageUrl: body.imageUrl ? str(body.imageUrl) : null,
      gradient: str(body.gradient, "from-brand-600 to-flame-500"),
      placement: str(body.placement, "hero"),
      active: body.active === undefined ? true : Boolean(body.active),
      sortOrder: num(body.sortOrder, 10),
    };
    if (body.id) await db.update(banners).set(values).where(eq(banners.id, num(body.id)));
    else await db.insert(banners).values(values);
    return NextResponse.json({ ok: true, message: "Banner saved" });
  }

  if (action === "banner.delete") {
    await db.delete(banners).where(eq(banners.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "Banner removed" });
  }

  if (action === "banner.toggle") {
    const id = num(body.id);
    const [row] = await db.select().from(banners).where(eq(banners.id, id)).limit(1);
    if (!row) return NextResponse.json({ ok: false, error: "Banner not found" }, { status: 404 });
    await db.update(banners).set({ active: !row.active }).where(eq(banners.id, id));
    return NextResponse.json({ ok: true, message: `Banner ${!row.active ? "published" : "hidden"}` });
  }

  /* -------------------------------- orders ----------------------------- */
  if (action === "order.status") {
    const id = num(body.id);
    const status = str(body.status, "confirmed");
    const [row] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
    if (!row) return NextResponse.json({ ok: false, error: "Order not found" }, { status: 404 });
    const flow = ["confirmed", "packed", "shipped", "out_for_delivery", "delivered"];
    const index = flow.indexOf(status);
    const timeline = row.timeline.map((step, i) => ({
      ...step,
      done: index >= 0 ? i <= index : step.done,
      at: index >= 0 && i <= index && !step.at ? new Date().toISOString() : step.at,
    }));
    await db.update(orders).set({ status, timeline, paymentStatus: status === "delivered" ? "paid" : row.paymentStatus }).where(eq(orders.id, id));
    if (status === "cancelled") await db.update(orderItems).set({ itemStatus: "cancelled" }).where(eq(orderItems.orderId, id));
    return NextResponse.json({ ok: true, message: `${row.orderNumber} → ${status.replace(/_/g, " ")}` });
  }

  if (action === "return.status") {
    await db.update(returnRequests).set({ status: str(body.status, "approved") }).where(eq(returnRequests.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "Return request updated" });
  }

  /* -------------------------------- users ------------------------------ */
  if (action === "user.role") {
    await db.update(users).set({ role: str(body.role, "customer") }).where(eq(users.id, num(body.id)));
    return NextResponse.json({ ok: true, message: "User role updated" });
  }

  return NextResponse.json({ ok: false, error: `Unknown action: ${action}` }, { status: 400 });
}
