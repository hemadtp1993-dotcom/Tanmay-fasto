import { NextResponse } from "next/server";
import { getProductsByIds } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const ids = (searchParams.get("ids") ?? "")
    .split(",")
    .map((v) => Number(v))
    .filter((v) => Number.isFinite(v) && v > 0);
  const products = await getProductsByIds(ids);
  return NextResponse.json({ products });
}
