import { NextResponse } from "next/server";
import { getWishlistProducts, toggleWishlist } from "@/lib/shop";

export const dynamic = "force-dynamic";

export async function GET() {
  const products = await getWishlistProducts();
  return NextResponse.json({ products, ids: products.map((p) => p.id) });
}

export async function POST(request: Request) {
  const body = (await request.json()) as { productId: number };
  if (!body.productId) return NextResponse.json({ ok: false, error: "productId is required" }, { status: 400 });
  const wishlisted = await toggleWishlist(body.productId);
  return NextResponse.json({ ok: true, wishlisted });
}
