import Link from "next/link";
import { notFound } from "next/navigation";
import { ORDER_STATUS_LABEL, deliveryPromise, formatDateTime, rupees } from "@/lib/format";
import { getOrderByNumber } from "@/lib/shop";
import { CtaLink } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata = { title: "Order confirmed" };

export default async function OrderConfirmationPage({ params }: { params: Promise<{ orderNumber: string }> }) {
  const { orderNumber } = await params;
  const order = await getOrderByNumber(orderNumber);
  if (!order) notFound();

  const address = order.shippingAddress as Record<string, string>;

  return (
    <div className="mx-auto max-w-3xl space-y-5 py-4">
      <div className="panel overflow-hidden rounded-3xl">
        <div className="relative bg-gradient-to-br from-emerald-600 to-teal-500 px-6 py-10 text-center text-white">
          <span className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/15 blur-2xl" />
          <div className="relative">
            <span className="grid mx-auto h-16 w-16 place-items-center rounded-full bg-white/25 text-3xl">✓</span>
            <h1 className="mt-4 text-2xl font-black tracking-tight sm:text-3xl">Order confirmed!</h1>
            <p className="mt-1 text-sm text-white/90">
              Thank you {address.fullName}. Your order <strong>{order.orderNumber}</strong> is being packed.
            </p>
          </div>
        </div>

        <div className="grid gap-4 p-5 sm:grid-cols-3">
          {[
            ["Order number", order.orderNumber],
            ["Placed on", formatDateTime(order.createdAt)],
            ["Amount paid", `${rupees(order.total)} · ${order.paymentMethod.toUpperCase()}`],
            ["Payment status", order.paymentStatus === "paid" ? "Paid" : order.paymentStatus === "pending" ? "Pay on delivery" : order.paymentStatus],
            ["Delivery expected", deliveryPromise(address.pincode)],
            ["Items", `${order.items.length} product${order.items.length === 1 ? "" : "s"}`],
          ].map(([label, value]) => (
            <div key={label} className="rounded-2xl bg-ink-400/6 p-3">
              <p className="text-[10px] font-black uppercase tracking-wide text-ink-400">{label}</p>
              <p className="mt-0.5 text-sm font-bold text-ink-900 dark:text-white">{value}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="panel rounded-3xl p-5">
        <h2 className="text-sm font-black uppercase tracking-wide text-ink-400">Items in this order</h2>
        <div className="mt-3 space-y-3">
          {order.items.map((item) => (
            <div key={item.id} className="flex items-center gap-3">
              <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-ink-50 dark:bg-ink-900">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.image} alt="" loading="lazy" className="h-full w-full object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <Link href={`/product/${item.slug}`} className="line-clamp-1 text-sm font-semibold text-ink-900 hover:text-brand-600 dark:text-white">
                  {item.title}
                </Link>
                <p className="text-[11px] text-ink-400">
                  Qty {item.quantity}
                  {item.size ? ` · ${item.size}` : ""}
                  {item.color ? ` · ${item.color}` : ""}
                </p>
              </div>
              <p className="text-sm font-bold text-ink-900 dark:text-white">{rupees(item.price * item.quantity)}</p>
            </div>
          ))}
        </div>

        <dl className="mt-5 space-y-2 border-t pt-4 text-sm hairline">
          <div className="flex justify-between">
            <dt className="text-ink-600 dark:text-ink-300">Items total</dt>
            <dd className="font-bold">{rupees(order.itemsTotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-600 dark:text-ink-300">Discount {order.couponCode ? `(${order.couponCode})` : ""}</dt>
            <dd className="font-bold text-emerald-600 dark:text-emerald-400">− {rupees(order.discount)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-600 dark:text-ink-300">Delivery</dt>
            <dd className="font-bold">{order.deliveryFee === 0 ? "FREE" : rupees(order.deliveryFee)}</dd>
          </div>
          <div className="flex justify-between border-t pt-2 hairline">
            <dt className="font-black text-ink-900 dark:text-white">Total paid</dt>
            <dd className="text-lg font-black text-ink-900 dark:text-white">{rupees(order.total)}</dd>
          </div>
        </dl>
      </div>

      <div className="panel rounded-3xl p-5">
        <h2 className="text-sm font-black uppercase tracking-wide text-ink-400">Delivering to</h2>
        <p className="mt-2 text-sm font-bold text-ink-900 dark:text-white">
          {address.fullName} · {address.phone}
        </p>
        <p className="text-xs leading-relaxed text-ink-500 dark:text-ink-300">
          {address.line1}
          {address.line2 ? `, ${address.line2}` : ""}, {address.city}, {address.state} — {address.pincode}
        </p>
        <p className="mt-3 rounded-xl bg-brand-500/8 px-3 py-2 text-xs text-brand-700 dark:text-brand-200">
          Status: <strong>{ORDER_STATUS_LABEL[order.status] ?? order.status}</strong>. We&apos;ll notify you at every step.
        </p>
      </div>

      <div className="flex flex-wrap gap-3">
        <CtaLink href={`/account/orders/${order.orderNumber}`}>Track this order</CtaLink>
        <CtaLink href="/products" variant="outline">
          Continue shopping
        </CtaLink>
      </div>
    </div>
  );
}
