import Link from "next/link";
import type { Metadata } from "next";
import { StatStrip } from "@/components/home-blocks";
import { CtaLink } from "@/components/ui";

export const metadata: Metadata = {
  title: "About FASTO",
  description: "FASTO is an Indian e-commerce startup on a mission to make online shopping faster, fairer and friendlier.",
};

export default function AboutPage() {
  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-700 via-brand-600 to-flame-500 px-6 py-14 text-white sm:px-12">
        <span className="absolute -right-10 -top-16 h-56 w-56 rounded-full bg-white/15 blur-2xl" />
        <span className="absolute -bottom-20 left-1/4 h-56 w-56 rounded-full bg-black/15 blur-2xl" />
        <div className="relative max-w-2xl">
          <p className="text-xs font-black uppercase tracking-[0.24em] text-white/80">Our story</p>
          <h1 className="mt-3 text-3xl font-black leading-tight tracking-tight sm:text-5xl">
            We started FASTO because waiting for a parcel is the worst part of shopping.
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-white/90 sm:text-base">
            Founded in Bengaluru in 2024 by a team of logistics engineers and retail veterans, FASTO runs 34 fulfilment
            centres across India so that a customer in Kota gets the same two-day promise as one in Koramangala.
          </p>
        </div>
      </section>

      <StatStrip />

      <section className="grid gap-4 sm:grid-cols-3">
        {[
          ["🎯", "Our mission", "Make every Indian product discoverable, affordable and deliverable within 48 hours — without dark patterns, fake MRPs or hidden fees."],
          ["🌱", "FASTO Green", "We offset every delivery kilometre, use 100% recycled packaging and plant a sapling for every 500 orders shipped."],
          ["🤝", "Seller first", "12,400+ Indian sellers, 72-hour payouts, zero listing fees for the first year and free product photography in 9 cities."],
        ].map(([icon, title, body]) => (
          <div key={title} className="panel lift rounded-3xl p-6">
            <span aria-hidden className="text-3xl">{icon}</span>
            <h2 className="mt-3 text-base font-black text-ink-900 dark:text-white">{title}</h2>
            <p className="mt-1.5 text-sm leading-relaxed text-ink-400">{body}</p>
          </div>
        ))}
      </section>

      <section id="careers" className="panel rounded-3xl p-6 sm:p-8">
        <h2 className="text-xl font-black tracking-tight text-ink-900 dark:text-white">Careers at FASTO</h2>
        <p className="mt-1 text-sm text-ink-400">We are 340 people across Bengaluru, Gurugram and Hyderabad — and hiring.</p>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[
            ["Senior Backend Engineer", "Bengaluru · Full-time"],
            ["Category Manager — Fashion", "Gurugram · Full-time"],
            ["Data Analyst, Logistics", "Hyderabad · Full-time"],
            ["UX Designer (Mobile)", "Bengaluru · Full-time"],
            ["Warehouse Operations Lead", "Nagpur · Full-time"],
            ["Customer Experience Associate", "Remote · Rotational"],
          ].map(([role, meta]) => (
            <div key={role} className="rounded-2xl border p-4 transition hover:border-brand-500 hairline">
              <p className="text-sm font-bold text-ink-900 dark:text-white">{role}</p>
              <p className="text-[11px] text-ink-400">{meta}</p>
              <Link href="/contact" className="mt-2 inline-block text-xs font-bold text-brand-600 dark:text-brand-300">
                Apply →
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section id="press" className="panel rounded-3xl p-6 sm:p-8">
        <h2 className="text-xl font-black tracking-tight text-ink-900 dark:text-white">Press &amp; media</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {[
            ["Series A", "$42M raised in 2025 to expand same-day delivery to 40 cities."],
            ["Fast Company", "Named among Asia-Pacific's most innovative commerce companies."],
            ["Economic Times", "Winner — Best Customer Experience in E-commerce, 2025."],
          ].map(([tag, body]) => (
            <div key={tag} className="rounded-2xl bg-ink-400/6 p-4">
              <p className="text-xs font-black uppercase tracking-wide text-brand-600 dark:text-brand-300">{tag}</p>
              <p className="mt-1 text-sm text-ink-600 dark:text-ink-200">{body}</p>
            </div>
          ))}
        </div>
        <p className="mt-4 text-xs text-ink-400">For interviews and brand assets, write to press@fasto.in</p>
      </section>

      <section id="sell" className="relative overflow-hidden rounded-3xl bg-ink-950 px-6 py-12 text-center text-white sm:px-12">
        <div className="absolute -left-10 -bottom-16 h-48 w-48 rounded-full bg-brand-600/40 blur-3xl" />
        <div className="relative">
          <h2 className="text-2xl font-black tracking-tight sm:text-3xl">Sell to 42 lakh shoppers</h2>
          <p className="mx-auto mt-2 max-w-lg text-sm text-white/70">
            Onboard in 48 hours with zero listing fees for the first year. GSTIN and a bank account are all you need.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <CtaLink href="/contact" variant="solid" className="!bg-white !text-ink-900 !shadow-none">
              Become a seller
            </CtaLink>
            <CtaLink href="/products" variant="outline" className="!border-white/40 !bg-white/10 !text-white">
              Explore the marketplace
            </CtaLink>
          </div>
        </div>
      </section>
    </div>
  );
}
