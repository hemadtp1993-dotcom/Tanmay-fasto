import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-lg flex-col items-center justify-center text-center">
      <p className="bg-gradient-to-r from-brand-600 to-flame-500 bg-clip-text text-6xl font-black text-transparent">404</p>
      <h1 className="mt-3 text-2xl font-black tracking-tight text-ink-900 dark:text-white">This page took a wrong turn</h1>
      <p className="mt-2 text-sm text-ink-400">
        The link may be broken or the product may have been removed. Let&apos;s get you back to the good stuff.
      </p>
      <div className="mt-6 flex flex-wrap justify-center gap-3">
        <Link href="/" className="rounded-xl bg-brand-600 px-5 py-3 text-sm font-bold text-white">
          Back to home
        </Link>
        <Link href="/products" className="rounded-xl border px-5 py-3 text-sm font-bold text-ink-700 hairline dark:text-ink-100">
          Browse products
        </Link>
      </div>
    </div>
  );
}
