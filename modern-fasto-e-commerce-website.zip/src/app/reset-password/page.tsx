"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

export default function ResetPasswordPage() {
  const params = useSearchParams();
  const router = useRouter();
  const token = params.get("token") ?? "";
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (password !== confirm) {
      setError("Both passwords must match.");
      return;
    }
    setBusy(true);
    setError(null);
    const res = await fetch("/api/auth", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "reset", token, password }),
    });
    const data = (await res.json()) as { ok: boolean; error?: string };
    if (!data.ok) {
      setError(data.error ?? "Could not reset password");
      setBusy(false);
      return;
    }
    router.push("/account");
    router.refresh();
  }

  return (
    <div className="mx-auto max-w-md py-10">
      <div className="panel rounded-3xl p-7">
        <h1 className="text-2xl font-black text-ink-900 dark:text-white">Choose a new password</h1>
        <p className="mt-1 text-sm text-ink-400">Your reset link is single-use and expires 30 minutes after it was created.</p>
        <form onSubmit={submit} className="mt-6 space-y-3.5">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="New password (8+ chars)"
            required
            minLength={8}
            className="w-full rounded-xl border bg-transparent px-3.5 py-2.5 text-sm outline-none focus:border-brand-500 hairline"
          />
          <input
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            placeholder="Confirm new password"
            required
            minLength={8}
            className="w-full rounded-xl border bg-transparent px-3.5 py-2.5 text-sm outline-none focus:border-brand-500 hairline"
          />
          {error && <p className="rounded-xl bg-rose-500/10 px-3 py-2 text-xs font-semibold text-rose-600">{error}</p>}
          <button type="submit" disabled={busy || !token} className="w-full rounded-xl bg-brand-600 py-3 text-sm font-bold text-white disabled:opacity-60">
            {busy ? "Updating…" : "Update password"}
          </button>
        </form>
        {!token && (
          <p className="mt-4 rounded-xl bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-700 dark:text-amber-400">
            No reset token found.{" "}
            <Link href="/forgot-password" className="underline">
              Request a new link
            </Link>
          </p>
        )}
      </div>
    </div>
  );
}
