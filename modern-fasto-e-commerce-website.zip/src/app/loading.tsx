export default function Loading() {
  return (
    <div className="space-y-6">
      <div className="shimmer h-[240px] rounded-3xl sm:h-[300px]" />
      <div className="flex gap-3 overflow-hidden">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="shimmer h-[92px] w-[92px] shrink-0 rounded-2xl" />
        ))}
      </div>
      <div className="shimmer h-7 w-48 rounded-xl" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="panel rounded-2xl p-3">
            <div className="shimmer aspect-square rounded-xl" />
            <div className="shimmer mt-3 h-3 w-3/4 rounded" />
            <div className="shimmer mt-2 h-3 w-1/2 rounded" />
          </div>
        ))}
      </div>
    </div>
  );
}
