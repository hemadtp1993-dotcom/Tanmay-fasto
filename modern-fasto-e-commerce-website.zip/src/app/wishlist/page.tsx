import Link from "next/link";
import ProductCard from "@/components/product-card";
import { CtaLink, EmptyState, SectionHeader } from "@/components/ui";
import { getWishlistProducts } from "@/lib/shop";

export const dynamic = "force-dynamic";
export const metadata = { title: "My wishlist" };

export default async function WishlistPage() {
  const products = await getWishlistProducts();

  return (
    <div className="space-y-5">
      <SectionHeader title="My wishlist" subtitle={`${products.length} saved item${products.length === 1 ? "" : "s"} · we alert you when prices drop`} />

      {products.length === 0 ? (
        <EmptyState
          icon="❤️"
          title="Your wishlist is empty"
          body="Tap the heart on any product to save it here. We will notify you about price drops and restocks."
          action={<CtaLink href="/products">Start exploring</CtaLink>}
        />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}

      <p className="text-center text-xs text-ink-400">
        Want to see them side by side?{" "}
        <Link href="/compare" className="font-bold text-brand-600 dark:text-brand-300">
          Open the comparison tool →
        </Link>
      </p>
    </div>
  );
}
