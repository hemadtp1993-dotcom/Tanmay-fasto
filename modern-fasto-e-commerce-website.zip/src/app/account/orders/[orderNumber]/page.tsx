import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { OrderActions } from "@/components/order-actions";
import { ORDER_FLOW, ORDER_STATUS_LABEL, formatDateTime, rupees, statusTone } from "@/lib/format";
import { currentUser } from "@/lib/auth";
import { getOrderByNumber } from "@/lib/shop";

export const dynamic = "force-dynamic";
export const metadata = { title: "Order details" };

export default async function OrderDetailPage({ params }: { params: Promise<{ orderNumber: string }> }) {
  const user = await currentUser();
  if (!user) redirect("/login?next=%2Faccount%2Forders");

  const { orderNumber } = await params;
  const order = await getOrderByNumber(orderNumber);
  if (!order) notFound();
  if (order.userId && order.userId !== user.id && user.role !== "admin") notFound();

  const address = order.shippingAddress as Record<string, string>;
  const currentIndex = ORDER_FLOW.indexOf(order.status as (typeof ORDER_FLOW)[number]);

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <Link href="/account?tab=orders" className="text-xs font-bold text-brand-600 dark:text-brand-300">
        ← Back to my orders
      </Link>

      <div className="panel rounded-3xl p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-black tracking-tight text-ink-900 dark:text-white">{order.orderNumber}</h1>
            <p className="text-xs text-ink-400">Placed {formatDateTime(order.createdAt)}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <span className={`rounded-full px-3 py-1 text-xs font-bold ${statusTone(order.status)}`}>
              {ORDER_STATUS_LABEL[order.status] ?? order.status}
            </span>
            <span className={`rounded-full px-3 py-1 text-xs font-bold ${statusTone(order.paymentStatus)}`}>
              {order.paymentMethod.toUpperCase()} · {order.paymentStatus}
            </span>
          </div>
        </div>

        {/* timeline */}
        <div className="mt-6">
          <p className="mb-4 text-xs font-black uppercase tracking-wide text-ink-400">Tracking timeline</p>
          <ol className="relative space-y-5 border-l-2 pl-6 hairline">
            {order.timeline.map((step, i) => {
              const reached = step.done || (currentIndex >= 0 ? i <= currentIndex : false);
              return (
                <li key={step.label} className="relative">
                  <span
                    className={`absolute -left-[31px] grid h-5 w-5 place-items-center rounded-full text-[10px] font-black ${
                      reached ? "bg-brand-600 text-white" : "bg-ink-400/25 text-ink-400"
                    }`}
                  >
                    {reached ? "✓" : i + 1}
                  </span>
                  <p className={`text-sm font-bold ${reached ? "text-ink-900 dark:text-white" : "text-ink-400"}`}>{step.label}</p>
                  <p className="text-[11px] text-ink-400">{step.at ? formatDateTime(step.at) : "Pending"}</p>
                </li>
              );
            })}
          </ol>
        </div>
      </div>

      <div className="panel rounded-3xl p-5">
        <p className="text-xs font-black uppercase tracking-wide text-ink-400">Items</p>
        <div className="mt-3 space-y-3">
          {order.items.map((item) => (
            <div key={item.id} className="flex flex-wrap items-center gap-3">
              <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-ink-50 dark:bg-ink-900">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.image} alt="" loading="lazy" className="h-full w-full object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <Link href={`/product/${item.slug}`} className="line-clamp-1 text-sm font-semibold text-ink-900 hover:text-brand-600 dark:text-white">
                  {item.title}
                </Link>
                <p className="text-[11px] text-ink-400">
                  Qty {item.quantity}
                  {item.size ? ` · Size ${item.size}` : ""}
                  {item.color ? ` · ${item.color}` : ""}
                  {item.itemStatus !== "active" ? ` · ${item.itemStatus} requested` : ""}
                </p>
              </div>
              <p className="text-sm font-bold text-ink-900 dark:text-white">{rupees(item.price * item.quantity)}</p>
            </div>
          ))}
        </div>

        <dl className="mt-5 space-y-2 border-t pt-4 text-sm hairline">
          <div className="flex justify-between">
            <dt className="text-ink-600 dark:text-ink-300">Items total</dt>
            <dd className="font-bold">{rupees(order.itemsTotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-600 dark:text-ink-300">Discount {order.couponCode ? `(${order.couponCode})` : ""}</dt>
            <dd className="font-bold text-emerald-600 dark:text-emerald-400">− {rupees(order.discount)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-600 dark:text-ink-300">Delivery</dt>
            <dd className="font-bold">{order.deliveryFee === 0 ? "FREE" : rupees(order.deliveryFee)}</dd>
          </div>
          <div className="flex justify-between border-t pt-2 hairline">
            <dt className="font-black text-ink-900 dark:text-white">Total</dt>
            <dd className="text-lg font-black text-ink-900 dark:text-white">{rupees(order.total)}</dd>
          </div>
        </dl>
        {order.paymentRef && <p className="mt-3 text-[11px] text-ink-400">Payment reference: {order.paymentRef}</p>}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="panel rounded-3xl p-5">
          <p className="text-xs font-black uppercase tracking-wide text-ink-400">Delivery address</p>
          <p className="mt-2 text-sm font-bold text-ink-900 dark:text-white">
            {address.fullName} · {address.phone}
          </p>
          <p className="text-xs leading-relaxed text-ink-500 dark:text-ink-300">
            {address.line1}
            {address.line2 ? `, ${address.line2}` : ""}, {address.city}, {address.state} — {address.pincode}
          </p>
        </div>
        <OrderActions orderId={order.id} status={order.status} orderNumber={order.orderNumber} />
      </div>
    </div>
  );
}
