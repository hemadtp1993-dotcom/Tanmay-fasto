import { redirect } from "next/navigation";
import { Suspense } from "react";
import { desc, eq } from "drizzle-orm";
import AccountDashboard from "@/components/account-dashboard";
import { db } from "@/db";
import { addresses as addressesTable, notifications as notificationsTable, paymentMethods as paymentMethodsTable, returnRequests } from "@/db/schema";
import { currentUser } from "@/lib/auth";
import { getOrdersForUser, getRecentlyViewed, getWishlistProducts } from "@/lib/shop";
import { listCoupons } from "@/lib/shop";

export const dynamic = "force-dynamic";
export const metadata = { title: "My account" };

export default async function AccountPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const user = await currentUser();
  if (!user) redirect("/login?next=%2Faccount");

  const sp = await searchParams;
  const tabRaw = Array.isArray(sp.tab) ? sp.tab[0] : sp.tab;
  const tab = tabRaw ?? "profile";

  const [orders, adds, pays, notes, returns, recent, wishlist, coupons] = await Promise.all([
    getOrdersForUser(user.id),
    db.select().from(addressesTable).where(eq(addressesTable.userId, user.id)).orderBy(desc(addressesTable.isDefault)),
    db.select().from(paymentMethodsTable).where(eq(paymentMethodsTable.userId, user.id)),
    db.select().from(notificationsTable).where(eq(notificationsTable.userId, user.id)).orderBy(desc(notificationsTable.createdAt)).limit(30),
    db.select().from(returnRequests).where(eq(returnRequests.userId, user.id)).orderBy(desc(returnRequests.createdAt)),
    getRecentlyViewed(12),
    getWishlistProducts(),
    listCoupons(),
  ]);

  return (
    <Suspense fallback={<div className="shimmer h-96 rounded-3xl" />}>
      <AccountDashboard
        user={{
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          referralCode: user.referralCode,
          walletBalance: user.walletBalance,
          fastoCoins: user.fastoCoins,
          createdAt: user.createdAt,
        }}
        orders={orders}
        addresses={adds}
        paymentMethods={pays}
        notifications={notes}
        returns={returns}
        recent={recent}
        wishlist={wishlist}
        coupons={coupons}
        tab={tab}
      />
    </Suspense>
  );
}
