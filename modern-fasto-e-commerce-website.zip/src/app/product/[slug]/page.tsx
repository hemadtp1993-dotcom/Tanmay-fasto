import type { Metadata } from "next";
import { cookies } from "next/headers";
import { notFound } from "next/navigation";
import ProductDetail from "@/components/product-detail";
import { getProductBySlug, getProductReviews, getSimilar } from "@/lib/catalog";
import { getWishlistIds, trackView } from "@/lib/shop";
import { VISITOR_COOKIE } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: product.title,
    description: product.shortDescription || product.description.slice(0, 155),
    openGraph: { title: product.title, description: product.shortDescription, images: product.images.slice(0, 1) },
    alternates: { canonical: `/product/${product.slug}` },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const [reviews, similar, wishlist, jar] = await Promise.all([
    getProductReviews(product.id),
    getSimilar(product, 10),
    getWishlistIds(),
    cookies(),
  ]);

  await trackView(product.id);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.title,
    brand: { "@type": "Brand", name: product.brand },
    image: product.images,
    description: product.description,
    aggregateRating: { "@type": "AggregateRating", ratingValue: product.rating, reviewCount: product.reviewCount },
    offers: {
      "@type": "Offer",
      price: product.price,
      priceCurrency: "INR",
      availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <ProductDetail
        product={product}
        reviews={reviews}
        similar={similar}
        wishlisted={wishlist.includes(product.id)}
        pincode={jar.get(VISITOR_COOKIE)?.value?.slice(0, 6).replace(/[^0-9]/g, "") || "560038"}
      />
    </>
  );
}
