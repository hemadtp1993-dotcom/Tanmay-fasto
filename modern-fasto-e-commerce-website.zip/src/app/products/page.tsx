import type { Metadata } from "next";
import Listing from "@/components/listing";

export const dynamic = "force-dynamic";

export async function generateMetadata({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }): Promise<Metadata> {
  const params = await searchParams;
  const q = Array.isArray(params.q) ? params.q[0] : params.q;
  return {
    title: q ? `“${q}” — search results` : "All products",
    description: q ? `Shop ${q} on FASTO with free delivery above ₹499 and 7-day returns.` : "Browse the full FASTO catalogue.",
  };
}

export default async function ProductsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const params = await searchParams;
  const q = Array.isArray(params.q) ? params.q[0] : params.q;
  const tag = Array.isArray(params.tag) ? params.tag[0] : params.tag;

  const heading = q ? `Results for “${q}”` : tag === "flash" ? "Flash sale" : tag === "new" ? "New arrivals" : tag === "best" ? "Best sellers" : tag === "trending" ? "Trending now" : "All products";
  const subtitle = q ? "Filtered by relevance across 1.2 lakh listings" : "Use filters to narrow down by price, brand, size and more";

  return <Listing params={params} heading={heading} subtitle={subtitle} />;
}
