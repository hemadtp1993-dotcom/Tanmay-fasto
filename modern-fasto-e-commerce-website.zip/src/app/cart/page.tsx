import CartView from "@/components/cart-view";

export const dynamic = "force-dynamic";
export const metadata = { title: "Shopping cart" };

export default function CartPage() {
  return <CartView />;
}
