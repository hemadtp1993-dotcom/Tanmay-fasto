import Link from "next/link";
import { SectionHeader } from "@/components/ui";
import { getCategories } from "@/lib/catalog";
import { rupees } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata = { title: "All categories" };

const GRADIENTS = [
  "from-brand-600 to-brand-400",
  "from-flame-600 to-amber-400",
  "from-emerald-600 to-teal-400",
  "from-fuchsia-600 to-pink-400",
  "from-sky-600 to-cyan-400",
  "from-rose-600 to-orange-400",
  "from-violet-600 to-indigo-400",
  "from-lime-600 to-emerald-400",
  "from-amber-600 to-yellow-400",
  "from-slate-700 to-slate-500",
];

export default async function CategoriesPage() {
  const categories = await getCategories();

  return (
    <div className="space-y-8">
      <SectionHeader title="All categories" subtitle="Ten departments, 1.2 lakh+ products, one fast checkout" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {categories.map((c, i) => (
          <Link
            key={c.slug}
            href={`/category/${c.slug}`}
            className={`lift relative flex min-h-[150px] flex-col justify-between overflow-hidden rounded-3xl bg-gradient-to-br ${GRADIENTS[i % GRADIENTS.length]} p-4 text-white`}
          >
            <span className="absolute -right-6 -top-8 h-24 w-24 rounded-full bg-white/15 blur-xl" />
            <span aria-hidden className="text-3xl">{c.icon}</span>
            <span>
              <span className="block text-base font-black leading-tight">{c.name}</span>
              <span className="mt-0.5 block text-[11px] text-white/85">{c.tagline}</span>
            </span>
          </Link>
        ))}
      </div>

      <section className="panel rounded-3xl p-6">
        <h2 className="text-lg font-black text-ink-900 dark:text-white">Why shop on FASTO?</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {[
            ["⚡", "Fastest fulfilment", "Orders placed before 6 PM are dispatched the same day from our 34 warehouses."],
            ["🏷️", "Honest pricing", "No hidden charges at checkout. What you see is what you pay, always."],
            ["🤝", "Human support", "Real people on chat and calls, 7 days a week, 8 AM to midnight."],
          ].map(([icon, title, body]) => (
            <div key={title}>
              <span aria-hidden className="text-2xl">{icon}</span>
              <p className="mt-1.5 text-sm font-bold text-ink-900 dark:text-white">{title}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-ink-400">{body}</p>
            </div>
          ))}
        </div>
        <p className="mt-5 text-xs text-ink-400">
          Free delivery on eligible orders above {rupees(499)} · 7-day returns · 100% secure payments
        </p>
      </section>
    </div>
  );
}
